from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import Student, Company, Internship, Application, University, Feedback, Complaint, Interview
# from .user_serializers import UserSerializer

User = get_user_model()

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['email', 'first_name', 'last_name', 'password', 'is_active', 'user_type']
        extra_kwargs = {
            'password': {'write_only': True}  # Ensure password is write-only
        }

    def create(self, validated_data):
        user = User(
            email=validated_data['email'],
            first_name=validated_data['first_name'],
            # last_name=validated_data['last_name'],
            user_type=validated_data['user_type']
        )
        user.set_password(validated_data['password'])  # Hash the password
        user.save()
        return user

class StudentSerializer(serializers.ModelSerializer):
    user = UserSerializer()  # Nested serializer for user details

    class Meta:
        model = Student
        fields = ['id', 'user', 'university', 'cv_file', 'cv', 'profile']
        read_only_fields = ['cv']  # CV content is read-only, must use cv_file to update

    def create(self, validated_data):
        user_data = validated_data.pop('user')
        user = UserSerializer.create(UserSerializer(), validated_data=user_data)
        student = Student.objects.create(user=user, **validated_data)
        return student

    def update(self, instance, validated_data):
        user_data = validated_data.pop('user', None)
        print(validated_data)
        if user_data:
            user_serializer = UserSerializer(instance.user, data=user_data)
            user_serializer.is_valid(raise_exception=True)
            user_serializer.save()

        instance.university = validated_data.get('university', instance.university)
        instance.save()
        return instance

class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['id', 'user', 'company_name', 'logo', 'description']  # Include any other fields you need

class InternshipSerializer(serializers.ModelSerializer):
    company = CompanySerializer(read_only=True)  # For reading company data
    company_id = serializers.PrimaryKeyRelatedField(
        queryset=Company.objects.all(),
        write_only=True,
        source='company'
    )

    class Meta:
        model = Internship
        fields = ['id', 'title', 'description', 'skills_required', 'is_paid', 
                 'start_date', 'end_date', 'company', 'company_id']

    def create(self, validated_data):
        # Create the internship with the provided company
        return Internship.objects.create(**validated_data)

class InterviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Interview
        fields = ['id', 'date_time', 'location', 'interview_type', 'notes', 'status']

class ApplicationSerializer(serializers.ModelSerializer):
    student = serializers.PrimaryKeyRelatedField(queryset=Student.objects.all())
    internship = InternshipSerializer()  # Use the nested InternshipSerializer
    interviews = InterviewSerializer(many=True, read_only=True)  # Include interviews

    class Meta:
        model = Application
        fields = ['id', 'student', 'internship', 'date_applied', 'description', 'status', 'interviews']
        read_only_fields = ['date_applied', 'status']  # Status will be 'applied' by default

    def create(self, validated_data):
        user_id = validated_data.pop('student')
        try:
            student = Student.objects.get(user_id=user_id)
            validated_data['status'] = 'applied'
            validated_data['student'] = student
            return super().create(validated_data)
        except Student.DoesNotExist:
            raise serializers.ValidationError("Student not found for this user")

class UniversitySerializer(serializers.ModelSerializer):
    user = UserSerializer()  # Nested serializer for user details

    class Meta:
        model = University
        fields = ['id', 'user', 'university_code', 'description', 'location', 'website']

class FeedbackSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(queryset=User.objects.all(), required=True)

    class Meta:
        model = Feedback
        fields = ['id', 'user', 'message', 'rating', 'date_submitted']
        read_only_fields = ['date_submitted']
    def create(self, validated_data):
        return super().create(validated_data)

class ComplaintSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(queryset=User.objects.all(), required=True)

    class Meta:
        model = Feedback
        fields = ['id', 'user', 'message', 'rating', 'date_submitted']  # Exclude user field

    def create(self, validated_data):
        # The user is set in the view, so we don't need to handle it here
        return super().create(validated_data)



