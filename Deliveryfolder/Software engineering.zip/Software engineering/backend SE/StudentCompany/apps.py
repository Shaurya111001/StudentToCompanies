from django.apps import AppConfig


class StudentcompanyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'StudentCompany'
