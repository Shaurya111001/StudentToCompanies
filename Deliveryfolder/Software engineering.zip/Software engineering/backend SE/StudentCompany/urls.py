from django.urls import path
from .views import (
    RegisterView, LoginView, LogoutView,
    StudentView, CompanyView, InternshipView,
    RecommendationView, InterviewView, UniversityView,
    FeedbackView, ComplaintView, ApplicationView
)

urlpatterns = [
    # Auth URLs
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),

    # Student URLs
    path('students/', StudentView.as_view(), name='student-list'),
    path('students/<int:pk>/', StudentView.as_view(), name='student-detail'),

    # Company URLs
    path('companies/', CompanyView.as_view(), name='company-list'),
    path('companies/<int:pk>/', CompanyView.as_view(), name='company-detail'),

    # Internship URLs
    path('internships/', InternshipView.as_view(), name='internship-list'),
    path('internships/<int:pk>/', InternshipView.as_view(), name='internship-detail'),
    path('companies/<int:company_id>/internships/', InternshipView.as_view(), name='company-internships'),

    # Recommendation URL
    path('recommendations/', RecommendationView.as_view(), name='recommendations'),

    # Interview URLs
    path('interviews/', InterviewView.as_view(), name='interview-list'),
    path('interviews/<int:interview_id>/', InterviewView.as_view(), name='interview-detail'),
    path('applications/<int:application_id>/interviews/', InterviewView.as_view(), name='application-interviews'),

    # University URLs
    path('universities/', UniversityView.as_view(), name='university-list'),
    path('universities/<int:pk>/', UniversityView.as_view(), name='university-detail'),

    # Feedback URLs
    path('feedback/', FeedbackView.as_view(), name='feedback-list'),
    path('feedback/<int:feedback_id>/', FeedbackView.as_view(), name='feedback-detail'),

    # Complaint URLs
    path('complaints/', ComplaintView.as_view(), name='complaint-list'),
    path('complaints/<int:complaint_id>/', ComplaintView.as_view(), name='complaint-detail'),

    # Application URLs
    path('applications/', ApplicationView.as_view(), name='application-list'),
    path('applications/<int:application_id>/', ApplicationView.as_view(), name='application-detail'),
    path('internships/<int:internship_id>/applications/', ApplicationView.as_view(), name='internship-applications'),
]