import pytest
from django.urls import reverse, resolve
import logging

logger = logging.getLogger(__name__)

@pytest.mark.django_db
class TestUrls:
    def test_auth_urls(self):
        logger.info("Testing authentication URLs")
        
        # Test register URL
        url = reverse('register')
        assert resolve(url).view_name == 'register'
        logger.info(f"Register URL: {url}")
        
        # Test login URL
        url = reverse('login')
        assert resolve(url).view_name == 'login'
        logger.info(f"Login URL: {url}")
        
        # Test logout URL
        url = reverse('logout')
        assert resolve(url).view_name == 'logout'
        logger.info(f"Logout URL: {url}")

    def test_student_urls(self):
        logger.info("Testing student URLs")
        
        # Test student list URL
        url = reverse('student-list')
        assert resolve(url).view_name == 'student-list'
        logger.info(f"Student list URL: {url}")
        
        # Test student detail URL
        url = reverse('student-detail', args=[1])
        assert resolve(url).view_name == 'student-detail'
        logger.info(f"Student detail URL: {url}")

    def test_company_urls(self):
        logger.info("Testing company URLs")
        
        # Test company list URL
        url = reverse('company-list')
        assert resolve(url).view_name == 'company-list'
        logger.info(f"Company list URL: {url}")
        
        # Test company detail URL
        url = reverse('company-detail', args=[1])
        assert resolve(url).view_name == 'company-detail'
        logger.info(f"Company detail URL: {url}")

    def test_internship_urls(self):
        logger.info("Testing internship URLs")
        
        # Test internship list URL
        url = reverse('internship-list')
        assert resolve(url).view_name == 'internship-list'
        logger.info(f"Internship list URL: {url}")
        
        # Test internship detail URL
        url = reverse('internship-detail', args=[1])
        assert resolve(url).view_name == 'internship-detail'
        logger.info(f"Internship detail URL: {url}")
        
        # Test company internships URL
        url = reverse('company-internships', args=[1])
        assert resolve(url).view_name == 'company-internships'
        logger.info(f"Company internships URL: {url}")

    def test_interview_urls(self):
        logger.info("Testing interview URLs")
        
        # Test interview list URL
        url = reverse('interview-list')
        assert resolve(url).view_name == 'interview-list'
        logger.info(f"Interview list URL: {url}")
        
        # Test interview detail URL
        url = reverse('interview-detail', args=[1])
        assert resolve(url).view_name == 'interview-detail'
        logger.info(f"Interview detail URL: {url}")
        
        # Test application interviews URL
        url = reverse('application-interviews', args=[1])
        assert resolve(url).view_name == 'application-interviews'
        logger.info(f"Application interviews URL: {url}")

    def test_university_urls(self):
        logger.info("Testing university URLs")
        
        # Test university list URL
        url = reverse('university-list')
        assert resolve(url).view_name == 'university-list'
        logger.info(f"University list URL: {url}")
        
        # Test university detail URL
        url = reverse('university-detail', args=[1])
        assert resolve(url).view_name == 'university-detail'
        logger.info(f"University detail URL: {url}")

    def test_feedback_urls(self):
        logger.info("Testing feedback URLs")
        
        # Test feedback list URL
        url = reverse('feedback-list')
        assert resolve(url).view_name == 'feedback-list'
        logger.info(f"Feedback list URL: {url}")
        
        # Test feedback detail URL
        url = reverse('feedback-detail', args=[1])
        assert resolve(url).view_name == 'feedback-detail'
        logger.info(f"Feedback detail URL: {url}")

    def test_complaint_urls(self):
        logger.info("Testing complaint URLs")
        
        # Test complaint list URL
        url = reverse('complaint-list')
        assert resolve(url).view_name == 'complaint-list'
        logger.info(f"Complaint list URL: {url}")
        
        # Test complaint detail URL
        url = reverse('complaint-detail', args=[1])
        assert resolve(url).view_name == 'complaint-detail'
        logger.info(f"Complaint detail URL: {url}")

    def test_recommendation_url(self):
        logger.info("Testing recommendation URL")
        
        # Test recommendations URL
        url = reverse('recommendations')
        assert resolve(url).view_name == 'recommendations'
        logger.info(f"Recommendations URL: {url}")

    def test_application_urls(self):
        logger.info("Testing application URLs")
        
        # Test application list URL
        url = reverse('internship-applications', args=[1])
        assert resolve(url).view_name == 'internship-applications'
        logger.info(f"Application list for internship URL: {url}")
        
        # Test application detail URL
        url = reverse('application-detail', args=[1])
        assert resolve(url).view_name == 'application-detail'
        logger.info(f"Application detail URL: {url}")
