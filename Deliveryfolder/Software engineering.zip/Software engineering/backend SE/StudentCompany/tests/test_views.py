import pytest
from rest_framework import status
from rest_framework.test import APIClient
from django.urls import reverse
from ..models import User, Student, Company, University, Application, Feedback, Complaint, Interview

@pytest.mark.django_db
class TestViews:
    client = APIClient()

    @pytest.fixture(autouse=True)
    def setup(self):
        # Create test users
        self.student_user = User.objects.create_user(
            email='student@example.com',
            password='password123',
            user_type='student'
        )
        self.company_user = User.objects.create_user(
            email='company@example.com',
            password='password123',
            user_type='company'
        )
        self.university_user = User.objects.create_user(
            email='university@example.com',
            password='password123',
            user_type='university'
        )

        # Create test instances
        self.student = Student.objects.create(user=self.student_user)
        self.company = Company.objects.create(user=self.company_user, company_name='Test Company')
        self.university = University.objects.create(user=self.university_user, university_code='Adyf')

    def test_student_registration(self):
        url = reverse('register')
        data = {
            "email": "newstudent@example.com",
            "password": "password123",
            "first_name": "New",
            "last_name": "Student",
            "user_type": "student"
        }
        response = self.client.post(url, data)
        assert response.status_code == status.HTTP_201_CREATED
        assert response.data['email'] == data['email']

    def test_student_login(self):
        url = reverse('login')
        data = {
            "email": "student@example.com",
            "password": "password123"
        }
        response = self.client.post(url, data)
        assert response.status_code == status.HTTP_200_OK
        assert 'token' in response.data

    def test_company_create(self):
        self.client.login(email='company@example.com', password='password123')
        url = reverse('company-list')
        data = {
            "company_name": "New Company",
            "description": "A new company description."
        }
        response = self.client.post(url, data)
        assert response.status_code == status.HTTP_201_CREATED
        assert response.data['company_name'] == data['company_name']

    def test_university_create(self):
        self.client.login(email='university@example.com', password='password123')
        url = reverse('university-list')
        data = {
            "university_name": "New University",
            "description": "A new university description.",
            "location": "New Location",
            "website": "http://newuniversity.com"
        }
        response = self.client.post(url, data)
        assert response.status_code == status.HTTP_201_CREATED
        assert response.data['university_name'] == data['university_name']

    def test_application_create(self):
        self.client.login(email='student@example.com', password='password123')
        url = reverse('application-list')
        data = {
            "internship": 1,  # Assuming an internship with ID 1 exists
            "student": self.student.id,
            "status": "applied"
        }
        response = self.client.post(url, data)
        assert response.status_code == status.HTTP_201_CREATED
        assert response.data['status'] == data['status']

    def test_feedback_create(self):
        self.client.login(email='student@example.com', password='password123')
        url = reverse('feedback-list')
        data = {
            "message": "Great experience!",
            "rating": 5
        }
        response = self.client.post(url, data)
        assert response.status_code == status.HTTP_201_CREATED
        assert response.data['message'] == data['message']

    def test_complaint_create(self):
        self.client.login(email='student@example.com', password='password123')
        url = reverse('complaint-list')
        data = {
            "message": "I have a complaint about the service."
        }
        response = self.client.post(url, data)
        assert response.status_code == status.HTTP_201_CREATED
        assert response.data['message'] == data['message']

    def test_interview_create(self):
        self.client.login(email='company@example.com', password='password123')
        url = reverse('interview-list')
        data = {
            "application": 1,  # Assuming an application with ID 1 exists
            "date_time": "2023-12-01T10:00:00Z",
            "location": "Online",
            "interview_type": "online"
        }
        response = self.client.post(url, data)
        assert response.status_code == status.HTTP_201_CREATED
        assert response.data['location'] == data['location']

    def test_student_detail(self):
        self.client.login(email='student@example.com', password='password123')
        url = reverse('student-detail', args=[self.student.id])
        response = self.client.get(url)
        assert response.status_code == status.HTTP_200_OK
        assert response.data['email'] == self.student_user.email

    def test_company_detail(self):
        self.client.login(email='company@example.com', password='password123')
        url = reverse('company-detail', args=[self.company.id])
        response = self.client.get(url)
        assert response.status_code == status.HTTP_200_OK
        assert response.data['company_name'] == self.company.company_name

    def test_university_detail(self):
        self.client.login(email='university@example.com', password='password123')
        url = reverse('university-detail', args=[self.university.id])
        response = self.client.get(url)
        assert response.status_code == status.HTTP_200_OK
        assert response.data['university_code'] == self.university.university_code

    def test_feedback_list(self):
        self.client.login(email='student@example.com', password='password123')
        url = reverse('feedback-list')
        response = self.client.get(url)
        assert response.status_code == status.HTTP_200_OK

    def test_complaint_list(self):
        self.client.login(email='student@example.com', password='password123')
        url = reverse('complaint-list')
        response = self.client.get(url)
        assert response.status_code == status.HTTP_200_OK

    def test_interview_list(self):
        self.client.login(email='company@example.com', password='password123')
        url = reverse('interview-list')
        response = self.client.get(url)
        assert response.status_code == status.HTTP_200_OK
