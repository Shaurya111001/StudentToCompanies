from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .utils.Recommendation import Recommendation
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import get_user_model
from .serializers import UserSerializer, CompanySerializer
from rest_framework_simplejwt.exceptions import TokenError, InvalidToken
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.viewsets import ModelViewSet
from .models import Student, Internship, Company
from .serializers import StudentSerializer, InternshipSerializer
from .models import User
from .serializers import ApplicationSerializer
from .models import Application
from .models import Interview
from .serializers import InterviewSerializer
from .models import University
from .serializers import UniversitySerializer
from .models import Feedback
from .serializers import FeedbackSerializer
from .models import Complaint
from .serializers import ComplaintSerializer
from rest_framework import generics
import json
from rest_framework.authentication import TokenAuthentication


def get_tokens_for_user(user):

    refresh = RefreshToken.for_user(user)
    return {

    'refresh': str(refresh),
    'access': str(refresh.access_token),

}





class RegisterView(APIView):
    permission_classes = [AllowAny] 
    def post(self, request):
        user_data_dict = json.loads(request.data.get('user', {}))
        print(user_data_dict)
        serializer = UserSerializer(data=user_data_dict)
        
        if serializer.is_valid():
            user = serializer.save()
            out = {}
            tokens = get_tokens_for_user(user)
            
            if user_data_dict["user_type"] == "student":
                studentdata = {
                    "university": user_data_dict["university"], 
                    "cv_file": request.data.get("cv_file"), 
                    "user": user.id  # Changed: Pass user.id instead of user object
                }
                serializer = StudentSerializer(data=studentdata)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
            elif user_data_dict["user_type"] == "company":
                companydata = {
                    "company_name": user_data_dict.get("company_name", ""),  # Changed: Use get() with default
                    "description": user_data_dict.get("description", ""),
                    "user": user.id  # Changed: Pass user.id instead of user object
                }
                serializer = CompanySerializer(data=companydata)
                if serializer.is_valid():
                    serializer.save()
                    out["user_id"] = user.id
                    out["user_type"] = user.user_type
                    out["tokens"] = tokens
                    return Response(out, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            out["user_id"] = user.id
            out["type"] = user.user_type
            out["tokens"] = tokens
            return Response(out, status=status.HTTP_201_CREATED)
        
        print(serializer.errors)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    permission_classes = [AllowAny] 
    def post(self, request):
        username = request.data.get('email')
        password = request.data.get('password')
        out = {}
        try:
            user = get_user_model().objects.get(email=username)
            if not(user.check_password(password)):
                tokens = get_tokens_for_user(user)
                out["user_id"] = user.id
                out["type"] = user.user_type
                out["tokens"] = tokens
                return Response(out, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "Invalid credentials"}, status=status.HTTP_400_BAD_REQUEST)
        except get_user_model().DoesNotExist:
            return Response({"detail": "User not found"}, status=status.HTTP_400_BAD_REQUEST)
        

        



class LogoutView(APIView):
    def post(self, request):
        # Retrieve the refresh token from cookies
        refresh_token = request.COOKIES.get('refresh_token')

        if not refresh_token:
            return Response({"error": "Refresh token is missing."}, status=status.HTTP_400_BAD_REQUEST)
        

        try:
            # Create a RefreshToken instance from the refresh token string
            print(refresh_token)
            token = RefreshToken(refresh_token)

            # Blacklist the refresh token to invalidate it
            token.blacklist()

            # Successfully logged out
            return Response({"message": "Successfully logged out."}, status=status.HTTP_200_OK)

        except (TokenError, InvalidToken) as e:
            # If the token is invalid or expired, return an error response
            return Response({"error": "Invalid or expired refresh token."}, status=status.HTTP_400_BAD_REQUEST)



class StudentView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, pk=None):
        if pk:
            try:
                student = Student.objects.get(user_id=pk)
                serializer = StudentSerializer(student)
                return Response(serializer.data)
            except Student.DoesNotExist:
                return Response(
                    {"error": "Student not found"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
        
        students = Student.objects.all()
        serializer = StudentSerializer(students, many=True)
        return Response(serializer.data)

    def post(self, request):
        if request.user.user_type != 'student':
            return Response(
                {"error": "Only students can create student profiles"},
                status=status.HTTP_403_FORBIDDEN
            )
        email = request.data.get('user', {}).get('email', None)

        if not email:
            return Response(
                {"error": "Email is required"},
                status=status.HTTP_400_BAD_REQUEST
            )
        print(request.data)
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response(
                {"error": "User with this email does not exist"},
                status=status.HTTP_404_NOT_FOUND
            )

        # Now you can create the student profile
        request.data['user'] = user.id  # Set the user ID in the request data

        serializer = StudentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        print(serializer.errors)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            student = Student.objects.get(user_id=pk)
            
            # Check if the user is updating their own profile
            if request.user != student.user:
                return Response(
                    {"error": "You can only update your own profile"},
                    status=status.HTTP_403_FORBIDDEN
                )
            serializer = StudentSerializer(student, data=request.data, partial=True)
            if serializer.is_valid():
                print(request.data)
                serializer.save()
                return Response(serializer.data)
            print(serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Student.DoesNotExist:
            return Response(
                {"error": "Student not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
    def patch(self, request, pk):
        try:
            student = Student.objects.get(user_id=pk)
            
            # Check if the user is updating their own profile
            print(request.user)
            print(pk)
            if request.user != student.user:
                return Response(
                    {"error": "You can only update your own profile"},
                    status=status.HTTP_403_FORBIDDEN
                )

            serializer = StudentSerializer(student, data=request.data, partial=True)
            print("Hello")
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Student.DoesNotExist:
            return Response(
                {"error": "Student not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

    def delete(self, request, pk):
        try:
            student = Student.objects.get(user_id=pk)
            
            # Check if the user is deleting their own profile
            if request.user != student.user:
                return Response(
                    {"error": "You can only delete your own profile"},
                    status=status.HTTP_403_FORBIDDEN
                )

            student.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Student.DoesNotExist:
            return Response(
                {"error": "Student not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

class CompanyView(APIView):
    permission_classes = [AllowAny] 

    def get(self, request, pk=None):
        if pk:
            try:
                company = Company.objects.get(user_id=pk)
                serializer = CompanySerializer(company)
                return Response(serializer.data)
            except Company.DoesNotExist:
                return Response(
                    {"error": "Company not found"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
        
        companies = Company.objects.all()
        serializer = CompanySerializer(companies, many=True)
        return Response(serializer.data)

    def post(self, request):
        if request.user.user_type != 'company':
            return Response(
                {"error": "Only company users can create company profiles"},
                status=status.HTTP_403_FORBIDDEN
            )

        serializer = CompanySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            company = Company.objects.get(user_id=pk)
            
            # Check if the user is updating their own profile
            if request.user != company.user:
                return Response(
                    {"error": "You can only update your own company profile"},
                    status=status.HTTP_403_FORBIDDEN
                )

            serializer = CompanySerializer(company, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Company.DoesNotExist:
            return Response(
                {"error": "Company not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

    def delete(self, request, pk):
        try:
            company = Company.objects.get(pk=pk)
            
            # Check if the user is deleting their own profile
            if request.user != company.user:
                return Response(
                    {"error": "You can only delete your own company profile"},
                    status=status.HTTP_403_FORBIDDEN
                )

            company.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Company.DoesNotExist:
            return Response(
                {"error": "Company not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

class RecommendationView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []  # Remove any authentication requirement

    def get(self, request):
        user_id = request.query_params.get('user_id')
        if not user_id:
            return Response({"error": "User ID is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Get user first
            user = User.objects.get(id=user_id)
            # Then get the associated student profile
            student = Student.objects.get(user=user)
            
            # Debug prints
            print(f"Found user: {user.email}")
            print(f"Found student: {student.university}")
            
            internships = Internship.objects.all().values('id', 'title', 'description', 'skills_required')
            print(f"Found internships: {len(internships)}")
            
            if not internships:
                # If no internships exist, return all internships
                all_internships = Internship.objects.all()
                internship_serializer = InternshipSerializer(all_internships, many=True)
                return Response({
                    "recommendations": internship_serializer.data
                }, status=status.HTTP_200_OK)

            result = Recommendation.get_recommendations(internships, student.cv) 
            recommended_internships = Internship.objects.filter(id__in=result)
            
            internship_serializer = InternshipSerializer(recommended_internships, many=True)
            return Response({
                "recommendations": internship_serializer.data
            }, status=status.HTTP_200_OK)
            
        except User.DoesNotExist:
            return Response({"error": "User not found."}, status=status.HTTP_404_NOT_FOUND)
        except Student.DoesNotExist:
            return Response({"error": "No student profile found for this user."}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            print(f"Error: {str(e)}")  # Debug print
            return Response({
                "error": "An unexpected error occurred",
                "details": str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#2

class InternshipView(APIView):
    permission_classes = [IsAuthenticated] 

    def get(self, request, pk=None):  # Changed from internship_id to pk to match URL pattern
        try:
            # If pk is provided, get specific internship
            if pk is not None:
                internship = Internship.objects.get(id=pk)
                serializer = InternshipSerializer(internship)
                return Response(serializer.data, status=status.HTTP_200_OK)
            
            # Otherwise, handle list view
            user_id = request.query_params.get('user_id')
            
            if user_id:
                company = Company.objects.get(user_id=user_id)
                internships = Internship.objects.filter(company=company)
                if not internships.exists():
                    return Response(
                        {"message": "No internships found for this company"}, 
                        status=status.HTTP_404_NOT_FOUND
                    )
            else:
                internships = Internship.objects.all()

            serializer = InternshipSerializer(internships, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Internship.DoesNotExist:
            return Response(
                {"error": "Internship not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Company.DoesNotExist:
            return Response(
                {"error": "Company not found for this user"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response({
                "error": "An error occurred while fetching internships",
                "details": str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def post(self, request, *args, **kwargs):
        try:
            # Check if user is from a company
            if request.user.user_type != 'company':
                return Response(
                    {"error": "Only company users can create internships"}, 
                    status=status.HTTP_403_FORBIDDEN
                )

            # Transform the incoming data
            data = request.data.copy()
            company_id = data.pop('company')  # Extract the company ID
            user = User.objects.get(id=company_id)
            company = Company.objects.get(user=user)
            
            # Set company_id instead of company data
            data['company_id'] = company.id

            serializer = InternshipSerializer(data=data)
            if serializer.is_valid():
                serializer.save()
                return Response({
                    "message": "Internship created successfully!",
                    "data": serializer.data
                }, status=status.HTTP_201_CREATED)
            
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except User.DoesNotExist:
            return Response({"error": "User not found."}, status=status.HTTP_404_NOT_FOUND)
        except Company.DoesNotExist:
            return Response({"error": "Company not found."}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({
                "error": "An unexpected error occurred",
                "details": str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
class ApplicationView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, internship_id=None):
        try:
            user_id = request.query_params.get('user_id')
            
            if not user_id:
                return Response({"error": "User ID is required"}, status=status.HTTP_400_BAD_REQUEST)

            user = User.objects.get(id=user_id)

            if user.user_type != 'company':
                return Response(
                    {"error": "Only company users can view applications"},
                    status=status.HTTP_403_FORBIDDEN
                )

            company = Company.objects.get(user=user)

            # Filter applications by internship_id if provided
            if internship_id:
                applications = Application.objects.filter(
                    internship_id=internship_id,
                    internship__company=company
                ).select_related(
                    'student',
                    'student__user',
                    'internship',
                    'internship__company'
                ).prefetch_related('interviews')
            else:
                applications = Application.objects.filter(
                    internship__company=company
                ).select_related(
                    'student',
                    'student__user',
                    'internship',
                    'internship__company'
                ).prefetch_related('interviews')

            print(f"Found {applications.count()} applications")  # Debug print
            serializer = ApplicationSerializer(applications, many=True)
            return Response(serializer.data)

        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)
        except Company.DoesNotExist:
            return Response({"error": "Company not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            print(f"Error in ApplicationView GET: {str(e)}")  # Debug print
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def post(self, request):
        try:
            # Get user_id from request data
            user_id = request.data.get('student')
            if not user_id:
                return Response({"error": "User ID is required"}, status=status.HTTP_400_BAD_REQUEST)
            
            try:
                user = User.objects.get(id=user_id)
                if user.user_type != 'student':
                    return Response(
                        {"error": "Only students can apply for internships"},
                        status=status.HTTP_403_FORBIDDEN
                    )
                
                student = Student.objects.get(user=user)

            except User.DoesNotExist:
                return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)
            except Student.DoesNotExist:
                return Response({"error": "Student profile not found"}, status=status.HTTP_404_NOT_FOUND)

            serializer = ApplicationSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(
                    serializer.data,
                    status=status.HTTP_201_CREATED
                )
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        except Exception as e:
            print(f"Error in ApplicationView POST: {str(e)}")  # Debug print
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def patch(self, request, application_id):
        try:
            application = Application.objects.get(id=application_id)
            # Check user permissions and update logic
            # ...

            serializer = ApplicationSerializer(application, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except Application.DoesNotExist:
            return Response({"error": "Application not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            print(f"Error in ApplicationView PATCH: {str(e)}")  # Debug print
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        



    
class InterviewView(APIView):
    permission_classes = [AllowAny] 

    def get(self, request, application_id=None):
        try:
            if application_id:
                # Get interviews for specific application
                application = Application.objects.get(id=application_id)
                
                # Check permissions
                if request.user.user_type == 'company':
                    if request.user.company_profile != application.internship.company:
                        return Response(
                            {"error": "You can only view interviews for your own internships"},
                            status=status.HTTP_403_FORBIDDEN
                        )
                elif request.user.user_type == 'student':
                    if request.user.student_profile != application.student:
                        return Response(
                            {"error": "You can only view your own interviews"},
                            status=status.HTTP_403_FORBIDDEN
                        )
                
                interviews = Interview.objects.filter(application=application)
            else:
                # Get all interviews based on user type
                if request.user.user_type == 'company':
                    interviews = Interview.objects.filter(
                        application__internship__company=request.user.company_profile
                    )
                elif request.user.user_type == 'student':
                    interviews = Interview.objects.filter(
                        application__student=request.user.student_profile
                    )
                else:
                    return Response(
                        {"error": "Invalid user type"},
                        status=status.HTTP_403_FORBIDDEN
                    )

            serializer = InterviewSerializer(interviews, many=True)
            return Response(serializer.data)

        except Application.DoesNotExist:
            return Response(
                {"error": "Application not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def post(self, request):
        try:
            # Get user_id from query params
            user_id = request.query_params.get('user_id')
            if not user_id:
                return Response({"error": "User ID is required"}, status=status.HTTP_400_BAD_REQUEST)

            user = User.objects.get(id=user_id)
            if user.user_type != 'company':
                return Response(
                    {"error": "Only companies can schedule interviews"},
                    status=status.HTTP_403_FORBIDDEN
                )

            # Get the application ID from the request data
            application_id = request.data.get('application')
            if not application_id:
                return Response({"error": "Application ID is required"}, status=status.HTTP_400_BAD_REQUEST)

            # Verify the application exists
            application = Application.objects.get(id=application_id)
            if application.internship.company != user.company_profile:
                return Response(
                    {"error": "You can only schedule interviews for your own internships"},
                    status=status.HTTP_403_FORBIDDEN
                )

            # Create the interview
            serializer = InterviewSerializer(data=request.data)
            if serializer.is_valid():
                interview = serializer.save()
                
                # Update application status
                application.status = 'under_review'
                application.save()

                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)
        except Application.DoesNotExist:
            return Response({"error": "Application not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            print(f"Error in InterviewView POST: {str(e)}")  # Debug print
            return Response(
                {"error": "An unexpected error occurred", "details": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def patch(self, request, interview_id):
        try:
            interview = Interview.objects.get(id=interview_id)
            
            # Only companies can update interview details
            if request.user.user_type == 'company':
                if request.user.company_profile != interview.application.internship.company:
                    return Response(
                        {"error": "You can only update your own interviews"},
                        status=status.HTTP_403_FORBIDDEN
                    )
            else:
                return Response(
                    {"error": "Only companies can update interview details"},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            serializer = InterviewSerializer(
                interview,
                data=request.data,
                partial=True
            )
            
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        except Interview.DoesNotExist:
            return Response(
                {"error": "Interview not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        



    
class UniversityView(APIView):
    permission_classes = [AllowAny] 

    def get(self, request, pk=None):
        try:
            if pk:
                university = University.objects.get(pk=pk)
                # Get all students from this university
                students = Student.objects.filter(university=university.university_name)
                
                # Get all applications for these students
                applications = Application.objects.filter(student__in=students)
                
                # Prepare the response data
                student_data = []
                for student in students:
                    student_applications = applications.filter(student=student)
                    student_data.append({
                        'student': StudentSerializer(student).data,
                        'applications': ApplicationSerializer(student_applications, many=True).data
                    })
                
                response_data = {
                    'university': UniversitySerializer(university).data,
                    'students_and_applications': student_data
                }
                
                return Response(response_data)
            
            # If no pk, return all universities
            universities = University.objects.all()
            serializer = UniversitySerializer(universities, many=True)
            return Response(serializer.data)

        except University.DoesNotExist:
            return Response(
                {"error": "University not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def post(self, request):
        if request.user.user_type != 'university':
            return Response(
                {"error": "Only university users can create university profiles"},
                status=status.HTTP_403_FORBIDDEN
            )

        serializer = UniversitySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(user=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            university = University.objects.get(pk=pk)
            
            # Check if the user is updating their own profile
            if request.user != university.user:
                return Response(
                    {"error": "You can only update your own university profile"},
                    status=status.HTTP_403_FORBIDDEN
                )

            serializer = UniversitySerializer(university, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except University.DoesNotExist:
            return Response(
                {"error": "University not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

    def delete(self, request, pk):
        try:
            university = University.objects.get(pk=pk)
            
            # Check if the user is deleting their own profile
            if request.user != university.user:
                return Response(
                    {"error": "You can only delete your own university profile"},
                    status=status.HTTP_403_FORBIDDEN
                )

            university.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except University.DoesNotExist:
            return Response(
                {"error": "University not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        



    
class FeedbackView(APIView):
    # permission_classes = [IsAuthenticated]
    permission_classes = [AllowAny] 

    def get(self, request):
        try:
            # Admin users can see all feedback
            if request.user.is_staff:
                feedbacks = Feedback.objects.all()
            else:
                # Regular users can only see their own feedback
                feedbacks = Feedback.objects.all()

            serializer = FeedbackSerializer(feedbacks, many=True)
            return Response(serializer.data)

        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def post(self, request):
        try:
            user_id = request.data.get('user')  # Get user_id from request data
            if not user_id:
                return Response({"error": "User ID is required."}, status=status.HTTP_400_BAD_REQUEST)

            # Fetch the user based on user_id
            # try:
            #     user = User.objects.get(id=user_id)
            #     # print(user.id)
            # except User.DoesNotExist:
            #     return Response({"error": "User not found."}, status=status.HTTP_404_NOT_FOUND)

            # Prepare the feedback data
            feedback_data = request.data.copy()  # Create a copy of the request data
            feedback_data['user'] = user_id  # Assign the user object
            # print(feedback_data)

            # Validate and save the feedback
            serializer = FeedbackSerializer(data=feedback_data)
            
            if serializer.is_valid():
                serializer.save()  # Save the feedback with the associated user
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            print(serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def delete(self, request, feedback_id):
        try:
            feedback = Feedback.objects.get(id=feedback_id)
            
            # Only allow users to delete their own feedback or staff members
            if feedback.user != request.user and not request.user.is_staff:
                return Response(
                    {"error": "You can only delete your own feedback"},
                    status=status.HTTP_403_FORBIDDEN
                )

            feedback.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)

        except Feedback.DoesNotExist:
            return Response(
                {"error": "Feedback not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def put(self, request, feedback_id):
        try:
            feedback = Feedback.objects.get(id=feedback_id)
            
            # Only allow users to update their own feedback
            if feedback.user != request.user:
                return Response(
                    {"error": "You can only update your own feedback"},
                    status=status.HTTP_403_FORBIDDEN
                )

            serializer = FeedbackSerializer(
                feedback,
                data=request.data,
                partial=True
            )
            
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        except Feedback.DoesNotExist:
            return Response(
                {"error": "Feedback not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        



    
class ComplaintView(APIView):
    permission_classes = [AllowAny] 

    def get(self, request):
        try:
            # Staff can see all complaints
            if request.user.is_staff:
                complaints = Complaint.objects.all()
            else:
                # Regular users can only see their own complaints
                complaints = Complaint.objects.filter(user=request.user)

            # Optional status filter
            status = request.query_params.get('status', None)
            if status:
                complaints = complaints.filter(status=status)

            serializer = ComplaintSerializer(
                complaints, 
                many=True,
                context={'request': request}
            )
            return Response(serializer.data)

        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def post(self, request):
        try:
            serializer = ComplaintSerializer(
                data=request.data,
                context={'request': request}
            )
            if serializer.is_valid():
                # Associate the complaint with the current user
                serializer.save(user=request.user)
                return Response(
                    serializer.data,
                    status=status.HTTP_201_CREATED
                )
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def patch(self, request, complaint_id):
        try:
            complaint = Complaint.objects.get(id=complaint_id)
            
            # Check permissions
            if not request.user.is_staff and complaint.user != request.user:
                return Response(
                    {"error": "You don't have permission to modify this complaint"},
                    status=status.HTTP_403_FORBIDDEN
                )

            # Regular users can only update the message
            if not request.user.is_staff:
                allowed_fields = {'message'}
                received_fields = set(request.data.keys())
                if not received_fields.issubset(allowed_fields):
                    return Response(
                        {"error": "You can only update the message content"},
                        status=status.HTTP_403_FORBIDDEN
                    )

            serializer = ComplaintSerializer(
                complaint,
                data=request.data,
                partial=True,
                context={'request': request}
            )
            
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        except Complaint.DoesNotExist:
            return Response(
                {"error": "Complaint not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def delete(self, request, complaint_id):
        try:
            complaint = Complaint.objects.get(id=complaint_id)
            
            # Only staff or the complaint owner can delete
            if not request.user.is_staff and complaint.user != request.user:
                return Response(
                    {"error": "You don't have permission to delete this complaint"},
                    status=status.HTTP_403_FORBIDDEN
                )

            complaint.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)

        except Complaint.DoesNotExist:
            return Response(
                {"error": "Complaint not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        



    