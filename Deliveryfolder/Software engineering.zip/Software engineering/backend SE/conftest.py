import pytest
import logging
from datetime import datetime
from logging.handlers import RotatingFileHandler

# Configure logging
@pytest.fixture(autouse=True)
def setup_logging(request):
    # Create a unique log file name with timestamp
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = f'test_logs/test_run_{timestamp}.log'
    handler = RotatingFileHandler(
        log_file,
        maxBytes=1024*1024,  # 1MB
        backupCount=5
    )
    
    # Configure the logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(name)s:%(lineno)d - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[
            handler,
            logging.StreamHandler()  # This will also show logs in console
        ]
    )
    
    # Create a logger for the test
    logger = logging.getLogger(__name__)
    
    # Log the start of the test
    logger.info(f"Starting test: {request.node.name}")
    
    yield logger  # This makes the logger available in tests
    
    # Log the end of the test
    logger.info(f"Finished test: {request.node.name}\n")

def pytest_terminal_summary(terminalreporter, exitstatus):
    logger = logging.getLogger(__name__)
    logger.info("\nTest Summary:")
    logger.info(f"Total tests: {terminalreporter.stats.get('total', 0)}")
    logger.info(f"Passed tests: {len(terminalreporter.stats.get('passed', []))}")
    logger.info(f"Failed tests: {len(terminalreporter.stats.get('failed', []))}")
    logger.info(f"Skipped tests: {len(terminalreporter.stats.get('skipped', []))}")
