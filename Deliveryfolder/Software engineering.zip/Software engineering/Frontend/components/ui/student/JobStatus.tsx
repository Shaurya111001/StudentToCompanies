'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import {
  Building,
  MapPin,
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  MessageCircle,
  Briefcase,
  GraduationCap,
  FileText,
  DollarSign,
  Mail,
  Phone
} from 'lucide-react'
import axios from 'axios'

interface JobStatusData {
  internship: {
    title: string
    student: number
    description: string
    skills_required: string // Use skills_required from the backend
    type: string
    is_paid: boolean // Use is_paid from the backend
    salary: string | null // Salary might be null, so make it optional or nullable
    start_date: string
    end_date: string
    company: {
      company_name: string // Use company_name from the backend
      logo: string | null // Logo might be null
      description: string
      location: string
      website: string | null // Website might be null
    }
  }
  date_applied: string // Use date_applied from the backend
  status: 'under_review' | 'interviewed' | 'accepted' | 'rejected' // Match backend status values
  interviews: {
    date_time: string;
    location: string;
    interview_type: string;
    notes: string;
  }[]
}

interface JobStatusProps {
  applicationId: string;
}
interface UserData {
  email: string
  first_name: string
  last_name: string
  is_active: boolean
  user_type: string
}

interface ProfileData {
  id: number
  university: string
  cv: string | null
  user: UserData
}


const JobStatus = ({ applicationId }: JobStatusProps) => {
  const router = useRouter()
  const [internshipStatus, setInternshipStatus] = useState<JobStatusData | null>(null)
  const [loading, setLoading] = useState(true)
  const [profileData, setProfileData] = useState<ProfileData | null>(null)

  useEffect(() => {
    const fetchInternshipStatus = async () => {
      const userId = localStorage.getItem('user_id')
      if (!applicationId || !userId) return

      try {
        const response = await axios.get(`http://localhost:8000/api/applications/${applicationId}/`, {
          params: { user_id: userId }
        })
        setInternshipStatus(response.data)
        console.log("Fetched internship status:", response.data)
      } catch (error) {
        console.error("Error fetching internship status:", error)
      } finally {
        setLoading(false)
      }
    }
    

    fetchInternshipStatus()
  }, [applicationId])



  useEffect(() => {
    const fetchStudentData = async () => {
      const token = localStorage.getItem('accessToken')
      var _user = localStorage.getItem("user_id");
      var _usertype = localStorage.getItem("user_type")
      try {
        if (_user) {
          
          const response = await axios.get(`http://localhost:8000/api/students/${_user}/`, {
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          })
          setProfileData(response.data)
          console.log(response.data)
        }
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    fetchStudentData()
  },[internshipStatus])





  const getStatusColor = (status: JobStatusData['application']['status']) => {
    switch (status) {
      case 'accepted':
        return 'bg-green-100 text-green-800'
      case 'rejected':
        return 'bg-red-100 text-red-800'
      case 'interviewed':
        return 'bg-blue-100 text-blue-800'
      default:
        return 'bg-yellow-100 text-yellow-800'
    }
  }

  const getStatusIcon = (status: JobStatusData['application']['status']) => {
    switch (status) {
      case 'accepted':
        return <CheckCircle2 className="h-5 w-5 text-green-600" />
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-600" />
      case 'interviewed':
        return <MessageCircle className="h-5 w-5 text-blue-600" />
      default:
        return <Clock className="h-5 w-5 text-yellow-600" />
    }
  }

  if (loading) {
    return <div>Loading...</div>
  }

  if (!internshipStatus || !internshipStatus.internship || !internshipStatus.internship.company) {
    return <div>No internship status found or company information is missing.</div>
  }
  if (!internshipStatus) { // Simplified condition
    return <div>No internship status found.</div>; // More accurate message
  }


  return (
    <div className="max-w-4xl mx-auto p-8">
      {/* Company Section */}
      <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
        <div className="flex items-start space-x-6">
          <div className="relative w-20 h-20 flex-shrink-0">
          <Image
              src={internshipStatus.internship.company.logo || '/path/to/default/logo.png'} // Handle null logo
              alt={internshipStatus.internship.company.company_name} // Use company_name
              fill
              className="object-contain rounded-lg"
            />
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900">{internshipStatus.internship.title}</h1>
            <div className="mt-2 flex flex-wrap gap-4 text-sm text-gray-600">
              <span className="flex items-center">
                <MapPin className="h-4 w-4 mr-1" />
                {internshipStatus.internship.company.location}
              </span>
              <span className="flex items-center">
                <Building className="h-4 w-4 mr-1" />
                {internshipStatus.internship.company.website}
              </span>
            </div>
            <p className="mt-4 text-gray-600">{internshipStatus.internship.description}</p>
          </div>
        </div>
      </div>

      {/* Job Details Section */}
      <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Job Details</h2>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-900">{internshipStatus.internship.title}</h3>
            <div className="flex items-center gap-4">
              <span className="flex items-center text-gray-600">
                <Briefcase className="h-4 w-4 mr-1" />
                {internshipStatus.internship.type}
              </span>
              <span className="flex items-center text-gray-600">
                <DollarSign className="h-4 w-4 mr-1" />
                {internshipStatus.internship.salary}
              </span>
            </div>
          </div>
          <p className="text-gray-600">{internshipStatus.internship.description}</p>
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Requirements</h4>
            {/* <ul className="list-disc list-inside text-gray-600 space-y-1">
              {internshipStatus.internship.map((req, index) => (
                <li key={index}>{req}</li>
              ))}
            </ul> */}
          </div>
        </div>
      </div>

      {/* Application Details Section */}
      <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Your Application</h2>
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">Contact Information</h4>
              <div className="space-y-2 text-gray-600">
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  {profileData.user.email}
                </div>
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  {profileData.user.phone}
                </div>
                <div className="flex items-center">
                  <GraduationCap className="h-4 w-4 mr-2" />
                  {profileData.university}
                </div>
              </div>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">Application Timeline</h4>
              <div className="space-y-2 text-gray-600">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  Applied: {new Date(internshipStatus.date_applied).toLocaleDateString()}
                </div>
                {internshipStatus.interview_date && (
                  <div className="flex items-center">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Interview: {new Date(internshipStatus.application.interview_date).toLocaleDateString()}
                    {internshipStatus.application.interview_completed && 
                      <span className="ml-2 text-green-600">(Completed)</span>
                    }
                  </div>
                )}
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Your Experience</h4>
            <p className="text-gray-600 whitespace-pre-line">
              {profileData.experience}
            </p>
          </div>

          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Cover Letter</h4>
            <p className="text-gray-600 whitespace-pre-line">
              {profileData.cover_letter}
            </p>
          </div>
        </div>
      </div>

      {/* Status Section */}
      <div className="bg-white rounded-xl shadow-sm p-8">
        <div className="text-center">
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium
            ${getStatusColor(internshipStatus.status)}`}
          >
            {getStatusIcon(internshipStatus.status)}
            <span className="capitalize">Application {internshipStatus.status}</span>
          </div>

          {internshipStatus.feedback && (
            <div className="mt-6">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Feedback</h4>
              <p className="text-gray-600">{internshipStatus.application.feedback}</p>
            </div>
          )}

          <button
            onClick={() => router.push(`/student/feedback?application=${applicationId}`)}
            className="mt-6 px-6 py-2 bg-purple-500 text-white rounded-lg 
              hover:bg-purple-600 transition-colors"
          >
            Provide Portal Feedback
          </button>
        </div>
      </div>
    </div>
  )
}

export default JobStatus