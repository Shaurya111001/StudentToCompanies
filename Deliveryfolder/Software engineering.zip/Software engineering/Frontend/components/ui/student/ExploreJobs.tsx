'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import axios from 'axios'
import { 
  Search, 
  User, 
  Clock, 
  FileCheck, 
  LogOut,
  Briefcase,
  MapPin,
  DollarSign,
  Filter,
  Calendar
} from 'lucide-react'

interface Job {
  id: number
  title: string
  description: string
  skills_required: string
  is_paid: boolean
  start_date: string
  end_date: string
  company_id: number
}

const ExploreJobs = () => {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState('')
  const [showFilters, setShowFilters] = useState(true)
  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchRecommendedJobs()
  }, [])

  const fetchRecommendedJobs = async () => {
    try {
      const userId = localStorage.getItem('user_id')
      const token = localStorage.getItem('accessToken')

      if (!userId || !token) {
        throw new Error('Authentication required')
      }

      const response = await axios.get(`http://localhost:8000/api/recommendations/`, {
        params: {
          user_id: userId
        },
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      })

      console.log('Response:', response.data)
      console.log(response.data);
      setJobs(response.data.recommendations)
    } catch (error: any) {
      console.error('Error details:', error.response?.data)
      console.error('Failed to fetch recommended jobs:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleApply = (jobId: number) => {
    router.push(`/student/applyjob?id=${jobId}`)
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Left Sidebar - Filters */}
      <div className={`w-80 bg-white border-r border-gray-200 p-6 space-y-6 transition-all duration-300 ${showFilters ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-800">Filters</h2>
          <button onClick={() => setShowFilters(!showFilters)}>
            <Filter className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Filter Sections */}
        <div className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-sm font-medium text-gray-600">Job Type</h3>
            {['Full-time', 'Part-time', 'Contract', 'Internship'].map((type) => (
              <label key={type} className="flex items-center space-x-3">
                <input type="checkbox" className="rounded border-gray-300 text-blue-500 focus:ring-blue-500" />
                <span className="text-gray-700">{type}</span>
              </label>
            ))}
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-medium text-gray-600">Experience Level</h3>
            {['Entry Level', 'Mid Level', 'Senior Level', 'Lead'].map((level) => (
              <label key={level} className="flex items-center space-x-3">
                <input type="checkbox" className="rounded border-gray-300 text-blue-500 focus:ring-blue-500" />
                <span className="text-gray-700">{level}</span>
              </label>
            ))}
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-medium text-gray-600">Salary Range</h3>
            {['$0-$50k', '$50k-$100k', '$100k-$150k', '$150k+'].map((range) => (
              <label key={range} className="flex items-center space-x-3">
                <input type="checkbox" className="rounded border-gray-300 text-blue-500 focus:ring-blue-500" />
                <span className="text-gray-700">{range}</span>
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Navigation Bar */}
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Search Bar */}
            <div className="flex-1 max-w-2xl">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search for jobs..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-400"
                />
              </div>
            </div>

            {/* Navigation Icons */}
            <nav className="flex items-center space-x-6 ml-6">
              <button onClick={() => router.push('/profile')} className="p-2 hover:bg-gray-100 rounded-full">
                <User className="h-6 w-6 text-gray-600" />
              </button>
              <button onClick={() => router.push('/status')} className="p-2 hover:bg-gray-100 rounded-full">
                <Clock className="h-6 w-6 text-gray-600" />
              </button>
              <button onClick={() => router.push('/applications')} className="p-2 hover:bg-gray-100 rounded-full">
                <FileCheck className="h-6 w-6 text-gray-600" />
              </button>
              <div className="relative group">
                <button className="p-2 hover:bg-gray-100 rounded-full">
                  <LogOut className="h-6 w-6 text-gray-600" />
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 invisible group-hover:visible">
                  <button 
                    onClick={() => router.push('/logout')}
                    className="w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    Logout
                  </button>
                </div>
              </div>
            </nav>
          </div>
        </header>

        {/* Job Posts Feed */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-3xl mx-auto space-y-6">
            {jobs.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-xl shadow-sm">
                <h3 className="text-xl text-gray-600">No internships available</h3>
                <p className="text-gray-500 mt-2">Check back later for new opportunities</p>
              </div>
            ) : (
              jobs.map((job) => (
                <article 
                  key={job.id}
                  className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200"
                >
                  <div className="flex items-start space-x-4">
                    <div className="relative w-16 h-16 flex-shrink-0">
                      <Image
                        src="/assets/images/default-company-logo.png"
                        alt="Company Logo"
                        fill
                        className="object-contain rounded-lg"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h2 className="text-lg font-semibold text-gray-900">{job.title}</h2>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-4 text-sm text-gray-500">
                        <span className="flex items-center">
                          <DollarSign className="h-4 w-4 mr-1" />
                          {job.is_paid ? 'Paid' : 'Unpaid'}
                        </span>
                        <span className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          {new Date(job.start_date).toLocaleDateString()} - {new Date(job.end_date).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="mt-3 text-gray-600">{job.description}</p>
                      <div className="mt-2">
                        <h3 className="text-sm font-medium text-gray-600">Required Skills:</h3>
                        <p className="text-gray-600">{job.skills_required}</p>
                      </div>
                      <div className="mt-4">
                        <button
                          onClick={() => handleApply(job.id)}
                          className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                        >
                          Apply Now
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              ))
            )}
          </div>
        </main>
      </div>
    </div>
  )
}

export default ExploreJobs