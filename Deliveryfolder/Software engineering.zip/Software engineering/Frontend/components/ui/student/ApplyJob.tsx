'use client'
import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import axios from 'axios'
import { Calendar, DollarSign, Building, BookOpen } from 'lucide-react'

interface Job {
  id: number
  title: string
  description: string
  skills_required: string
  is_paid: boolean
  start_date: string
  end_date: string
}

export default function ApplyJob() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const internshipId = searchParams.get('id')

  const [job, setJob] = useState<Job | null>(null)
  const [hasApplied, setHasApplied] = useState(false)
  const [loading, setLoading] = useState(true)
  const [description, setDescription] = useState('')

  useEffect(() => {
    if (internshipId) {
      fetchJobDetails()
      checkApplicationStatus()
    }
  }, [internshipId])

  const fetchJobDetails = async () => {
    try {
      const token = localStorage.getItem('accessToken')
      const response = await axios.get(`http://localhost:8000/api/internships/${internshipId}/`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      setJob(response.data)
    } catch (error) {
      console.error('Failed to fetch job details:', error)
    } finally {
      setLoading(false)
    }
  }

  const checkApplicationStatus = async () => {
    try {
      const token = localStorage.getItem('accessToken')
      const userId = localStorage.getItem('user_id')
      
      if (!userId) {
        console.error('User ID not found')
        return
      }

      const response = await axios.get(
        `http://localhost:8000/api/internships/${internshipId}/applications/`, 
        {
          params: { 
            check_status: true,
            user_id: userId
          },
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      )
      setHasApplied(response.data.has_applied)
    } catch (error) {
      console.error('Failed to check application status:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const token = localStorage.getItem('accessToken')
      const userId = localStorage.getItem('user_id')

      const response = await axios.post(
        'http://localhost:8000/api/applications/',
        {
          student: userId,
          internship: internshipId,
          description: description
        },
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      )

      alert('Application submitted successfully!')
      router.push('/student/explorejob')
    } catch (error: any) {
      console.error('Failed to submit application:', error)
      alert(error.response?.data?.error || 'Failed to submit application')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  if (!job) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800">Job not found</h2>
          <button
            onClick={() => router.push('/student/explorejobs')}
            className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
          >
            Back to Jobs
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      {/* Job Details Section */}
      <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">{job.title}</h1>
        
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="flex items-center text-gray-600">
            <Calendar className="h-5 w-5 mr-2" />
            <span>{new Date(job.start_date).toLocaleDateString()} - {new Date(job.end_date).toLocaleDateString()}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <DollarSign className="h-5 w-5 mr-2" />
            <span>{job.is_paid ? 'Paid Position' : 'Unpaid Position'}</span>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Description</h2>
            <p className="text-gray-600">{job.description}</p>
          </div>
          
          <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Required Skills</h2>
            <p className="text-gray-600">{job.skills_required}</p>
          </div>
        </div>
      </div>

      {/* Application Form Section */}
      {hasApplied ? (
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 text-center">
          <h2 className="text-xl font-semibold text-yellow-800">You have already applied for this position</h2>
          <p className="text-yellow-600 mt-2">Check your applications page for status updates</p>
          <button
            onClick={() => router.push('/student/explorejob')}
            className="mt-4 px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600"
          >
            Back to Jobs
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Submit Your Application</h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Why are you interested in this position?
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                rows={6}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Describe your interest and qualifications..."
              />
            </div>

            <div className="flex justify-end space-x-4">
              <button
                type="button"
                onClick={() => router.push('/student/explorejob')}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
              >
                Submit Application
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}