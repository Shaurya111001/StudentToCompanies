const InterviewRes = () =>{
    return(<></>)
}
export default InterviewRes;