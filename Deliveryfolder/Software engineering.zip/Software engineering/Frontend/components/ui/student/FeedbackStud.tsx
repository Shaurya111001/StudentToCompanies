'use client'
import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Star, Send, MessageSquare, Clock, Heart } from 'lucide-react'
import axios from 'axios';

interface FeedbackForm {
  portalUsability: number
  applicationProcess: number
  communicationClarity: number
  overallExperience: number
  suggestions: string
  wouldRecommend: boolean
  message: string
}

const FeedbackStud = () => {
  const router = useRouter()
  const searchParams = useSearchParams()
  const applicationId = searchParams.get('application')

  const [feedback, setFeedback] = useState<FeedbackForm>({
    portalUsability: 0,
    applicationProcess: 0,
    communicationClarity: 0,
    overallExperience: 0,
    suggestions: '',
    wouldRecommend: true,
    message: ''
  })

  const RatingStars = ({ 
    rating, 
    onRatingChange 
  }: { 
    rating: number
    onRatingChange: (rating: number) => void 
  }) => {
    return (
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => onRatingChange(star)}
            className="focus:outline-none"
          >
            <Star
              className={`h-6 w-6 ${
                star <= rating
                  ? 'fill-yellow-400 text-yellow-400'
                  : 'text-gray-300'
              }`}
            />
          </button>
        ))}
      </div>
    )
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // API call to submit feedback
    try {
      const userId = localStorage.getItem('user_id'); // Retrieve user ID from localStorage
      if (!userId) {
        console.error("User ID is not found in localStorage.");
        return;
      }

      const response = await axios.post('http://localhost:8000/api/feedback/', {
        user: userId, // Include user ID in the feedback data
        ...feedback, // Spread the feedback data
        application: applicationId // Include application ID if needed
      });

      console.log('Feedback submitted successfully:', response.data);
      // On success, redirect back
      router.push('/student/joblist');
    } catch (error) {
      console.error('Error submitting feedback:', error);
    }
  }

  return (
    <div className="max-w-3xl mx-auto p-8">
      <div className="bg-white rounded-xl shadow-sm p-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">
          Help Us Improve Your Experience
        </h1>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Rating Sections */}
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <MessageSquare className="h-4 w-4 mr-2" />
                Portal Usability
              </label>
              <RatingStars
                rating={feedback.portalUsability}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, portalUsability: rating }))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <Clock className="h-4 w-4 mr-2" />
                Application Process
              </label>
              <RatingStars
                rating={feedback.applicationProcess}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, applicationProcess: rating }))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <MessageSquare className="h-4 w-4 mr-2" />
                Communication Clarity
              </label>
              <RatingStars
                rating={feedback.communicationClarity}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, communicationClarity: rating }))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <Heart className="h-4 w-4 mr-2" />
                Overall Experience
              </label>
              <RatingStars
                rating={feedback.overallExperience}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, overallExperience: rating }))
                }
              />
            </div>
          </div>

          {/* Suggestions Text Area */}
          <div className="space-y-2">
            <label className="flex items-center text-sm font-medium text-gray-700">
              Suggestions for Improvement
            </label>
            <textarea
              value={feedback.suggestions}
              onChange={(e) => setFeedback(prev => ({
                ...prev,
                suggestions: e.target.value
              }))}
              rows={4}
              className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                focus:ring-purple-100 focus:border-purple-400 outline-none"
              placeholder="Please share your suggestions on how we can improve..."
            />
          </div>

          {/* Feedback Message Text Area */}
          <div className="space-y-2">
            <label className="flex items-center text-sm font-medium text-gray-700">
              Your Feedback Message
            </label>
            <textarea
              value={feedback.message}
              onChange={(e) => setFeedback(prev => ({
                ...prev,
                message: e.target.value
              }))}
              rows={4}
              className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                focus:ring-purple-100 focus:border-purple-400 outline-none"
              placeholder="Please provide your feedback message..."
              required
            />
          </div>

          {/* Would Recommend */}
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="recommend"
              checked={feedback.wouldRecommend}
              onChange={(e) => setFeedback(prev => ({
                ...prev,
                wouldRecommend: e.target.checked
              }))}
              className="h-4 w-4 text-purple-500 focus:ring-purple-400 
                border-gray-300 rounded"
            />
            <label htmlFor="recommend" className="text-sm text-gray-700">
              I would recommend this portal to other students
            </label>
          </div>

          {/* Submit Buttons */}
          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="px-6 py-2 bg-purple-500 text-white rounded-lg 
                hover:bg-purple-600 transition-colors flex items-center"
            >
              <Send className="h-4 w-4 mr-2" />
              Submit Feedback
            </button>
            <button
              type="button"
              onClick={() => router.back()}
              className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg 
                hover:bg-gray-200 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default FeedbackStud