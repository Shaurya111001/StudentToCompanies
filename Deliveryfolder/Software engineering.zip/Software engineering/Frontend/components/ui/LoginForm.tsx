'use client'
import { useState, useEffect } from 'react';
import Image from 'next/image';
import { FaEnvelope, FaLock } from 'react-icons/fa';
import axios from 'axios';
import { useRouter } from 'next/navigation';
import { useUser } from '../../app/context/UserContext';

export default function LoginForm() {
  const { user, setUser } = useUser();
  const [mounted, setMounted] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState('');
  const router = useRouter();

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null; // Prevent rendering until mounted


  const handleUser = (u) => {
    setUser(u);
  }; 
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    try {
      const response = await axios.post('http://localhost:8000/api/login/', {
        email,
        password,
      });

      const { access, refresh } = response.data.tokens;
      var user_id = response.data.user_id
      var user_type = response.data.type // Assuming user_id and user_type are returned
      // const usercontext  = {
      //   "user_id": user_id,
      //   "user_type": user_type
      // }

      localStorage.setItem('user_id', user_id);
      localStorage.setItem('user_type', user_type);
      localStorage.setItem('accessToken', access);
      localStorage.setItem('refreshToken', refresh);
      console.log(response.data)

      setSuccess("Login successful!");


      // Redirect based on user type
      if (user_type === 'student') {
        router.push('/student');
      
      } else if (user_type === 'company') {
        router.push('/company/');

      } else if (user_type === 'university') {
        router.push('/university/');
      } else {
        router.push('/');
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Login failed. Please try again.');
    }
  };

  return (
    <div className="w-full h-screen flex items-center justify-center bg-gray-50">
      <div className="w-full max-w-md mx-4 space-y-8 p-8 bg-white rounded-xl shadow-lg">
        {/* Logo/Image */}
        <div className="text-center">
          <Image
            src="/assets/images/OE60WQ0.jpg" // Add your logo here
            alt="Job Portal Logo"
            width={80}
            height={80}
            className="mx-auto"
          />
          <h2 className="mt-6 text-3xl font-bold text-gray-900">
            Welcome Back!
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Sign in to access your account
          </p>
        </div>

        {error && <p className="error">{error}</p>}
        {success && <p className="success">{success}</p>}

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="relative">
            <FaEnvelope className="absolute top-3 left-3 text-gray-400" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email Address"
              required
              className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <div className="relative">
            <FaLock className="absolute top-3 left-3 text-gray-400" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              required
              className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <input
                type="checkbox"
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-900">
                Remember me
              </label>
            </div>
            <div className="text-sm">
              <a
                href="#"
                className="font-medium text-blue-600 hover:text-blue-500"
              >
                Forgot password?
              </a>
            </div>
          </div>

          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Sign In
          </button>

          <div className="text-center">
            <button
              type="button"
              className="text-sm text-blue-600 hover:text-blue-500"
            >
              Don't have an account? Sign up
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
