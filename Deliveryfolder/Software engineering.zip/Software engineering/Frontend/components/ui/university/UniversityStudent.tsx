'use client'
import { useState } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { 
  Search,
  GraduationCap,
  Building,
  Mail,
  Phone,
  CheckCircle2,
  XCircle,
  Clock,
  Filter
} from 'lucide-react'

interface Student {
  id: string
  name: string
  profile_image: string
  email: string
  phone: string
  department: string
  year: string
  placements: {
    company_name: string
    position: string
    status: 'pending' | 'accepted' | 'rejected'
    package?: string
  }[]
}

export default function UniversityStudent() {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState('')
  const [filterDepartment, setFilterDepartment] = useState('all')

  // Mock data - replace with API call
  const [students] = useState<Student[]>([
    {
      id: '1',
      name: 'John Doe',
      profile_image: '/assets/images/default-avatar.png',
      email: 'john.doe@university.edu',
      phone: '+1 234 567 8900',
      department: 'Computer Science',
      year: '2024',
      placements: [
        {
          company_name: 'Tech Corp',
          position: 'Software Engineer',
          status: 'accepted',
          package: '$95,000'
        },
        {
          company_name: 'Innovation Labs',
          position: 'Frontend Developer',
          status: 'rejected'
        }
      ]
    },
    // Add more students as needed
  ])

  const departments = ['all', 'Computer Science', 'Information Technology', 'Electronics', 'Mechanical']

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'accepted':
        return 'bg-green-100 text-green-800'
      case 'rejected':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-yellow-100 text-yellow-800'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'accepted':
        return <CheckCircle2 className="h-4 w-4 text-green-600" />
      case 'rejected':
        return <XCircle className="h-4 w-4 text-red-600" />
      default:
        return <Clock className="h-4 w-4 text-yellow-600" />
    }
  }

  const filteredStudents = students.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesDepartment = filterDepartment === 'all' || student.department === filterDepartment
    return matchesSearch && matchesDepartment
  })

  return (
    <div className="max-w-6xl mx-auto p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Student Placements</h1>
        <p className="mt-2 text-gray-600">Track and manage student placement status</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -mt-2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg 
                  focus:ring-2 focus:ring-blue-100 focus:border-blue-400 outline-none"
              />
            </div>
          </div>

          {/* Department Filter */}
          <div className="flex items-center space-x-3">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterDepartment}
              onChange={(e) => setFilterDepartment(e.target.value)}
              className="p-2 border border-gray-200 rounded-lg focus:ring-2 
                focus:ring-blue-100 focus:border-blue-400 outline-none"
            >
              {departments.map(dept => (
                <option key={dept} value={dept}>
                  {dept === 'all' ? 'All Departments' : dept}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Students List */}
      <div className="space-y-6">
        {filteredStudents.map(student => (
          <div key={student.id} className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-start space-x-4">
              {/* Student Profile */}
              <div className="relative w-16 h-16 flex-shrink-0">
                <Image
                  src={student.profile_image}
                  alt={student.name}
                  fill
                  className="object-cover rounded-full"
                />
              </div>

              {/* Student Details */}
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900">{student.name}</h3>
                <div className="mt-1 grid grid-cols-1 md:grid-cols-3 gap-2 text-sm text-gray-600">
                  <div className="flex items-center">
                    <GraduationCap className="h-4 w-4 mr-1" />
                    {student.department}
                  </div>
                  <div className="flex items-center">
                    <Mail className="h-4 w-4 mr-1" />
                    {student.email}
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 mr-1" />
                    {student.phone}
                  </div>
                </div>

                {/* Placements */}
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Placement Status</h4>
                  <div className="space-y-3">
                    {student.placements.map((placement, index) => (
                      <div key={index} className="flex items-center justify-between 
                        p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Building className="h-4 w-4 text-gray-400" />
                          <div>
                            <div className="font-medium text-gray-900">
                              {placement.company_name}
                            </div>
                            <div className="text-sm text-gray-600">
                              {placement.position}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          {placement.package && (
                            <span className="text-sm font-medium text-gray-900">
                              {placement.package}
                            </span>
                          )}
                          <span className={`flex items-center gap-1 px-2.5 py-0.5 
                            rounded-full text-xs font-medium
                            ${getStatusColor(placement.status)}`}
                          >
                            {getStatusIcon(placement.status)}
                            <span className="capitalize">{placement.status}</span>
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* Empty State */}
        {filteredStudents.length === 0 && (
          <div className="text-center py-12 bg-white rounded-xl shadow-sm">
            <GraduationCap className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No students found</h3>
            <p className="mt-1 text-sm text-gray-500">
              Try adjusting your search or filter criteria
            </p>
          </div>
        )}
      </div>
    </div>
  )
}