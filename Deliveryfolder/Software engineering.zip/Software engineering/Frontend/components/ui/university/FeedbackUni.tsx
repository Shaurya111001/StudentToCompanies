'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { 
  Star, 
  Send, 
  ThumbsUp, 
  Users, 
  Building,
  MessageSquare,
  Briefcase,
  Settings,
  HelpCircle
} from 'lucide-react'

interface FeedbackForm {
  portalUsability: number
  companyEngagement: number
  studentParticipation: number
  placementProcess: number
  supportQuality: number
  overallSatisfaction: number
  challengesFaced: string
  suggestedImprovements: string
  additionalFeatures: string
  recommendationLikelihood: boolean
}

export default function FeedbackUni() {
  const router = useRouter()

  const [feedback, setFeedback] = useState<FeedbackForm>({
    portalUsability: 0,
    companyEngagement: 0,
    studentParticipation: 0,
    placementProcess: 0,
    supportQuality: 0,
    overallSatisfaction: 0,
    challengesFaced: '',
    suggestedImprovements: '',
    additionalFeatures: '',
    recommendationLikelihood: true
  })

  const RatingStars = ({ 
    rating, 
    onRatingChange 
  }: { 
    rating: number
    onRatingChange: (rating: number) => void 
  }) => {
    return (
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => onRatingChange(star)}
            className="focus:outline-none"
          >
            <Star
              className={`h-6 w-6 ${
                star <= rating
                  ? 'fill-yellow-400 text-yellow-400'
                  : 'text-gray-300'
              }`}
            />
          </button>
        ))}
      </div>
    )
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // API call to submit feedback
    console.log('Submitting feedback:', feedback)
    // On success, redirect back
    router.push('/university/profile')
  }

  return (
    <div className="max-w-3xl mx-auto p-8">
      <div className="bg-white rounded-xl shadow-sm p-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">
          University Portal Feedback
        </h1>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Rating Sections */}
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <Settings className="h-4 w-4 mr-2" />
                Portal Usability and Features
              </label>
              <RatingStars
                rating={feedback.portalUsability}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, portalUsability: rating }))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <Building className="h-4 w-4 mr-2" />
                Company Engagement Level
              </label>
              <RatingStars
                rating={feedback.companyEngagement}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, companyEngagement: rating }))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <Users className="h-4 w-4 mr-2" />
                Student Participation and Response
              </label>
              <RatingStars
                rating={feedback.studentParticipation}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, studentParticipation: rating }))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <Briefcase className="h-4 w-4 mr-2" />
                Placement Process Efficiency
              </label>
              <RatingStars
                rating={feedback.placementProcess}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, placementProcess: rating }))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <HelpCircle className="h-4 w-4 mr-2" />
                Support Quality
              </label>
              <RatingStars
                rating={feedback.supportQuality}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, supportQuality: rating }))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <ThumbsUp className="h-4 w-4 mr-2" />
                Overall Satisfaction
              </label>
              <RatingStars
                rating={feedback.overallSatisfaction}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, overallSatisfaction: rating }))
                }
              />
            </div>
          </div>

          {/* Text Feedback Areas */}
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                Challenges Faced
              </label>
              <textarea
                value={feedback.challengesFaced}
                onChange={(e) => setFeedback(prev => ({
                  ...prev,
                  challengesFaced: e.target.value
                }))}
                rows={4}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                  focus:ring-blue-100 focus:border-blue-400 outline-none"
                placeholder="What challenges did you face while using the portal?"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                Suggested Improvements
              </label>
              <textarea
                value={feedback.suggestedImprovements}
                onChange={(e) => setFeedback(prev => ({
                  ...prev,
                  suggestedImprovements: e.target.value
                }))}
                rows={4}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                  focus:ring-blue-100 focus:border-blue-400 outline-none"
                placeholder="How can we improve the portal?"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                Additional Features Needed
              </label>
              <textarea
                value={feedback.additionalFeatures}
                onChange={(e) => setFeedback(prev => ({
                  ...prev,
                  additionalFeatures: e.target.value
                }))}
                rows={4}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                  focus:ring-blue-100 focus:border-blue-400 outline-none"
                placeholder="What additional features would you like to see?"
              />
            </div>
          </div>

          {/* Recommendation */}
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="recommend"
              checked={feedback.recommendationLikelihood}
              onChange={(e) => setFeedback(prev => ({
                ...prev,
                recommendationLikelihood: e.target.checked
              }))}
              className="h-4 w-4 text-blue-500 focus:ring-blue-400 
                border-gray-300 rounded"
            />
            <label htmlFor="recommend" className="text-sm text-gray-700">
              I would recommend this portal to other universities
            </label>
          </div>

          {/* Submit Buttons */}
          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="px-6 py-2 bg-blue-500 text-white rounded-lg 
                hover:bg-blue-600 transition-colors flex items-center"
            >
              <Send className="h-4 w-4 mr-2" />
              Submit Feedback
            </button>
            <button
              type="button"
              onClick={() => router.back()}
              className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg 
                hover:bg-gray-200 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}