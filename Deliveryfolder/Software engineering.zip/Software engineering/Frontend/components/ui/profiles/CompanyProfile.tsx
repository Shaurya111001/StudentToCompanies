'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import axios from 'axios'

interface CompanyData {
  id: number
  company_name: string
  description: string
  logo: string
}

export default function CompanyProfile() {
  const router = useRouter()
  const [companyData, setCompanyData] = useState<CompanyData | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [updatedCompany, setUpdatedCompany] = useState<CompanyData | null>(null)

  useEffect(() => {
    const fetchCompanyData = async () => {
      const token = localStorage.getItem('accessToken')
      const _user = localStorage.getItem("user_id")

      const response = await axios.get(`http://localhost:8000/api/companies/${_user}/`)
      setCompanyData(response.data)
      setUpdatedCompany(response.data)
    }
    fetchCompanyData()
  }, [])

  const handleUpdate = async () => {
    const token = localStorage.getItem('accessToken')
    const _user = localStorage.getItem("user_id")
    try {
      await axios.put(`http://localhost:8000/api/companies/${_user}/`, updatedCompany, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      setCompanyData(updatedCompany)
      alert('Company profile updated successfully!')
      setIsModalOpen(false)
    } catch (error) {
      console.error('Update error:', error)
      alert('Failed to update company profile')
    }
  }

  if (!companyData) return <div>Loading...</div>

  return (
    <div className="max-w-6xl mx-auto p-8">
      <div className="bg-white rounded-xl shadow-sm p-8">
        <div className="flex flex-col md:flex-row gap-12">
          <div className="md:w-1/3">
            <div className="relative aspect-square w-full">
              <Image
                src={companyData.logo}
                alt={`${companyData.company_name} logo`}
                fill
                className="object-contain rounded-lg border-2 border-gray-100 p-4"
              />
            </div>
          </div>

          <div className="md:w-2/3 space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                {companyData.company_name}
              </h1>
              <p className="text-gray-600 leading-relaxed">
                {companyData.description}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-6">
              <button
                onClick={() => setIsModalOpen(true)}
                className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-200"
              >
                Update Profile
              </button>
              <button
                onClick={() => router.push('/company/showjob')}
                className="px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all duration-200"
              >
                Show Created Job
              </button>
              <button
                onClick={() => router.push('/company/createjob')}
                className="px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all duration-200"
              >
                Create New Job
              </button>
            </div>
          </div>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96">
            <h2 className="text-xl font-semibold mb-4">Update Profile</h2>
            <input
              type="text"
              value={updatedCompany?.company_name || ''}
              onChange={(e) => setUpdatedCompany({ ...updatedCompany!, company_name: e.target.value })}
              className="w-full p-2 border rounded mb-3"
              placeholder="Company Name"
            />
            <textarea
              value={updatedCompany?.description || ''}
              onChange={(e) => setUpdatedCompany({ ...updatedCompany!, description: e.target.value })}
              className="w-full p-2 border rounded mb-3"
              placeholder="Company Description"
            />
            <div className="flex justify-end gap-3">
              <button onClick={() => setIsModalOpen(false)} className="px-4 py-2 bg-gray-300 rounded">Cancel</button>
              <button onClick={handleUpdate} className="px-4 py-2 bg-blue-500 text-white rounded">Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
