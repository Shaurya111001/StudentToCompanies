'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { Eye, EyeOff, Pencil } from 'lucide-react'
import axios from 'axios'
// import { useUser } from '../../../app/context/UserContext';

interface UserData {
  email: string
  first_name: string
  last_name: string
  is_active: boolean
  user_type: string
}

interface ProfileData {
  id: number
  university: string
  cv: string | null
  user: UserData
}

export default function StudentProfile() {

  const [isEditing, setIsEditing] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [profileImage, setProfileImage] = useState<string | null>(null)
  const [pdfFile, setPdfFile] = useState<File | null>(null)
  const [profileData, setProfileData] = useState<ProfileData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [studentId, setStudentId] = useState<number>(1) // Replace with actual student ID

  useEffect(() => {
    const fetchStudentData = async () => {
      const token = localStorage.getItem('accessToken')
      var _user = localStorage.getItem("user_id");
      var _usertype = localStorage.getItem("user_type")
      try {
        if (_user) {
          
          const response = await axios.get(`http://localhost:8000/api/students/${_user}/`, {
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          })
          setProfileData(response.data)
          setProfileImage(response.data.profile || '/assets/icons/logo-icon.svg');
        } else {
          setError('User ID is not available.')
        }
      } catch (err) {
        setError('Failed to fetch profile data')
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    fetchStudentData()
  },[isEditing, profileImage, pdfFile])

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file && file.size <= 3 * 1024 * 1024) { // 3MB limit
      const reader = new FileReader()
      reader.onloadend = () => {
        setProfileImage(reader.result as string)
        uploadImage(file) // Call the upload function
      }
      reader.readAsDataURL(file)
    } else {
      alert('Please upload an image smaller than 3MB')
    }
  }

  const uploadImage = async (file: File) => {
    const formData = new FormData()
    formData.append('profile', file)
    const token = localStorage.getItem('accessToken')
    var user_id = localStorage.getItem('user_id')
    console.log(file)

    try {
      const response = await axios.patch(`http://localhost:8000/api/students/${user_id}/`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${token}`
        },
      })
      console.log('Image uploaded successfully:', response.data)
    } catch (error) {
      console.error('Error uploading image:', error)
    }
  }

  const handlePdfUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      try {
        const formData = new FormData()
        formData.append('cv_file', file)
        formData.append('email', profileData?.user.email || '')
        formData.append('university', profileData?.university || '')

        const token = localStorage.getItem('accessToken')
        var user_id = localStorage.getItem('user_id')

        await axios.patch(`http://localhost:8000/api/students/${user_id}/`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
            'Authorization': `Bearer ${token}`
          },
        })
        setPdfFile(file)
        alert('Document uploaded successfully')
      } catch (error) {
        console.error('Upload error:', error)
        alert('Failed to upload document')
      }
    }
  }

  const handleSave = async () => {
    const token = localStorage.getItem('accessToken')
    var user_id = localStorage.getItem('user_id')
    const formData = new FormData();
    formData.append('university', profileData?.university || ''); // Assuming you have a state for updated university
    formData.append('user', JSON.stringify({
        email: profileData?.user.email ||'', // Assuming you have a state for updated email
        first_name: profileData?.user.first_name ||'', // Assuming you have a state for updated first name
        last_name: profileData?.user.last_name ||'', // Assuming you have a state for updated last name
        is_active: true, // or whatever logic you have
        user_type: 'student', // or whatever logic you have
    }));
    console.log(profileData)
    try {
      await axios.put(`http://localhost:8000/api/students/${user_id}/`, formData, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      alert('Profile updated successfully!')
      setIsEditing(false)
    } catch (error) {
      console.error('Update error:', error)
      alert('Failed to update profile')
    }
  }

  const handleCancel = () => {
    setIsEditing(false)
  }

  if (loading) return <div>Loading...</div>
  if (error) return <div>{error}</div>
  if (!profileData) return <div>No profile data available.</div>

  return (
    <div className="max-w-5xl mx-auto p-8 bg-white rounded-xl shadow-sm">
      <h2 className="text-2xl font-semibold text-gray-800 mb-8">Profile Information</h2>
      
      <div className="relative flex flex-col md:flex-row gap-12">
        {/* Profile Image Section */}
        <div className="md:w-72">
          <div className="relative group">
            {profileImage && (
              <Image
                src={profileImage}
                alt="Profile"
                width={256}
                height={256}
                className="rounded-2xl w-72 h-72 object-cover border-2 border-gray-100"
              />
            )}
            <label className="absolute bottom-3 right-3 bg-white/90 p-2.5 rounded-full shadow-lg cursor-pointer hover:bg-gray-50 transition-colors group-hover:scale-105">
              <Pencil className="h-5 w-5 text-gray-700" />
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {/* Profile Details Section */}
        <div className="flex-1 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Object.entries(profileData.user).map(([key, value]) => (
              <div key={key} className="space-y-2">
                <label className="text-sm font-medium text-gray-600 capitalize">
                  {key.replace('_', ' ')}
                </label>
                <div className="relative">
                  {isEditing ? (
                    key === 'password' ? (
                      <div className="relative">
                        <input
                          type={showPassword ? 'text' : 'password'}
                          value={value}
                          onChange={(e) => setProfileData(prev => ({
                            ...prev,
                            user: {
                              ...prev.user,
                              [key]: e.target.value
                            }
                          }))}
                          className="w-full p-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-100 focus:border-blue-400 outline-none transition-all"
                        />
                        <button
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                        >
                          {showPassword ? 
                            <EyeOff className="h-5 w-5" /> : 
                            <Eye className="h-5 w-5" />
                          }
                        </button>
                      </div>
                    ) : (
                      <input
                        type="text"
                        value={value}
                        onChange={(e) => setProfileData(prev => ({
                          ...prev,
                          user: {
                            ...prev.user,
                            [key]: e.target.value
                          }
                        }))}
                        className="w-full p-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-100 focus:border-blue-400 outline-none transition-all"
                      />
                    )
                  ) : (
                    <p className="p-2.5 bg-gray-50 rounded-lg text-gray-700 border border-gray-100">
                      {key === 'password' ? '••••••••' : value}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="pt-4 space-x-4">
            {isEditing ? (
              <>
                <button
                  onClick={handleSave}
                  className="px-6 py-2.5 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium"
                >
                  Save Changes
                </button>
                <button
                  onClick={handleCancel}
                  className="px-6 py-2.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
                >
                  Cancel
                </button>
              </>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="px-6 py-2.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
              >
                Edit Profile
              </button>
            )}
          </div>

          {/* PDF Upload Section */}
          <div className="mt-8 p-6 bg-gray-50 rounded-xl border border-gray-100">
            <h3 className="text-lg font-medium text-gray-800 mb-4">Documents</h3>
            <input
              type="file"
              accept=".pdf"
              onChange={handlePdfUpload}
              className="block w-full text-sm text-gray-500 
                file:mr-4 file:py-2.5 file:px-6 
                file:rounded-lg file:border-0 
                file:text-sm file:font-medium
                file:bg-blue-50 file:text-blue-700 
                hover:file:bg-blue-100
                cursor-pointer"
            />
            {pdfFile && (
              <a
                href={URL.createObjectURL(pdfFile)}
                download={pdfFile.name}
                className="mt-4 inline-flex items-center text-blue-600 hover:text-blue-700 font-medium"
              >
                Download {pdfFile.name}
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}