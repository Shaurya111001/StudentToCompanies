'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import axios from 'axios'

interface UniversityData {
  id: number
  name: string
  logo: string
  location: string
  website: string
  email: string
  phone: string
  description: string
  stats: {
    total_students: number
    placed_students: number
    registered_companies: number
    average_package: string
  }
}

export default function UniversityProfile() {
  const router = useRouter()
  const [universityData, setUniversityData] = useState<UniversityData | null>(null)

  useEffect(() => {
    const fetchUniversityData = async () => {
      const token = localStorage.getItem('accessToken')
      const response = await axios.get('/api/university/1/', { // Replace '1' with the actual university ID
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      setUniversityData(response.data)
    }
    fetchUniversityData()
  }, [])

  const handleUpdate = async () => {
    const token = localStorage.getItem('accessToken')
    try {
      await axios.put(`/api/university/${universityData?.id}/`, universityData, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      alert('University profile updated successfully!')
    } catch (error) {
      console.error('Update error:', error)
      alert('Failed to update university profile')
    }
  }

  if (!universityData) return <div>Loading...</div>

  return (
    <div className="max-w-4xl mx-auto p-8">
      {/* Header Section */}
      <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
        <div className="flex items-start space-x-6">
          <div className="relative w-24 h-24 flex-shrink-0">
            <Image
              src={universityData.logo}
              alt={universityData.name}
              fill
              className="object-contain rounded-lg"
            />
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900">{universityData.name}</h1>
            <p className="mt-4 text-gray-600">{universityData.description}</p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-4">
        <button
          onClick={handleUpdate}
          className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-200"
        >
          Update Profile
        </button>
        <button
          onClick={() => router.push('/university/students')}
          className="px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors duration-200"
        >
          View Students
        </button>
      </div>
    </div>
  )
}