'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter, useSearchParams } from 'next/navigation'
import axios from 'axios'
import { 
  GraduationCap, 
  Mail, 
  Phone, 
  Calendar,
  FileText,
  CheckCircle,
  XCircle
} from 'lucide-react'

interface Application {
  id: number
  student: number
  student_details: {
    user: {
      id: number
      first_name: string
      last_name: string
      email: string
    }
    university: string
    profile_url: string | null
  }
  internship: number
  date_applied: string
  description: string
  status: string
}

interface ConfirmationModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: () => void
  message: string
}

function ConfirmationModal({ isOpen, onClose, onConfirm, message }: ConfirmationModalProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-sm w-full mx-4">
        <p className="text-gray-800 text-lg mb-6">{message}</p>
        <div className="flex space-x-4">
          <button
            onClick={onClose}
            className="flex-1 py-2 px-4 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 
              transition-colors duration-200"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 py-2 px-4 bg-blue-500 text-white rounded hover:bg-blue-600 
              transition-colors duration-200"
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  )
}

// Add new interface for Interview
interface Interview {
  id: number
  application: number
  date_time: string
  location: string
  interview_type: 'online' | 'in_person'
  status: 'scheduled' | 'completed' | 'cancelled' | 'rescheduled'
  notes?: string
}

// Add interview form state
interface InterviewForm {
  date_time: string
  location: string
  interview_type: 'online' | 'in_person'
  notes?: string
}

interface InterviewFormModalProps {
  isOpen: boolean
  onClose: () => void
  interviewForm: InterviewForm
  setInterviewForm: (form: InterviewForm) => void
  onSubmit: () => void
}

function InterviewFormModal({ 
  isOpen, 
  onClose, 
  interviewForm, 
  setInterviewForm,
  onSubmit 
}: InterviewFormModalProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
        <h2 className="text-xl font-semibold mb-4">Schedule Interview</h2>
        <form onSubmit={(e) => {
          e.preventDefault()
          onSubmit()
        }}>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Date and Time</label>
              <input
                type="datetime-local"
                value={interviewForm.date_time}
                onChange={(e) => setInterviewForm({...interviewForm, date_time: e.target.value})}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700">Location</label>
              <input
                type="text"
                value={interviewForm.location}
                onChange={(e) => setInterviewForm({...interviewForm, location: e.target.value})}
                placeholder="Meeting link or physical address"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Interview Type</label>
              <select
                value={interviewForm.interview_type}
                onChange={(e) => setInterviewForm({...interviewForm, interview_type: e.target.value as 'online' | 'in_person'})}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="online">Online</option>
                <option value="in_person">In Person</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Notes</label>
              <textarea
                value={interviewForm.notes}
                onChange={(e) => setInterviewForm({...interviewForm, notes: e.target.value})}
                placeholder="Additional instructions or notes"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                rows={3}
              />
            </div>
          </div>

          <div className="mt-6 flex space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 px-4 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 transition-colors duration-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2 px-4 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors duration-200"
            >
              Schedule
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function SelectStud() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const applicationId = searchParams.get('application')

  // States for managing different stages
  const [application, setApplication] = useState<Application | null>(null)
  const [loading, setLoading] = useState(true)
  const [showInterviewConfirm, setShowInterviewConfirm] = useState(false)
  const [interviewScheduled, setInterviewScheduled] = useState(false)
  const [showAcceptConfirm, setShowAcceptConfirm] = useState(false)
  const [showRejectConfirm, setShowRejectConfirm] = useState(false)
  const [remarks, setRemarks] = useState('')
  const [showInterviewForm, setShowInterviewForm] = useState(false)
  const [interviewForm, setInterviewForm] = useState<InterviewForm>({
    date_time: '',
    location: '',
    interview_type: 'online',
    notes: ''
  })

  useEffect(() => {
    fetchApplicationDetails()
  }, [applicationId])

  const fetchApplicationDetails = async () => {
    try {
      const userId = localStorage.getItem('user_id')
      const response = await axios.get(
        `http://localhost:8000/api/applications/${applicationId}/`,
        {
          params: { user_id: userId }
        }
      )
      setApplication(response.data)
    } catch (error) {
      console.error('Failed to fetch application details:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleStatusUpdate = async (newStatus: string) => {
    try {
      const userId = localStorage.getItem('user_id')
      await axios.patch(
        `http://localhost:8000/api/applications/${applicationId}/`,
        {
          status: newStatus,
          remarks: remarks
        },
        {
          params: { user_id: userId }
        }
      )
      // Refresh application details after update
      fetchApplicationDetails()
    } catch (error) {
      console.error('Failed to update application status:', error)
    }
  }

  const handleScheduleInterview = async () => {
    try {
      const userId = localStorage.getItem('user_id')
      
      // First create the interview
      const interviewResponse = await axios.post(
        'http://localhost:8000/api/interviews/',
        {
          application: applicationId,
          date_time: interviewForm.date_time,
          location: interviewForm.location,
          interview_type: interviewForm.interview_type,
          notes: interviewForm.notes
        },
        {
          params: { user_id: userId }
        }
      )

      // Update application status
      await handleStatusUpdate('under_review')
      
      setInterviewScheduled(true)
      setShowInterviewForm(false)
      setShowInterviewConfirm(false)
    } catch (error) {
      console.error('Failed to schedule interview:', error)
    }
  }

  const handleFinalDecision = (decision: 'accepted' | 'rejected') => {
    handleStatusUpdate(decision)
    if (decision === 'accepted') setShowAcceptConfirm(false)
    if (decision === 'rejected') setShowRejectConfirm(false)
  }

  if (loading || !application) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      {/* Student Profile Section */}
      <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
        <div className="flex items-start space-x-6">
          <div className="relative w-24 h-24">
            <Image
              src={application.student_details.profile_url || '/assets/images/default-avatar.png'}
              alt={`${application.student_details.user.first_name} ${application.student_details.user.last_name}`}
              fill
              className="object-cover rounded-full"
            />
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">
              {application.student_details.user.first_name} {application.student_details.user.last_name}
            </h1>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center text-gray-600">
                <GraduationCap className="h-5 w-5 mr-2" />
                {application.student_details.university}
              </div>
              <div className="flex items-center text-gray-600">
                <Mail className="h-5 w-5 mr-2" />
                {application.student_details.user.email}
              </div>
              <div className="flex items-center text-gray-600">
                <Calendar className="h-5 w-5 mr-2" />
                Applied: {new Date(application.date_applied).toLocaleDateString()}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Application Details */}
      <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Application Details</h2>
        <div className="space-y-6">
          <div>
            <h3 className="text-sm font-medium text-gray-600 mb-2">Description</h3>
            <p className="text-gray-800 whitespace-pre-line">{application.description}</p>
          </div>
        </div>
      </div>

      {/* Action Section */}
      <div className="bg-white rounded-xl shadow-sm p-8">
        {application.status === 'accepted' || application.status === 'rejected' ? (
          <div className="space-y-4">
            <div className={`text-center p-4 rounded-lg ${
              application.status === 'accepted' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
            }`}>
              <div className="text-lg font-medium mb-2">
                Application {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
              </div>
              {remarks && <div className="text-sm">Remarks: {remarks}</div>}
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {application.status !== 'under_review' ? (
              <button
                onClick={() => setShowInterviewForm(true)}
                className="w-full py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 
                  transition-colors duration-200"
              >
                Schedule Interview
              </button>
            ) : (
              <div className="space-y-4">
                <div className="text-center text-green-600 mb-4">
                  Under Review
                </div>
                <div className="space-y-4">
                  <div className="flex space-x-3">
                    <textarea
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      placeholder="Enter remarks..."
                      className="flex-1 p-3 border border-gray-200 rounded-lg focus:ring-2 
                        focus:ring-blue-100 focus:border-blue-400 outline-none"
                      rows={3}
                    />
                  </div>
                  <div className="flex space-x-4">
                    <button
                      onClick={() => setShowAcceptConfirm(true)}
                      className="flex-1 py-3 bg-green-500 text-white rounded-lg 
                        hover:bg-green-600 transition-colors duration-200"
                    >
                      Accept
                    </button>
                    <button
                      onClick={() => setShowRejectConfirm(true)}
                      className="flex-1 py-3 bg-red-500 text-white rounded-lg 
                        hover:bg-red-600 transition-colors duration-200"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Update InterviewFormModal usage */}
      <InterviewFormModal
        isOpen={showInterviewForm}
        onClose={() => setShowInterviewForm(false)}
        interviewForm={interviewForm}
        setInterviewForm={setInterviewForm}
        onSubmit={handleScheduleInterview}
      />
      
      {/* Keep other confirmation modals */}
      <ConfirmationModal
        isOpen={showAcceptConfirm}
        onClose={() => setShowAcceptConfirm(false)}
        onConfirm={() => handleFinalDecision('accepted')}
        message="Are you sure you want to accept this application?"
      />
      <ConfirmationModal
        isOpen={showRejectConfirm}
        onClose={() => setShowRejectConfirm(false)}
        onConfirm={() => handleFinalDecision('rejected')}
        message="Are you sure you want to reject this application?"
      />
    </div>
  )
}