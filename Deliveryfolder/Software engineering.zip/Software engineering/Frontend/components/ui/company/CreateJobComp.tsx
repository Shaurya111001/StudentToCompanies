'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import axios from 'axios'
import { Calendar, Briefcase, FileText, Tags, DollarSign } from 'lucide-react'

interface InternshipFormData {
  company: string // This will be the company ID
  title: string
  description: string
  skills_required: string
  is_paid: boolean
  start_date: string
  end_date: string
}

export default function CreateJobComp() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState<InternshipFormData>({
    company: '', // Will be set from localStorage
    title: '',
    description: '',
    skills_required: '',
    is_paid: false,
    start_date: '',
    end_date: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const token = localStorage.getItem("accessToken")
      const userId = localStorage.getItem("user_id")
      const userType = localStorage.getItem("user_type")

      // Ensure we have the necessary data
      if (!token || !userId || userType !== 'company') {
        throw new Error('Unauthorized: Only company users can create internships')
      }
      
      // Set the company ID in the form data
      const dataToSend = {
        ...formData,
        company: userId // Assuming the company ID is the same as the user ID
      }
      console.log(dataToSend)
      const response = await axios.post(
        'http://localhost:8000/api/internships/', 
        dataToSend,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      )

      alert('Internship created successfully!')
      router.push('/company/showjob')
    } catch (error: any) {
      console.error('Failed to create internship:', error)
      alert(error.response?.data?.error || 'Failed to create internship')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-3xl mx-auto p-8">
      <div className="flex items-center text-sm text-gray-500 mb-6">
        <button 
          onClick={() => router.push('/company/showjob')}
          className="hover:text-blue-500 transition-colors"
        >
          Internships
        </button>
        <span className="mx-2">→</span>
        <span className="text-gray-900">Create New Internship</span>
      </div>
      <div className="bg-white rounded-xl shadow-sm p-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">Create New Internship Posting</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Job Title */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Briefcase className="h-4 w-4 mr-2" />
              Internship Title
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                focus:ring-blue-100 focus:border-blue-400 outline-none transition-all"
              placeholder="e.g., Software Developer Intern"
            />
          </div>

          {/* Description */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <FileText className="h-4 w-4 mr-2" />
              Description
            </label>
            <textarea
              required
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={4}
              className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                focus:ring-blue-100 focus:border-blue-400 outline-none transition-all"
              placeholder="Describe the internship role, responsibilities, and requirements..."
            />
          </div>

          {/* Skills Required */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Tags className="h-4 w-4 mr-2" />
              Required Skills
            </label>
            <input
              type="text"
              required
              value={formData.skills_required}
              onChange={(e) => setFormData({ ...formData, skills_required: e.target.value })}
              className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                focus:ring-blue-100 focus:border-blue-400 outline-none transition-all"
              placeholder="e.g., React, Node.js, Python"
            />
          </div>

          {/* Dates */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                <Calendar className="h-4 w-4 mr-2" />
                Start Date
              </label>
              <input
                type="date"
                required
                value={formData.start_date}
                onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                  focus:ring-blue-100 focus:border-blue-400 outline-none transition-all"
              />
            </div>
            <div>
              <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                <Calendar className="h-4 w-4 mr-2" />
                End Date
              </label>
              <input
                type="date"
                required
                value={formData.end_date}
                onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                  focus:ring-blue-100 focus:border-blue-400 outline-none transition-all"
              />
            </div>
          </div>

          {/* Payment Status */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <DollarSign className="h-4 w-4 mr-2" />
              Payment Status
            </label>
            <select
              value={formData.is_paid.toString()}
              onChange={(e) => setFormData({ ...formData, is_paid: e.target.value === 'true' })}
              className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                focus:ring-blue-100 focus:border-blue-400 outline-none transition-all"
            >
              <option value="true">Paid Position</option>
              <option value="false">Unpaid Position</option>
            </select>
          </div>

          {/* Submit Button */}
          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              disabled={loading}
              className={`px-6 py-3 bg-blue-500 text-white rounded-lg 
                transition-colors flex items-center justify-center
                ${loading ? 'bg-blue-400 cursor-not-allowed' : 'hover:bg-blue-600'}`}
            >
              {loading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              ) : (
                'Create Internship'
              )}
            </button>
            <button
              type="button"
              onClick={() => router.push('/company/showjob')}
              className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg 
                hover:bg-gray-200 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
} 