'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter, useSearchParams } from 'next/navigation'
import axios from 'axios'
import { 
  GraduationCap, 
  Mail, 
  Phone, 
  FileText,
  ChevronRight,
  Building
} from 'lucide-react'

interface User {
  id: number
  first_name: string
  last_name: string
  email: string
}

interface StudentDetails {
  user: {
    first_name: string
    last_name: string
    email: string
  }
  phone_number: string
  university: string
  profile_image: string | null
}

interface Application {
  id: number
  student: {
    id: number
    user: {
      first_name: string
      last_name: string
      email: string
    }
  }
  date_applied: string
  status: string
  description: string
  interviews: Array<{
    id: number
    date_time: string
    location: string
    interview_type: string
    status: string
    notes: string
  }>
}

interface Job {
  id: number
  title: string
  description: string
  skills_required: string
  is_paid: boolean
  start_date: string
  end_date: string
}

interface Student {
  id: number
  user: {
    first_name: string
    last_name: string
    email: string
  }
  resume: string
  status: string
  application_date: string
}

const StudentListJob = () => {
  const router = useRouter()
  const searchParams = useSearchParams()
  const jobId = searchParams.get('id')

  const [job, setJob] = useState<Job | null>(null)
  const [applications, setApplications] = useState<Application[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [applicants, setApplicants] = useState<Student[]>([])

  useEffect(() => {
    console.log('StudentListJob params:', params); // Debug log

    if (!params?.id) {
      console.error('No internship ID provided');
      setError('No internship ID provided');
      setLoading(false);
      return;
    }

    const fetchApplications = async () => {
      try {
        const token = localStorage.getItem('accessToken')
        const userId = localStorage.getItem('user_id')
        
        if (!token || !userId) {
          setError('Authentication credentials not found')
          router.push('/login')
          return
        }

        console.log(`Fetching applications for internship ID: ${params.id}`); // Debug log

        const response = await axios.get(
          `http://localhost:8000/api/internships/${params.id}/applications/`,
          {
            headers: {
              'Authorization': `Token ${token}`
            },
            params: {
              user_id: userId
            }
          }
        )

        console.log('API Response:', response.data); // Debug log
        setApplications(response.data)
        setLoading(false)
      } catch (error) {
        console.error('Error fetching applications:', error);
        if (axios.isAxiosError(error)) {
          const errorMessage = error.response?.data?.error || error.message;
          console.error('Error details:', errorMessage);
          setError(`Failed to fetch applications: ${errorMessage}`);
        } else {
          setError('An unexpected error occurred');
        }
        setLoading(false)
      }
    }

    fetchApplications()
  }, [params?.id, router])

  useEffect(() => {
    if (jobId) {
      fetchJobDetails()
    }
  }, [jobId])

  useEffect(() => {
    const fetchApplicants = async () => {
      try {
        const token = localStorage.getItem('accessToken')
        if (!token) {
          setError('Authentication credentials not found')
          router.push('/login')
          return
        }

        const response = await axios.get(
          `http://localhost:8000/api/internships/${jobId}/applications/`,
          {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          }
        )

        setApplicants(response.data)
        console.log(response.data)
        setLoading(false)
      } catch (error) {
        console.error('Error fetching applicants:', error)
        if (axios.isAxiosError(error) && error.response?.status === 401) {
          setError('Session expired. Please login again.')
          router.push('/login')
        } else {
          setError('Failed to fetch applicants')
        }
        setLoading(false)
      }
    }

    fetchApplicants()
  }, [jobId, router])

  const fetchJobDetails = async () => {
    try {
      const response = await axios.get(`http://localhost:8000/api/internships/${jobId}/`)
      setJob(response.data)
      console.log(response.data)
    } catch (error) {
      console.error('Failed to fetch job details:', error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'applied':
        return 'text-blue-600'
      case 'under_review':
        return 'text-yellow-600'
      case 'accepted':
        return 'text-green-600'
      case 'rejected':
        return 'text-red-600'
      default:
        return 'text-gray-600'
    }
  }

  const formatStatus = (status: string) => {
    return status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center p-4">
        <p className="text-red-500">Error: {error}</p>
        <button 
          onClick={() => router.push('/company/dashboard')}
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Return to Dashboard
        </button>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto p-8">
      {/* Job Header */}
      {job && (
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{job.title}</h1>
              <div className="flex items-center mt-2 text-gray-600">
                <Building className="h-4 w-4 mr-2" />
                <span>
                  {job.description.substring(0, 100)}
                  {job.description.length > 100 ? '...' : ''}
                </span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-blue-600">{applications.length}</div>
              <div className="text-sm text-gray-600">Total Applicants</div>
            </div>
          </div>
          {/* Additional Job Details */}
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="text-sm text-gray-600">
              <span className="font-medium">Skills Required:</span> {job.skills_required}
            </div>
            <div className="text-sm text-gray-600">
              <span className="font-medium">Type:</span> {job.is_paid ? 'Paid' : 'Unpaid'}
            </div>
            <div className="text-sm text-gray-600">
              <span className="font-medium">Duration:</span> {new Date(job.start_date).toLocaleDateString()} - {new Date(job.end_date).toLocaleDateString()}
            </div>
          </div>
        </div>
      )}

      {/* Applications List */}
      <div className="space-y-4">
        {applications.map((application) => (
          <div 
            key={application.id}
            onClick={() => router.push(`/company/selectstud?application=${application.id}`)}
            className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow duration-200 cursor-pointer"
          >
            <div className="flex items-start justify-between">
              {/* Student Info */}
              <div className="flex items-start space-x-4">
                <div className="relative w-16 h-16 flex-shrink-0">
                  <Image
                    src={application.student.user.profile_image || '/assets/images/default-avatar.png'}
                    alt={`${application.student.user.first_name || ''} ${application.student.user.last_name || ''}`}
                    fill
                    className="object-cover rounded-full"
                  />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">
                    {application.student.user.first_name} {application.student.user.last_name}
                  </h2>
                  <div className="mt-2 space-y-1">
                    <div className="flex items-center text-sm text-gray-600">
                      <GraduationCap className="h-4 w-4 mr-2" />
                      {application.student.user.university}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Mail className="h-4 w-4 mr-2" />
                      {application.student.user.email}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Phone className="h-4 w-4 mr-2" />
                      {application.student.user.phone_number}
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Side Info */}
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <div className="text-sm text-gray-500">Applied</div>
                  <div className="text-sm font-medium text-gray-900">
                    {new Date(application.date_applied).toLocaleDateString()}
                  </div>
                  <div className={`
                    mt-2 px-3 py-1 rounded-full text-xs font-medium
                    ${getStatusColor(application.status)}
                  `}>
                    {formatStatus(application.status)}
                  </div>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* No Applications State */}
      {applications.length === 0 && (
        <div className="text-center py-12">
          <FileText className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-4 text-lg font-medium text-gray-900">No applications yet</h3>
          <p className="mt-2 text-gray-500">Applications for this position will appear here.</p>
        </div>
      )}

      <div className="mt-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Applicants List</h2>
        {applicants.length === 0 ? (
          <div className="text-center text-gray-500 p-4">
            No applications received yet.
          </div>
        ) : (
          <div className="grid gap-4">
            {applicants.map((applicant) => (
              <div
                key={applicant.id}
                className="bg-white p-6 rounded-lg shadow-md"
              >
                <h3 className="text-xl font-semibold text-gray-800 mb-2">
                  {applicant.user.first_name} {applicant.user.last_name}
                </h3>
                <p className="text-gray-600 mb-2">
                  Email: {applicant.user.email}
                </p>
                <p className="text-gray-600 mb-2">
                  Status: <span className="font-semibold">{applicant.status}</span>
                </p>
                <p className="text-gray-600 mb-2">
                  Applied: {new Date(applicant.application_date).toLocaleDateString()}
                </p>
                {applicant.resume && (
                  <a
                    href={applicant.resume}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:text-blue-600"
                  >
                    View Resume
                  </a>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default StudentListJob