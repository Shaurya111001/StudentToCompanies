'use client'
// import React, { useRef, useEffect, useState } from 'react';
// import { Canvas, useFrame } from '@react-three/fiber';
// import { useGLTF } from '@react-three/drei';
// import * as THREE from 'three';

// function Model3d({ scrollProgress }) {
//   const hat = useRef();
//   const { scene } = useGLTF('/models/graduation_hat.glb');

//   useEffect(() => {
//     if (scene) {
//       scene.traverse((child) => {
//         if (child instanceof THREE.Mesh) {
//           child.castShadow = true;
//           child.receiveShadow = true;
//         }
//       });
//     }
//   }, [scene]);

//   useFrame(() => {
//     if (scene) {
//       scene.position.z = -5 + scrollProgress * 10;
//       scene.rotation.y = scrollProgress * 2 * Math.PI;
//       scene.scale.set(1 + scrollProgress * 0.5, 1 + scrollProgress * 0.5, 1 + scrollProgress * 0.5);
//     }
//   });

//   return <primitive ref={hat} object={scene} />;
// }

// export default function Model({ scrollProgress }) {
//   return (
//     <Canvas style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', zIndex: -1, pointerEvents: 'none' }}>
//       <ambientLight intensity={0.5} />
//       <directionalLight position={[1, 1, 1]} intensity={0.8} />
//       <Model3d scrollProgress={scrollProgress} />
//     </Canvas>
//   );
// }

// app/test-page.tsx
// 'use client'; // Crucial: Mark as client component

import { Canvas } from '@react-three/fiber';
import React from 'react';

export default function Model() {
  return (
    <Canvas>
      <mesh>
        <boxGeometry />
        <meshStandardMaterial color="red" />
      </mesh>
    </Canvas>
  );
}