import CompanyProfile from '@/components/ui/profiles/CompanyProfile'

export default function CreateJobPage() {
  return (
    <main className="w-full h-screen">
      <CompanyProfile/>
    </main>
  )
} 