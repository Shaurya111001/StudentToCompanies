import StudentListJob from '@/components/ui/company/StudentListJob'

export default function StudentListJobPage({ params }: { params: string  }) {
  console.log('Page params:', params); // Debug log
  
  if (!params) {
    return <div>Error: No internship ID provided</div>;
  }

  return (
    <main className="w-full h-screen">
      <StudentListJob params={params} />
    </main>
  )
} 
