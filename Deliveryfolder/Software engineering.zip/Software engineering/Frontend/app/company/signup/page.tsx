import CompanySignupForm from '@/components/ui/company/SignupForm'

export default function SignupPage() {
  return (
    <main className="w-full h-screen">
      <CompanySignupForm />
    </main>
  )
}
