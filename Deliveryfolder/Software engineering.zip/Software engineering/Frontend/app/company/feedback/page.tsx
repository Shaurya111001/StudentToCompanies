import FeedBackComp from '@/components/ui/company/FeedBackComp'

export default function FeedBackCompPage() {
  return (
    <main className="w-full h-screen">
      <FeedBackComp />
    </main>
  )
} 