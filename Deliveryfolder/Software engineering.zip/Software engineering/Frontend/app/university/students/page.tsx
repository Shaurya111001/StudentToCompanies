import UniversityStudent from '@/components/ui/university/UniversityStudent'

export default function UniversityStudentPage() {
  return (
    <main className="w-full h-screen">
      <UniversityStudent />
    </main>
  )
}
