import FeedbackUni from '@/components/ui/university/FeedbackUni'

export default function FeedbackUniPage() {
  return (
    <main className="w-full h-screen">
      <FeedbackUni />
    </main>
  )
}
