import UniversityProfile from '@/components/ui/profiles/UniversityProfile'

export default function UniversityStudentPage() {
  return (
    <main className="w-full h-screen">
      <UniversityProfile />
    </main>
  )
}
