import LoginForm from '@/components/ui/LoginForm'

export default function LoginPage() {
  return (
    <main className="w-full h-screen">
      <LoginForm />
    </main>
  )
}
