'use client'
import { useState, useEffect } from "react";
import axios from "axios";
import Link from 'next/link';
import { ArrowRight, Briefcase, Search, Users, Star, CheckCircle, Building2, GraduationCap, Menu, X } from 'lucide-react';

import Model from '@/components/ui/Model'




export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [feedback, setFeedback] = useState([]);
  const [scrollProgress, setScrollProgress] = useState(0);


  useEffect(() => {
      const fetchFeedback = async () => {
          try {
              const response = await axios.get('http://127.0.0.1:8000/api/feedback/');
              setFeedback(response.data);
          } catch (error) {
              console.error('Error fetching feedback:', error);
          }
      };

      fetchFeedback();
  }, []);
  return (

    <div className="min-h-screen bg-white">
      {/* Navigation */}

      <nav className="bg-white border-b">
        <div className="container mx-auto px-6">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <span className="text-2xl font-bold text-blue-600">S&C</span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-600 hover:text-blue-600 transition">Features</a>
              <a href="#how-it-works" className="text-gray-600 hover:text-blue-600 transition">How It Works</a>
              <a href="#testimonials" className="text-gray-600 hover:text-blue-600 transition">Success Stories</a>
              <Link href="/login">
                <button className="text-gray-600 hover:text-blue-600 transition">Sign In</button>
              </Link>
              <Link href="/student/signup">
              <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
                Get Started
              </button>
              </Link>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-600 hover:text-blue-600 transition"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4">
              <div className="flex flex-col space-y-4">
                <a href="#features" className="text-gray-600 hover:text-blue-600 transition">Features</a>
                <a href="#how-it-works" className="text-gray-600 hover:text-blue-600 transition">How It Works</a>
                <a href="#testimonials" className="text-gray-600 hover:text-blue-600 transition">Success Stories</a>
                <Link href="/login">
                  <button className="text-gray-600 hover:text-blue-600 transition text-left">Sign In</button>
                </Link>
                <Link href="/student/signup">
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition w-full">
                  Get Started
                </button>
                </Link>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-700 min-h-[80vh] flex items-center text-white">
        <div className="container mx-auto px-6 py-32">
          <div className="flex flex-col lg:flex-row items-center justify-between">
            <div className="lg:w-1/2 mb-10 lg:mb-0">
              <h1 className="text-4xl lg:text-5xl font-bold mb-6">
                Connect Your Future with the Perfect Internship
              </h1>
              <p className="text-xl mb-8 text-blue-100">
                Bringing together talented students and leading companies for meaningful internship opportunities
              </p>
              <div className="flex gap-4">
              <Link href="/student/signup">
                <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition">
                  For Students
                </button>
                </Link>
                <Link href="/company/signup">
                <button className="bg-transparent border-2 border-white px-8 py-3 rounded-lg font-semibold hover:bg-white/10 transition">
                  For Companies
                </button>
                </Link>
              </div>
            </div>
            <div className="lg:w-1/2">
              <div className="bg-white/10 p-8 rounded-xl backdrop-blur-sm">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/20 p-4 rounded-lg text-center">
                    <GraduationCap className="w-8 h-8 mx-auto mb-2" />
                    <p>10,000+ Students</p>
                  </div>
                  <div className="bg-white/20 p-4 rounded-lg text-center">
                    <Building2 className="w-8 h-8 mx-auto mb-2" />
                    <p>500+ Companies</p>
                  </div>
                  <div className="bg-white/20 p-4 rounded-lg text-center">
                    <Briefcase className="w-8 h-8 mx-auto mb-2" />
                    <p>2,000+ Internships</p>
                  </div>
                  <div className="bg-white/20 p-4 rounded-lg text-center">
                    <CheckCircle className="w-8 h-8 mx-auto mb-2" />
                    <p>95% Success Rate</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50" >
        <div className="container mx-auto px-6 text-black">
          <h2 className="text-3xl font-bold text-center mb-16">Platform Features</h2>
          <div className="grid md:grid-cols-2 gap-12">
            {/* Student Features */}
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center mb-6">
                <GraduationCap className="w-8 h-8 text-blue-600 mr-4" />
                <h3 className="text-2xl font-semibold">For Students</h3>
              </div>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-1" />
                  <span>Build a professional profile showcasing your skills and achievements</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-1" />
                  <span>Get matched with relevant internship opportunities using AI</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-1" />
                  <span>Track applications and communicate directly with companies</span>
                </li>
              </ul>
            </div>

            {/* Company Features */}
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center mb-6">
                <Building2 className="w-8 h-8 text-blue-600 mr-4" />
                <h3 className="text-2xl font-semibold">For Companies</h3>
              </div>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-1" />
                  <span>Post and manage internship opportunities efficiently</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-1" />
                  <span>Access a curated pool of talented and motivated students</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-1" />
                  <span>Advanced filtering and AI-powered candidate matching</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20">
        <div className="container mx-auto px-6 text-black">
          <h2 className="text-3xl font-bold text-center mb-16">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">1. Create Profile</h3>
              <p className="text-gray-600">Sign up and build your professional profile in minutes</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">2. Find Matches</h3>
              <p className="text-gray-600">Browse opportunities or let our AI find perfect matches</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Star className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">3. Connect</h3>
              <p className="text-gray-600">Apply to positions and start your journey to success</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6 text-black">
          <h2 className="text-3xl font-bold text-center mb-16">Success Stories</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {feedback.map((item) => (
                        <div key={item.id} className="bg-white p-6 rounded-xl shadow-sm">
                            <div className="flex items-center mb-4">
                                <div className="ml-4">
                                    <h4 className="font-semibold">{item.user}</h4>
                                </div>
                            </div>
                            <p className="text-gray-600">"{item.message}"</p>
                        </div>
                    ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 text-blue-100">Join thousands of students and companies already on the platform</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/login">
              <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition flex items-center justify-center">
                Sign Up as Student
                <ArrowRight className="ml-2 w-5 h-5" />
              </button>
            </Link>
            <Link href="/university/register">
              <button className="bg-transparent border-2 border-white px-8 py-3 rounded-lg font-semibold hover:bg-white/10 transition flex items-center justify-center">
                Register As a University
                <ArrowRight className="ml-2 w-5 h-5" />
              </button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}


