import InterviewRes from '@/components/ui/student/InterviewRes'
export default function InterviewPage() {
  return (
    <main className="w-full h-screen">
      <InterviewRes />
    </main>
  )
} 