"use client";
import JobStatus from '@/components/ui/student/JobStatus'
import { useParams } from 'next/navigation'

export default function JobStatusPage() {
  const { id } = useParams()

  return (
    <main className="w-full h-screen">
      <JobStatus applicationId={id} />
    </main>
  )
} 