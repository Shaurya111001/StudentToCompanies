import StudentSignupForm from '@/components/ui/student/SignupForm'

export default function SignupPage() {
  return (
    <main className="w-full h-screen bg-gray-50">
      <StudentSignupForm />
    </main>
  )
}
