import FeedbackStud from '@/components/ui/student/FeedbackStud'
export default function FeedbackStudPage() {
  return (
    <main className="w-full h-screen">
      <FeedbackStud />
    </main>
  )
} 