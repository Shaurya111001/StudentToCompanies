import JobList from '@/components/ui/student/JobList'
export default function JobListPage() {
  return (
    <main className="w-full h-screen">
      <JobList/>
    </main>
  )
} 