import UniversityRegistration from '@/components/ui/university/UniversityRegistration'

export default function UniversityStudentPage() {
  return (
    <main className="w-full h-screen">
      <UniversityRegistration />
    </main>
  )
}
