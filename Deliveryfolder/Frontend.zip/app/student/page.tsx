import StudentProfile from '@/components/ui/profiles/StudentProfile'
export default function ExploreJobPage() {
  return (
    <main className="w-full h-screen">
      <StudentProfile />
    </main>
  )
} 