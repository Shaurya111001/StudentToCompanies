// import CreateJobComp from '@/components/ui/company/CreateJobComp'

import ExploreJobs from '@/components/ui/student/ExploreJobs'
export default function ExploreJobPage() {
  return (
    <main className="w-full h-screen">
      <ExploreJobs />
    </main>
  )
} 