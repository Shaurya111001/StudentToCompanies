// import CreateJobComp from '@/components/ui/company/CreateJobComp'
import ApplyJob from '@/components/ui/student/ApplyJob'
export default function ApplyJobPage() {
  return (
    <main className="w-full h-screen">
      <ApplyJob />
    </main>
  )
} 