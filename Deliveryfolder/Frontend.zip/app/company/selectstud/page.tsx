import SelectStud from '@/components/ui/company/SelectStud'

export default function SelectStudPage() {
  return (
    <main className="w-full h-screen">
      <SelectStud />
    </main>
  )
} 