import CreateJobComp from '@/components/ui/company/CreateJobComp'

export default function CreateJobPage() {
  return (
    <main className="w-full h-screen">
      <CreateJobComp />
    </main>
  )
} 