import ShowJobsComp from '@/components/ui/company/ShowJobsComp'

export default function ShowJobPage() {
  return (
    <main className="w-full h-screen">
      <ShowJobsComp />
    </main>
  )
} 