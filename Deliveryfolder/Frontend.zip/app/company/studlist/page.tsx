import StudentListJob from '@/components/ui/company/StudentListJob'

export default function StudentListJobPage() {
  return (
    <main className="w-full h-screen">
      <StudentListJob />
    </main>
  )
} 