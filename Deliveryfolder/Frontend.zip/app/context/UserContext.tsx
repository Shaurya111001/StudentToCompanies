// app/context/UserContext.tsx
'use client'; // Required for client-side functionality

import React, { createContext, useContext, useState, ReactNode } from 'react';

// Define the shape of the user data
interface User {
    id: number | null;
    type: string | null;
}

// Create the context with a default value of null
const UserContext = createContext<{
    user: User;
    setUser: React.Dispatch<React.SetStateAction<User>>;
} | null>(null);

// Create the UserProvider component
export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User>({ id: null, type: null }); // Initial state

    return (
        <UserContext.Provider value={{ user, setUser }}>
            {children}
        </UserContext.Provider>
    );
};

// Custom hook to use the UserContext
export const useUser = () => {
    const context = useContext(UserContext);
    if (!context) {
        throw new Error('useUser must be used within a UserProvider');
    }
    return context;
};
