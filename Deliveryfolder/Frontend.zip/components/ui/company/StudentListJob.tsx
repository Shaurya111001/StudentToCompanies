'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter, useSearchParams } from 'next/navigation'
import axios from 'axios'
import { 
  GraduationCap, 
  Mail, 
  Phone, 
  FileText,
  ChevronRight,
  Building,
  Calendar,
  DollarSign
} from 'lucide-react'


interface Company {
  id: number
  user: number
  company_name: string
  logo: string | null
  description: string
}

interface Internship {
  id: number
  company: Company
  title: string
  description: string
  skills_required: string
  is_paid: boolean
  start_date: string
  end_date: string
}

interface Application {
  id: number
  date_applied: string
  description: string
  internship: Internship
  status: string
  student: number  // This is just the ID
  interviews: Array<{
    id: number
    date_time: string
    location: string
    interview_type: string
    notes: string
  }>
}

interface Student {
  id: number
  user: {
    first_name: string
    last_name: string
    email: string
  }
  resume: string
  status: string
  application_date: string
}

const StudentListJob = () => {
  const router = useRouter()
  const searchParams = useSearchParams()
  const jobId = searchParams.get('id')

  const [job, setJob] = useState<Internship | null>(null)
  const [applications, setApplications] = useState<Application[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [applicants, setApplicants] = useState<Student[]>([])

  useEffect(() => {
    console.log('StudentListJob jobId:', jobId); // Debug log

    if (!jobId) {
      console.error('No internship ID provided');
      setError('No internship ID provided');
      setLoading(false);
      return;
    }

    const fetchData = async () => {
      try {
        const token = localStorage.getItem('accessToken')
        const userId = localStorage.getItem('user_id')
        
        if (!token || !userId) {
          setError('Authentication required')
          router.push('/login')
          return
        }

        // Fetch applications with user_id
        const applicationsResponse = await axios.get(
          `http://localhost:8000/api/internships/${jobId}/applications/`,
          {
            headers: { 'Authorization': `Bearer ${token}` },
            params: {
              user_id: userId
            }
          }
        )
        
        console.log('Applications Response:', applicationsResponse.data)
        setApplications(applicationsResponse.data)
        
        // Set job from the first application's internship data
        if (applicationsResponse.data.length > 0) {
          setJob(applicationsResponse.data[0].internship)
        }else{
          setError('No applications found')
          // router.push('/company/showjob')
        }

      } catch (error) {
        console.error('Error fetching data:', error)
        if (axios.isAxiosError(error)) {
          setError(error.response?.data?.message || 'Failed to load data')
        } else {
          setError('Failed to load data')
        }
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [jobId, router])


  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'applied':
        return 'text-blue-600'
      case 'under_review':
        return 'text-yellow-600'
      case 'accepted':
        return 'text-green-600'
      case 'rejected':
        return 'text-red-600'
      default:
        return 'text-gray-600'
    }
  }

  const formatStatus = (status: string) => {
    return status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center p-4">
        <p className="text-red-500">Error: {error}</p>
        <button 
          onClick={() => router.push('/company/showjob')}
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Return to Dashboard
        </button>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto p-8">
      {/* Job Header */}
      {job && (
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{job.title}</h1>
              <div className="mt-2 text-gray-600">
                <p className="font-medium">{job.company.company_name}</p>
                <p className="mt-1">{job.description}</p>
                <div className="mt-4 flex gap-4 text-sm">
                  <span className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    {new Date(job.start_date).toLocaleDateString()} - {new Date(job.end_date).toLocaleDateString()}
                  </span>
                  <span className="flex items-center">
                    <DollarSign className="h-4 w-4 mr-1" />
                    {job.is_paid ? 'Paid' : 'Unpaid'}
                  </span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-blue-600">{applications.length}</div>
              <div className="text-sm text-gray-600">Total Applicants</div>
            </div>
          </div>
        </div>
      )}

      {/* Applications List */}
      <div className="space-y-4">
        {applications.map((application) => (
          <div 
            key={application.id}
            onClick={() => router.push(`/company/selectstud?application=${application.id}`)}
            className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow duration-200 cursor-pointer"
          >
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">
                  Student ID: {application.student}
                </h2>
                <div className="mt-2 space-y-1">
                  <p className="text-sm text-gray-600">
                    Applied: {new Date(application.date_applied).toLocaleDateString()}
                  </p>
                  <p className="text-sm text-gray-600">
                    Description: {application.description}
                  </p>
                  <div className={`mt-2 inline-block px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(application.status)}`}>
                    {formatStatus(application.status)}
                  </div>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-gray-400" />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default StudentListJob