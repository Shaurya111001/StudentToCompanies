'use client'
import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Star, Send } from 'lucide-react'
import axios from 'axios';

interface FeedbackForm {
  technicalSkills: number
  communicationSkills: number
  problemSolving: number
  culturalFit: number
  overallRating: number
  strengthsAndWeaknesses: string
  improvementAreas: string
  additionalComments: string
  message: string
}

export default function FeedbackComp() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const applicationId = searchParams.get('application')

  const [feedback, setFeedback] = useState<FeedbackForm>({
    technicalSkills: 0,
    communicationSkills: 0,
    problemSolving: 0,
    culturalFit: 0,
    overallRating: 0,
    strengthsAndWeaknesses: '',
    improvementAreas: '',
    additionalComments: '',
    message: ''
  })

  const RatingStars = ({ 
    rating, 
    onRatingChange 
  }: { 
    rating: number
    onRatingChange: (rating: number) => void 
  }) => {
    return (
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => onRatingChange(star)}
            className="focus:outline-none"
          >
            <Star
              className={`h-6 w-6 ${
                star <= rating
                  ? 'fill-yellow-400 text-yellow-400'
                  : 'text-gray-300'
              }`}
            />
          </button>
        ))}
      </div>
    )
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // API call to submit feedback
    try {
      const userId = localStorage.getItem('user_id'); // Retrieve user ID from localStorage
      if (!userId) {
        console.error("User ID is not found in localStorage.");
        return;
      }

      const response = await axios.post('http://localhost:8000/api/feedback/', {
        user: userId, // Include user ID in the feedback data
        ...feedback, // Spread the feedback data
        application: applicationId // Include application ID if needed
      });

      console.log('Feedback submitted successfully:', response.data);
      // On success, redirect back
      router.push('/company/studlist');
    } catch (error) {
      console.error('Error submitting feedback:', error);
    }
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      <div className="bg-white rounded-xl shadow-sm p-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">
          Candidate Feedback Form
        </h1>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Rating Sections */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                Technical Skills
              </label>
              <RatingStars
                rating={feedback.technicalSkills}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, technicalSkills: rating }))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                Communication Skills
              </label>
              <RatingStars
                rating={feedback.communicationSkills}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, communicationSkills: rating }))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                Problem Solving
              </label>
              <RatingStars
                rating={feedback.problemSolving}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, problemSolving: rating }))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                Cultural Fit
              </label>
              <RatingStars
                rating={feedback.culturalFit}
                onRatingChange={(rating) => 
                  setFeedback(prev => ({ ...prev, culturalFit: rating }))
                }
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">
              Overall Rating
            </label>
            <RatingStars
              rating={feedback.overallRating}
              onRatingChange={(rating) => 
                setFeedback(prev => ({ ...prev, overallRating: rating }))
              }
            />
          </div>

          {/* Text Areas */}
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                Strengths and Weaknesses
              </label>
              <textarea
                value={feedback.strengthsAndWeaknesses}
                onChange={(e) => setFeedback(prev => ({
                  ...prev,
                  strengthsAndWeaknesses: e.target.value
                }))}
                rows={4}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                  focus:ring-blue-100 focus:border-blue-400 outline-none"
                placeholder="Please describe the candidate's key strengths and areas of weakness..."
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                Areas for Improvement
              </label>
              <textarea
                value={feedback.improvementAreas}
                onChange={(e) => setFeedback(prev => ({
                  ...prev,
                  improvementAreas: e.target.value
                }))}
                rows={4}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                  focus:ring-blue-100 focus:border-blue-400 outline-none"
                placeholder="Suggest specific areas where the candidate could improve..."
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                Additional Comments
              </label>
              <textarea
                value={feedback.additionalComments}
                onChange={(e) => setFeedback(prev => ({
                  ...prev,
                  additionalComments: e.target.value
                }))}
                rows={4}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                  focus:ring-blue-100 focus:border-blue-400 outline-none"
                placeholder="Any additional comments or observations..."
              />
            </div>

            {/* Feedback Message Text Area */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">
                Feedback Message
              </label>
              <textarea
                value={feedback.message}
                onChange={(e) => setFeedback(prev => ({
                  ...prev,
                  message: e.target.value
                }))}
                rows={4}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                  focus:ring-blue-100 focus:border-blue-400 outline-none"
                placeholder="Please provide your feedback message..."
                required
              />
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={() => router.back()}
              className="px-6 py-2 text-gray-700 bg-gray-100 rounded-lg 
                hover:bg-gray-200 transition-colors duration-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-500 text-white rounded-lg 
                hover:bg-blue-600 transition-colors duration-200 flex items-center"
            >
              <Send className="h-4 w-4 mr-2" />
              Submit Feedback
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}