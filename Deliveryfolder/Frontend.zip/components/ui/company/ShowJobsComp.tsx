'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import axios from 'axios'
import { Pencil, Trash2, Plus, Users } from 'lucide-react'

interface Internship {
  id: number
  title: string
  description: string
  skills_required: string
  is_paid: boolean
  start_date: string
  end_date: string
  company: {
    id: number
    company_name: string
    industry: string
    location: string
  }
}

const ShowInternshipsComp = () => {
  const router = useRouter()
  const [internships, setInternships] = useState<Internship[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchInternships = async () => {
      try {
        const userId = localStorage.getItem('user_id')
        const token = localStorage.getItem('accessToken')
        
        if (!userId || !token) {
          setError('Authentication credentials not found')
          setLoading(false)
          // router.push('/login')
          return
        }

        const response = await axios.get(`http://localhost:8000/api/internships/`, {
          params: { user_id: userId },
          headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
          }
        })

        setInternships(response.data)
        setLoading(false)
      } catch (error) {
        console.error('Error fetching internships:', error)
        if (axios.isAxiosError(error) && error.response?.status === 401) {
          setError('Session expired. Please login again.')
          // router.push('/login')
        } else {
          setError('Failed to fetch internships')
        }
        setLoading(false)
      }
    }

    fetchInternships()
  }, [router])

  const handleDelete = async (internshipId: number) => {
    if (!window.confirm('Are you sure you want to delete this internship?')) {
      return
    }

    try {
      const token = localStorage.getItem('accessToken')
      if (!token) {
        setError('Authentication credentials not found')
        router.push('/login')
        return
      }

      await axios.delete(`http://localhost:8000/api/internships/${internshipId}/`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      setInternships(internships.filter(internship => internship.id !== internshipId))
    } catch (error) {
      console.error('Error deleting internship:', error)
      if (axios.isAxiosError(error) && error.response?.status === 401) {
        setError('Session expired. Please login again.')
        router.push('/login')
      } else {
        setError('Failed to delete internship')
      }
    }
  }

  const handleEdit = (internshipId: number) => {
    const token = localStorage.getItem('accessToken')
    if (!token) {
      setError('Authentication credentials not found')
      router.push('/login')
      return
    }
    router.push(`/company/editinternship?id=${internshipId}`)
  }

  const handleCreate = () => {
    const token = localStorage.getItem('accessToken')
    if (!token) {
      setError('Authentication credentials not found')
      router.push('/login')
      return
    }
    router.push('/company/createjob')
  }

  const handleViewApplicants = (internshipId: number) => {
    console.log('Navigating to internship:', internshipId);
    const token = localStorage.getItem('accessToken')
    if (!token) {
      setError('Authentication credentials not found')
      router.push('/login')
      return
    }
    router.push(`/company/studlist?id=${internshipId}`)
  }

  if (loading) {
    return <div className="text-center p-4">Loading internships...</div>
  }

  if (error) {
    return <div className="text-center text-red-500 p-4">{error}</div>
  }

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Posted Internships</h1>
        <button
          onClick={handleCreate}
          className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg 
            hover:bg-blue-600 transition-colors"
        >
          <Plus className="h-5 w-5 mr-2" />
          Post New Internship
        </button>
      </div>

      {internships.length === 0 ? (
        <div className="text-center text-gray-500 p-4">
          No internships posted yet.
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {internships.map((internship) => (
            <div
              key={internship.id}
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
            >
              <div 
                onClick={() => {
                  console.log('Clicked internship:', internship.id);
                  handleViewApplicants(internship.id);
                }}
                className="cursor-pointer"
              >
                <h2 className="text-xl font-semibold text-gray-800 mb-2 hover:text-blue-600">
                  {internship.title}
                </h2>
                <p className="text-gray-600 mb-4">{internship.description}</p>
              </div>
              <div className="mb-4">
                <p className="text-sm text-gray-500">
                  <strong>Required Skills:</strong> {internship.skills_required}
                </p>
                <p className="text-sm text-gray-500">
                  <strong>Duration:</strong> {new Date(internship.start_date).toLocaleDateString()} - {new Date(internship.end_date).toLocaleDateString()}
                </p>
                <p className="text-sm text-gray-500">
                  <strong>Compensation:</strong> {internship.is_paid ? 'Paid' : 'Unpaid'}
                </p>
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => handleViewApplicants(internship.id)}
                  className="p-2 text-green-500 hover:bg-green-50 rounded-full transition-colors"
                  title="View Applicants"
                >
                  <Users className="h-5 w-5" />
                </button>
                <button
                  onClick={() => handleEdit(internship.id)}
                  className="p-2 text-blue-500 hover:bg-blue-50 rounded-full transition-colors"
                  title="Edit Internship"
                >
                  <Pencil className="h-5 w-5" />
                </button>
                <button
                  onClick={() => handleDelete(internship.id)}
                  className="p-2 text-red-500 hover:bg-red-50 rounded-full transition-colors"
                  title="Delete Internship"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default ShowInternshipsComp 