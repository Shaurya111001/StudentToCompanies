'use client'
import { useState, useEffect } from 'react'
import axios from 'axios'
import { FaGraduationCap } from 'react-icons/fa'

interface UniversityAutocompleteProps {
  value: string
  onChange: (value: string) => void
}

export default function UniversityAutocomplete({ value, onChange }: UniversityAutocompleteProps) {
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (value.length < 2) {
        setSuggestions([])
        return
      }

      try {
        const response = await axios.get(
          `http://localhost:8000/api/universities/search/?query=${encodeURIComponent(value)}`
        )
        const universities = response.data.map((uni: { name: string }) => uni.name)
        
        // Only add "Other" option if there are no exact matches
        if (universities.length === 0) {
          setSuggestions(['Enter custom university name'])
        } else {
          setSuggestions(universities)
        }
      } catch (error) {
        console.error('Error fetching universities:', error)
      }
    }

    const debounceTimer = setTimeout(fetchSuggestions, 300)
    return () => clearTimeout(debounceTimer)
  }, [value])

  return (
    <div className="relative">
      <FaGraduationCap className="absolute top-3 left-3 text-gray-400" />
      <input
        type="text"
        value={value}
        onChange={(e) => {
          onChange(e.target.value)
          setIsOpen(true)
        }}
        onFocus={() => setIsOpen(true)}
        placeholder="Enter university name"
        className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
      />
      {isOpen && suggestions.length > 0 && (
        <ul className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-auto">
          {suggestions.map((uni, index) => (
            <li
              key={index}
              className={`px-4 py-2 hover:bg-gray-100 cursor-pointer ${
                uni === 'Enter custom university name' ? 'text-gray-500 italic' : ''
              }`}
              onClick={() => {
                if (uni !== 'Enter custom university name') {
                  onChange(uni)
                }
                setIsOpen(false)
              }}
            >
              {uni}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}