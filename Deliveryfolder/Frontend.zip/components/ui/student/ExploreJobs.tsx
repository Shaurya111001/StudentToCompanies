'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import axios from 'axios'
import { 
  Search, 
  User, 
  Clock, 
  FileCheck, 
  LogOut,
  Briefcase,
  MapPin,
  DollarSign,
  Filter,
  Calendar
} from 'lucide-react'

interface Job {
  id: number
  title: string
  description: string
  skills_required: string
  is_paid: boolean
  start_date: string
  end_date: string
  company_id: number
}

const ExploreJobs = () => {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState('')
  const [showFilters, setShowFilters] = useState(true)
  const [jobs, setJobs] = useState<Job[]>([])
  const [filteredJobs, setFilteredJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)

  // Filter states
  const [isPaidFilter, setIsPaidFilter] = useState<boolean | null>(null)
  const [durationFilter, setDurationFilter] = useState<string | null>(null)

  useEffect(() => {
    fetchRecommendedJobs()
  }, [])

  // Apply filters whenever jobs or filter states change
  useEffect(() => {
    let filtered = [...jobs]

    // Apply paid/unpaid filter
    if (isPaidFilter !== null) {
      filtered = filtered.filter(job => job.is_paid === isPaidFilter)
    }

    // Apply duration filter
    if (durationFilter) {
      filtered = filtered.filter(job => {
        const start = new Date(job.start_date)
        const end = new Date(job.end_date)
        const durationInMonths = (end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24 * 30)
        
        switch(durationFilter) {
          case '0-3':
            return durationInMonths <= 3
          case '3-6':
            return durationInMonths > 3 && durationInMonths <= 6
          case '6+':
            return durationInMonths > 6
          default:
            return true
        }
      })
    }

    // Apply search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(job => 
        job.title.toLowerCase().includes(query) ||
        job.description.toLowerCase().includes(query) ||
        job.skills_required.toLowerCase().includes(query)
      )
    }

    setFilteredJobs(filtered)
  }, [jobs, isPaidFilter, durationFilter, searchQuery])

  const fetchRecommendedJobs = async () => {
    try {
      const userId = localStorage.getItem('user_id')
      const token = localStorage.getItem('accessToken')

      if (!userId || !token) {
        throw new Error('Authentication required')
      }

      const response = await axios.get(`http://localhost:8000/api/recommendations/`, {
        params: { user_id: userId },
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      })

      setJobs(response.data.recommendations)
      setFilteredJobs(response.data.recommendations)
    } catch (error: any) {
      console.error('Failed to fetch recommended jobs:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleApply = (jobId: number) => {
    router.push(`/student/applyjob?id=${jobId}`)
  }

  const handleLogout = () => {
    localStorage.removeItem('accessToken')
    localStorage.removeItem('user_id')
    localStorage.removeItem('user_type')
    router.push('/login')
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Left Sidebar - Filters */}
      <div className={`w-80 bg-white border-r border-gray-200 p-6 space-y-6 transition-all duration-300 ${showFilters ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-800">Filters</h2>
          <button onClick={() => setShowFilters(!showFilters)}>
            <Filter className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Real Filters */}
        <div className="space-y-6">
          {/* Paid/Unpaid Filter */}
          <div className="space-y-4">
            <h3 className="text-sm font-medium text-gray-600">Payment Type</h3>
            <div className="space-y-2">
              <label className="flex items-center space-x-3">
                <input
                  type="radio"
                  name="payment"
                  checked={isPaidFilter === true}
                  onChange={() => setIsPaidFilter(true)}
                  className="rounded border-gray-300 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-gray-700">Paid</span>
              </label>
              <label className="flex items-center space-x-3">
                <input
                  type="radio"
                  name="payment"
                  checked={isPaidFilter === false}
                  onChange={() => setIsPaidFilter(false)}
                  className="rounded border-gray-300 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-gray-700">Unpaid</span>
              </label>
              <label className="flex items-center space-x-3">
                <input
                  type="radio"
                  name="payment"
                  checked={isPaidFilter === null}
                  onChange={() => setIsPaidFilter(null)}
                  className="rounded border-gray-300 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-gray-700">All</span>
              </label>
            </div>
          </div>

          {/* Duration Filter */}
          <div className="space-y-4">
            <h3 className="text-sm font-medium text-gray-600">Duration</h3>
            <div className="space-y-2">
              <label className="flex items-center space-x-3">
                <input
                  type="radio"
                  name="duration"
                  checked={durationFilter === '0-3'}
                  onChange={() => setDurationFilter('0-3')}
                  className="rounded border-gray-300 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-gray-700">0-3 months</span>
              </label>
              <label className="flex items-center space-x-3">
                <input
                  type="radio"
                  name="duration"
                  checked={durationFilter === '3-6'}
                  onChange={() => setDurationFilter('3-6')}
                  className="rounded border-gray-300 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-gray-700">3-6 months</span>
              </label>
              <label className="flex items-center space-x-3">
                <input
                  type="radio"
                  name="duration"
                  checked={durationFilter === '6+'}
                  onChange={() => setDurationFilter('6+')}
                  className="rounded border-gray-300 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-gray-700">6+ months</span>
              </label>
              <label className="flex items-center space-x-3">
                <input
                  type="radio"
                  name="duration"
                  checked={durationFilter === null}
                  onChange={() => setDurationFilter(null)}
                  className="rounded border-gray-300 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-gray-700">Any duration</span>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Navigation Bar */}
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Search Bar */}
            <div className="flex-1 max-w-2xl">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search for jobs..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-400"
                />
              </div>
            </div>

            {/* Navigation Icons */}
            <nav className="flex items-center space-x-6 ml-6">
              <button onClick={() => router.push('/student')} className="p-2 hover:bg-gray-100 rounded-full">
                <User className="h-6 w-6 text-gray-600" />
              </button>
              {/* <button onClick={() => router.push('/status')} className="p-2 hover:bg-gray-100 rounded-full">
                <Clock className="h-6 w-6 text-gray-600" />
              </button> */}
              <button onClick={() => router.push('/student/joblist')} className="p-2 hover:bg-gray-100 rounded-full">
                <FileCheck className="h-6 w-6 text-gray-600" />
              </button>
              <div className="relative group">
                <button 
                  onClick={handleLogout}
                  className="p-2 hover:bg-gray-100 rounded-full"
                >
                  <LogOut className="h-6 w-6 text-gray-600" />
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 invisible group-hover:visible">
                  <button 
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    Logout
                  </button>
                </div>
              </div>
            </nav>
          </div>
        </header>

        {/* Job Posts Feed */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-3xl mx-auto space-y-6">
            {filteredJobs.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-xl shadow-sm">
                <h3 className="text-xl text-gray-600">No internships available</h3>
                <p className="text-gray-500 mt-2">Try adjusting your filters</p>
              </div>
            ) : (
              filteredJobs.map((job) => (
                <article 
                  key={job.id}
                  className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200"
                >
                  <div className="flex items-start space-x-4">
                    <div className="relative w-16 h-16 flex-shrink-0">
                      <Image
                        src="/assets/images/default-company-logo.png"
                        alt="Company Logo"
                        fill
                        className="object-contain rounded-lg"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h2 className="text-lg font-semibold text-gray-900">{job.title}</h2>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-4 text-sm text-gray-500">
                        <span className="flex items-center">
                          <DollarSign className="h-4 w-4 mr-1" />
                          {job.is_paid ? 'Paid' : 'Unpaid'}
                        </span>
                        <span className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          {new Date(job.start_date).toLocaleDateString()} - {new Date(job.end_date).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="mt-3 text-gray-600">{job.description}</p>
                      <div className="mt-2">
                        <h3 className="text-sm font-medium text-gray-600">Required Skills:</h3>
                        <p className="text-gray-600">{job.skills_required}</p>
                      </div>
                      <div className="mt-4">
                        <button
                          onClick={() => handleApply(job.id)}
                          className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                        >
                          Apply Now
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              ))
            )}
          </div>
        </main>
      </div>
    </div>
  )
}

export default ExploreJobs