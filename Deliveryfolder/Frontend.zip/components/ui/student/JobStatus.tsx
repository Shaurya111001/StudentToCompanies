'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import {
  Building,
  MapPin,
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  MessageCircle,
  Briefcase,
  GraduationCap,
  FileText,
  DollarSign,
  Mail,
  Phone
} from 'lucide-react'
import axios from 'axios'

interface JobStatusData {
  id: string;
  student: {
    id: string;
    user: {
      first_name: string;
      last_name: string;
      email: string;
    };
  };
  internship: {
    id: string;
    title: string;
    description: string;
    skills_required: string;
    is_paid: boolean;
    start_date: string;
    end_date: string;
    company: {
      id: string;
      company_name: string;
      logo: string | null;
      description: string;
      location: string;
      website: string | null;
    };
  };
  date_applied: string;
  status: 'pending' | 'interviewed' | 'accepted' | 'rejected' | 'under_review';
  interviews: {
    id: string;
    date_time: string;
    location: string;
    interview_type: string;
    notes: string;
    status: string;
  }[];
}

interface JobStatusProps {
  applicationId: string;
}
interface UserData {
  email: string
  first_name: string
  last_name: string
  is_active: boolean
  user_type: string
}

interface ProfileData {
  id: number
  university: string
  cv: string | null
  user: UserData
}


const JobStatus = ({ applicationId }: JobStatusProps) => {
  const router = useRouter()
  const [internshipStatus, setInternshipStatus] = useState<JobStatusData | null>(null)
  const [loading, setLoading] = useState(true)
  const [profileData, setProfileData] = useState<ProfileData | null>(null)

  useEffect(() => {
    const fetchInternshipStatus = async () => {
      const userId = localStorage.getItem('user_id')
      if (!applicationId || !userId) return

      try {
        console.log("Fetching status for application:", applicationId)
        const response = await axios.get(
          `http://localhost:8000/api/applications/status/${applicationId}/`,
          {
            params: { user_id: userId }
          }
        )
        console.log("Raw response data:", response.data)
        console.log("Student data:", response.data.student)
        console.log("Internship data:", response.data.internship)
        setInternshipStatus(response.data)
      } catch (error) {
        console.error("Error fetching internship status:", error)
        if (axios.isAxiosError(error)) {
          console.error("Response data:", error.response?.data)
        }
      } finally {
        setLoading(false)
      }
    }

    fetchInternshipStatus()
  }, [applicationId])

  useEffect(() => {
    const fetchStudentData = async () => {
      const token = localStorage.getItem('accessToken')
      var _user = localStorage.getItem("user_id");
      var _usertype = localStorage.getItem("user_type")
      try {
        if (_user) {
          
          const response = await axios.get(`http://localhost:8000/api/students/${_user}/`, {
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          })
          setProfileData(response.data)
          console.log(response.data)
        }
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    fetchStudentData()
  },[])

  const getStatusColor = (status: JobStatusData['status']) => {
    switch (status) {
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'interviewed':
        return 'bg-blue-100 text-blue-800';
      case 'under_review':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: JobStatusData['status']) => {
    switch (status) {
      case 'accepted':
        return <CheckCircle2 className="h-5 w-5 text-green-600" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-600" />;
      case 'interviewed':
        return <MessageCircle className="h-5 w-5 text-blue-600" />;
      case 'under_review':
        return <Clock className="h-5 w-5 text-yellow-600" />;
      default:
        return <Clock className="h-5 w-5 text-gray-600" />;
    }
  };

  if (loading) {
    return <div>Loading...</div>
  }

  if (!internshipStatus) {
    console.log("No internship status found")
    return <div>No internship status found.</div>
  }

  if (!internshipStatus.internship?.company) {
    console.log("Incomplete data check failed:", {
      hasInternship: !!internshipStatus.internship,
      hasCompany: !!internshipStatus.internship?.company
    })
    return <div>Application data is incomplete.</div>
  }

  if (!profileData) {
    return <div>Loading profile data...</div>
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      {/* Company Section */}
      <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
        <div className="flex items-start space-x-6">
          <div className="relative w-20 h-20 flex-shrink-0">
            <Image
              src={internshipStatus.internship.company.logo || '/assets/company-logo.jpeg'}
              alt={internshipStatus.internship.company.company_name}
              fill
              className="object-contain rounded-lg"
            />
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900">
              {internshipStatus.internship.title}
            </h1>
            <div className="mt-2 flex flex-wrap gap-4 text-sm text-gray-600">
              <span className="flex items-center">
                <MapPin className="h-4 w-4 mr-1" />
                {internshipStatus.internship.company.location}
              </span>
              {internshipStatus.internship.company.website && (
                <span className="flex items-center">
                  <Building className="h-4 w-4 mr-1" />
                  {internshipStatus.internship.company.website}
                </span>
              )}
            </div>
            <p className="mt-4 text-gray-600">
              {internshipStatus.internship.description}
            </p>
          </div>
        </div>
      </div>

      {/* Job Details Section */}
      <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Job Details</h2>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-900">
              {internshipStatus.internship.title}
            </h3>
            <div className="flex items-center gap-4">
              <span className="flex items-center text-gray-600">
                <DollarSign className="h-4 w-4 mr-1" />
                {internshipStatus.internship.is_paid ? 'Paid' : 'Unpaid'}
              </span>
            </div>
          </div>
          <p className="text-gray-600">{internshipStatus.internship.description}</p>
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Required Skills</h4>
            <p className="text-gray-600">{internshipStatus.internship.skills_required}</p>
          </div>
        </div>
      </div>

      {/* Application Details Section */}
      <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Your Application</h2>
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">Contact Information</h4>
              <div className="space-y-2 text-gray-600">
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  {profileData.user.email}
                </div>
                <div className="flex items-center">
                  <GraduationCap className="h-4 w-4 mr-2" />
                  {profileData.university}
                </div>
                {profileData.department && (
                  <div className="flex items-center">
                    <Building className="h-4 w-4 mr-2" />
                    {profileData.department}
                  </div>
                )}
              </div>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">Application Timeline</h4>
              <div className="space-y-2 text-gray-600">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  Applied: {new Date(internshipStatus.date_applied).toLocaleDateString()}
                </div>
              </div>
            </div>
          </div>

          {/* Interviews Section */}
          {internshipStatus.interviews?.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">Interviews</h4>
              <div className="space-y-4">
                {internshipStatus.interviews.map((interview) => (
                  <div key={interview.id} className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{interview.interview_type}</span>
                      <span className="text-sm text-gray-600">
                        {new Date(interview.date_time).toLocaleString()}
                      </span>
                    </div>
                    <p className="mt-2 text-gray-600">Location: {interview.location}</p>
                    {interview.notes && (
                      <p className="mt-1 text-gray-600">Notes: {interview.notes}</p>
                    )}
                    <div className="mt-2">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                        ${getStatusColor(interview.status)}`}>
                        {interview.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Status Section */}
      <div className="bg-white rounded-xl shadow-sm p-8">
        <div className="text-center">
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium
            ${getStatusColor(internshipStatus.status)}`}>
            {getStatusIcon(internshipStatus.status)}
            <span className="capitalize">Application {internshipStatus.status.replace('_', ' ')}</span>
          </div>

          <button
            onClick={() => router.push(`/student/feedback?application=${applicationId}`)}
            className="mt-6 px-6 py-2 bg-purple-500 text-white rounded-lg 
              hover:bg-purple-600 transition-colors">
            Provide Portal Feedback
          </button>
        </div>
      </div>
    </div>
  )
}

export default JobStatus