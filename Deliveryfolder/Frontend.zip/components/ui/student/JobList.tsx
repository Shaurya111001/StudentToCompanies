'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import axios from 'axios'
import { 
  Building,
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  MessageCircle,
  ChevronRight
} from 'lucide-react'

interface Interview {
  id: string
  date_time: string
  location: string
  interview_type: string
  notes: string
  status: string
}

interface JobApplication {
  id: string
  student: {
    id: string
    first_name: string
    last_name: string
    email: string
    university: string
    profile_url?: string
  }
  internship: {
    id: string
    title: string
    description: string
    skills_required: string
    is_paid: boolean
    start_date: string
    end_date: string
    company: {
      id: string
      user: number
      company_name: string
      logo?: string
      description: string
    }
  }
  date_applied: string
  description: string
  status: 'pending' | 'interviewed' | 'accepted' | 'rejected' | 'under_review'
  interviews: Interview[]; // Add interviews array
}

const JobList = () => {
  const router = useRouter()
  const [applications, setApplications] = useState<JobApplication[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchApplications = async () => {
      const userId = localStorage.getItem('user_id') // Assuming user_id is stored in localStorage
      if (!userId) {
        console.error("User ID is not found in localStorage.")
        return
      }

      try {
        const response = await axios.get(`http://localhost:8000/api/applications/`, {
          params: { user_id: userId }
        })
        console.log("API Response:", response.data); // Log the response data
        const formattedApplications = response.data.map((application: any) => ({
          id: application.id,
          student: {
            id: application.student,
            first_name: "N/A", // Placeholder
            last_name: "N/A",  // Placeholder
            email: "N/A",      // Placeholder
            university: "N/A", // Placeholder
            profile_url: '/assets/company-logo.jpeg' // Default logo if not available
          },
          internship: {
            id: application.internship.id,
            title: application.internship.title,
            description: application.internship.description,
            skills_required: application.internship.skills_required,
            is_paid: application.internship.is_paid,
            start_date: application.internship.start_date,
            end_date: application.internship.end_date,
            company: {
              id: application.internship.company.id,
              user: application.internship.company.user,
              company_name: application.internship.company.company_name,
              logo: application.internship.company.logo || '/assets/company-logo.jpeg', // Default logo if not available
              description: application.internship.company.description
            }
          },
          date_applied: new Date(application.date_applied).toISOString().split('T')[0], // Format date
          description: application.description,
          status: application.status,
          interviews: application.interviews || [] // Include interviews
        }));
        setApplications(formattedApplications);
      } catch (error) {
        console.error("Error fetching applications:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchApplications();
  }, []);

  const getStatusColor = (status: JobApplication['status']) => {
    switch (status) {
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'interviewed':
        return 'bg-blue-100 text-blue-800';
      case 'under_review':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  const getStatusIcon = (status: JobApplication['status']) => {
    switch (status) {
      case 'accepted':
        return <CheckCircle2 className="h-5 w-5 text-green-600" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-600" />;
      case 'interviewed':
        return <MessageCircle className="h-5 w-5 text-blue-600" />;
      case 'under_review':
        return <Clock className="h-5 w-5 text-yellow-600" />;
      default:
        return <Clock className="h-5 w-5 text-gray-600" />;
    }
  }

  if (loading) {
    return <div>Loading...</div>; // Simple loading state
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      <div className="bg-white rounded-xl shadow-sm">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <h1 className="text-2xl font-bold text-gray-900">My Job Applications</h1>
          <p className="mt-1 text-gray-500">
            Track the status of your job applications
          </p>
        </div>

        {/* Applications List */}
        <div className="divide-y divide-gray-200">
          {applications.map((application) => (
            <div
              key={application.id}
              onClick={() => router.push(`/student/jobstatus/${application.id}`)}
              className="p-6 hover:bg-gray-50 transition-colors duration-200 cursor-pointer"
            >
              <div className="flex items-start space-x-4">
                {/* Company Logo */}
                <div className="relative w-12 h-12 flex-shrink-0">
                  <Image
                    src={application.internship.company.logo}
                    alt={application.internship.company.company_name}
                    fill
                    className="object-contain rounded-lg"
                  />
                </div>

                {/* Job Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-semibold text-gray-900 truncate">
                      {application.internship.title}
                    </h2>
                    <ChevronRight className="h-5 w-5 text-gray-400" />
                  </div>
                  <div className="mt-1 text-gray-600">{application.internship.company.company_name}</div>
                  <div className="mt-2 flex flex-wrap items-center gap-4 text-sm text-gray-500">
                    <div className="flex items-center">
                      <Building className="h-4 w-4 mr-1" />
                      {application.internship.location}
                    </div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      Applied: {application.date_applied}
                    </div>
                    <div className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium
                      ${getStatusColor(application.status)}`}
                    >
                      {getStatusIcon(application.status)}
                      <span className="capitalize">{application.status}</span>
                    </div>
                  </div>

                  {/* Interview Details */}
                  {application.interviews.length > 0 && (
                    <div className="mt-3 text-sm">
                      <h4 className="font-semibold">Interviews:</h4>
                      {application.interviews.map((interview) => (
                        <div key={interview.id} className="text-gray-600">
                          <div>
                            <strong>Type:</strong> {interview.interview_type}
                          </div>
                          <div>
                            <strong>Date:</strong> {new Date(interview.date_time).toLocaleString()}
                          </div>
                          <div>
                            <strong>Location:</strong> {interview.location}
                          </div>
                          <div>
                            <strong>Status:</strong> {interview.status}
                          </div>
                          {interview.notes && (
                            <div>
                              <strong>Notes:</strong> {interview.notes}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {applications.length === 0 && (
          <div className="p-8 text-center">
            <Clock className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No applications yet</h3>
            <p className="mt-1 text-sm text-gray-500">
              Start applying for jobs to see your applications here.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

export default JobList