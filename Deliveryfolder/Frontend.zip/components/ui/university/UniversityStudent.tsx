'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { 
  Search,
  GraduationCap,
  Building,
  Mail,
  FileText,
  ChevronLeft,
  ChevronRight,
  ArrowUpDown,
  Filter
} from 'lucide-react'
import axios from 'axios'
import { motion } from 'framer-motion'
// import GradientBackground from '../backgrounds/GradientBackground'

interface Application {
  id: string
  company_name: string
  position: string
  status: string
  date_applied: string
  is_paid: boolean
  description: string
}

interface Student {
  id: string
  name: string
  email: string
  profile_image: string | null
  cv_file: string | null
  cv_text: string
  applications: Application[]
}

interface PaginatedResponse {
  results: Student[]
  total_pages: number
  current_page: number
  total_count: number
}

// Add new interfaces for filters
interface Department {
  id: number
  name: string
  courses: Course[]
}

interface Course {
  id: number
  name: string
  subjects: Subject[]
}

interface Subject {
  id: number
  name: string
}

interface FilterState {
  department: string
  course: string
  subject: string
}

export default function UniversityStudent() {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState('')
  const [students, setStudents] = useState<Student[]>([])
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [sortField, setSortField] = useState<'name' | 'date'>('name')
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc')
  
  // Add new state for filters
  const [departments, setDepartments] = useState<Department[]>([])
  const [filters, setFilters] = useState<FilterState>({
    department: '',
    course: '',
    subject: ''
  })
  const [isFilterOpen, setIsFilterOpen] = useState(false)

  useEffect(() => {
    fetchStudents()
    fetchDepartments()
  }, [currentPage, sortField, sortOrder])

  const fetchDepartments = async () => {
    try {
      const token = localStorage.getItem('accessToken')
      const userId = localStorage.getItem('user_id')
      
      const response = await axios.get(
        `http://localhost:8000/api/universities/${userId}/`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      )
      setDepartments(response.data.departments)
    } catch (error) {
      console.error('Error fetching departments:', error)
    }
  }

  const fetchStudents = async () => {
    try {
      const token = localStorage.getItem('accessToken')
      const userId = localStorage.getItem('user_id')
      
      if (!token || !userId) {
        console.error('No access token or user ID found')
        router.push('/login')
        return
      }

      // Add filters to the query
      const queryParams = new URLSearchParams({
        page: currentPage.toString(),
        sort_field: sortField,
        sort_order: sortOrder,
        user_id: userId,
        ...(filters.department && { department: filters.department }),
        ...(filters.course && { course: filters.course }),
        ...(filters.subject && { subject: filters.subject })
      })

      const response = await axios.get<PaginatedResponse>(
        `http://localhost:8000/api/universities/students/?${queryParams}`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      )
      setStudents(response.data.results)
      setTotalPages(response.data.total_pages)
    } catch (error) {
      console.error('Error fetching students:', error)
      if (axios.isAxiosError(error) && error.response?.status === 401) {
        router.push('/login')
      }
    } finally {
      setLoading(false)
    }
  }

  const handleFilterChange = (filterType: keyof FilterState, value: string) => {
    setFilters(prev => {
      const newFilters = { ...prev, [filterType]: value }
      // Reset dependent filters
      if (filterType === 'department') {
        newFilters.course = ''
        newFilters.subject = ''
      } else if (filterType === 'course') {
        newFilters.subject = ''
      }
      return newFilters
    })
    setCurrentPage(1) // Reset to first page when filters change
  }

  const getAvailableCourses = () => {
    const department = departments.find(d => d.name === filters.department)
    return department?.courses || []
  }

  const getAvailableSubjects = () => {
    const department = departments.find(d => d.name === filters.department)
    const course = department?.courses.find(c => c.name === filters.course)
    return course?.subjects || []
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'accepted':
        return 'bg-green-100 text-green-800'
      case 'rejected':
        return 'bg-red-100 text-red-800'
      case 'under_review':
        return 'bg-blue-100 text-blue-800'
      default:
        return 'bg-yellow-100 text-yellow-800'
    }
  }

  const handleSort = (field: 'name' | 'date') => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortOrder('asc')
    }
  }

  const filteredStudents = students.filter(student => 
    student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.email.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (loading) return (
    <div className="flex justify-center items-center h-screen">
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360]
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "linear"
        }}
        className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full"
      />
    </div>
  )

  return (
    <div className="min-h-screen">
      {/* <GradientBackground /> */}
      
      <div className="max-w-6xl mx-auto p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Student Applications</h1>
          <p className="mt-2 text-gray-600">Track and manage student internship applications</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-sm p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4 justify-between">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -mt-2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search students..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg 
                    focus:ring-2 focus:ring-blue-100 focus:border-blue-400 outline-none"
                />
              </div>
            </div>
            
            <div className="flex gap-4">
              <button
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-50"
              >
                <Filter className="h-4 w-4" />
                Filters
              </button>
              <button
                onClick={() => handleSort('name')}
                className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-50"
              >
                Sort by Name
                <ArrowUpDown className="h-4 w-4" />
              </button>
              <button
                onClick={() => handleSort('date')}
                className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-50"
              >
                Sort by Date
                <ArrowUpDown className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Filter Panel */}
          {isFilterOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="mt-4 pt-4 border-t"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Department
                  </label>
                  <select
                    value={filters.department}
                    onChange={(e) => handleFilterChange('department', e.target.value)}
                    className="w-full p-2 border border-gray-200 rounded-lg"
                  >
                    <option value="">All Departments</option>
                    {departments.map(dept => (
                      <option key={dept.id} value={dept.name}>
                        {dept.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Course
                  </label>
                  <select
                    value={filters.course}
                    onChange={(e) => handleFilterChange('course', e.target.value)}
                    className="w-full p-2 border border-gray-200 rounded-lg"
                    disabled={!filters.department}
                  >
                    <option value="">All Courses</option>
                    {getAvailableCourses().map(course => (
                      <option key={course.id} value={course.name}>
                        {course.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Subject
                  </label>
                  <select
                    value={filters.subject}
                    onChange={(e) => handleFilterChange('subject', e.target.value)}
                    className="w-full p-2 border border-gray-200 rounded-lg"
                    disabled={!filters.course}
                  >
                    <option value="">All Subjects</option>
                    {getAvailableSubjects().map(subject => (
                      <option key={subject.id} value={subject.name}>
                        {subject.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </motion.div>
          )}
        </div>

        {/* Students List */}
        <div className="space-y-6">
          {filteredStudents.map(student => (
            <motion.div
              key={student.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white/80 backdrop-blur-sm rounded-xl shadow-sm p-6"
            >
              <div className="flex items-start space-x-4">
                {/* Student Profile */}
                <div className="relative w-16 h-16 flex-shrink-0">
                  <img
                    src={student.profile_image || '/assets/student-logo.jpeg'}
                    alt={student.name}
                    className="w-16 h-16 object-cover rounded-full"
                  />
                </div>

                {/* Student Details */}
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{student.name}</h3>
                      <div className="mt-1 flex items-center gap-4 text-sm text-gray-600">
                        <div className="flex items-center">
                          <Mail className="h-4 w-4 mr-1" />
                          {student.email}
                        </div>
                        {student.cv_file && (
                          <a
                            href={student.cv_file}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center text-blue-600 hover:text-blue-700"
                          >
                            <FileText className="h-4 w-4 mr-1" />
                            View CV
                          </a>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Applications */}
                  <div className="mt-4">
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Recent Applications</h4>
                    <div className="space-y-3">
                      {student.applications.map((application, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                        >
                          <div className="flex items-center space-x-3">
                            <Building className="h-4 w-4 text-gray-400" />
                            <div>
                              <div className="font-medium text-gray-900">
                                {application.company_name}
                              </div>
                              <div className="text-sm text-gray-600">
                                {application.position}
                                {application.is_paid && (
                                  <span className="ml-2 text-green-600">• Paid</span>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-4">
                            <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium
                              ${getStatusColor(application.status)}`}>
                              {application.status.replace('_', ' ')}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}

          {/* Pagination */}
          <div className="flex justify-center space-x-2 mt-6">
            <button
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="p-2 border rounded-lg disabled:opacity-50"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <span className="py-2 px-4 border rounded-lg">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="p-2 border rounded-lg disabled:opacity-50"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>

          {/* Empty State */}
          {filteredStudents.length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-12 bg-white/80 backdrop-blur-sm rounded-xl shadow-sm"
            >
              <GraduationCap className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No students found</h3>
              <p className="mt-1 text-sm text-gray-500">
                Try adjusting your search criteria or filters
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}