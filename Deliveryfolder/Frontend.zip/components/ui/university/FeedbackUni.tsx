'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Star, Send, MessageSquare } from 'lucide-react'
import axios from 'axios'

interface FeedbackForm {
  rating: number
  message: string
}

export default function FeedbackUni() {
  const router = useRouter()

  const [feedback, setFeedback] = useState<FeedbackForm>({
    rating: 0,
    message: ''
  })

  const RatingStars = ({ 
    rating, 
    onRatingChange 
  }: { 
    rating: number
    onRatingChange: (rating: number) => void 
  }) => {
    return (
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => onRatingChange(star)}
            className="focus:outline-none"
          >
            <Star
              className={`h-6 w-6 ${
                star <= rating
                  ? 'fill-yellow-400 text-yellow-400'
                  : 'text-gray-300'
              }`}
            />
          </button>
        ))}
      </div>
    )
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const userId = localStorage.getItem('user_id')
      if (!userId) {
        console.error("User ID is not found in localStorage.")
        return
      }

      const response = await axios.post('http://localhost:8000/api/feedback/', {
        user: userId,
        rating: feedback.rating,
        message: feedback.message
      })

      console.log('Feedback submitted successfully:', response.data)
      router.push('/university/profile')
    } catch (error) {
      console.error('Error submitting feedback:', error)
    }
  }

  return (
    <div className="max-w-3xl mx-auto p-8">
      <div className="bg-white rounded-xl shadow-sm p-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">
          University Portal Feedback
        </h1>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Overall Rating */}
          <div className="space-y-2">
            <label className="flex items-center text-sm font-medium text-gray-700">
              <Star className="h-4 w-4 mr-2" />
              Overall Rating
            </label>
            <RatingStars
              rating={feedback.rating}
              onRatingChange={(rating) => 
                setFeedback(prev => ({ ...prev, rating }))
              }
            />
          </div>

          {/* Feedback Message */}
          <div className="space-y-2">
            <label className="flex items-center text-sm font-medium text-gray-700">
              <MessageSquare className="h-4 w-4 mr-2" />
              Your Feedback
            </label>
            <textarea
              value={feedback.message}
              onChange={(e) => setFeedback(prev => ({
                ...prev,
                message: e.target.value
              }))}
              rows={6}
              className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 
                focus:ring-blue-100 focus:border-blue-400 outline-none"
              placeholder="Please share your feedback about the portal..."
              required
            />
          </div>

          {/* Submit Buttons */}
          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="px-6 py-2 bg-blue-500 text-white rounded-lg 
                hover:bg-blue-600 transition-colors flex items-center"
            >
              <Send className="h-4 w-4 mr-2" />
              Submit Feedback
            </button>
            <button
              type="button"
              onClick={() => router.back()}
              className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg 
                hover:bg-gray-200 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}