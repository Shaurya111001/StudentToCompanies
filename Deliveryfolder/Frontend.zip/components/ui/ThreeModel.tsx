'use client'
import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'

export default function ThreeModel() {
  const mountRef = useRef<HTMLDivElement>(null)
  const sceneRef = useRef<THREE.Scene | null>(null)
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null)
  const modelRef = useRef<THREE.Group | null>(null)
  const controlsRef = useRef<OrbitControls | null>(null)

  useEffect(() => {
    if (!mountRef.current) return

    // Only create new scene and renderer if they don't exist
    if (!sceneRef.current) {
      sceneRef.current = new THREE.Scene()
      // Remove background color
      sceneRef.current.background = null
    }

    if (!rendererRef.current) {
      rendererRef.current = new THREE.WebGLRenderer({ 
        antialias: true,
        alpha: true // Enable transparency
      })
      rendererRef.current.setPixelRatio(window.devicePixelRatio)
      rendererRef.current.setClearColor(0x000000, 0) // Make background transparent
    }

    const scene = sceneRef.current
    const renderer = rendererRef.current
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
    
    renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight)
    mountRef.current.appendChild(renderer.domElement)

    // Add OrbitControls with restrictions
    const controls = new OrbitControls(camera, renderer.domElement)
    controls.enableDamping = true // Add smooth damping
    controls.dampingFactor = 0.05
    controls.rotateSpeed = 0.5
    controls.autoRotate = true // Enable auto-rotation
    controls.autoRotateSpeed = 2.0 // Adjust rotation speed
    
    // Add zoom restrictions
    controls.enableZoom = true
    controls.minDistance = 3.5 // Minimum zoom distance
    controls.maxDistance = 4  // Maximum zoom distance
    
    // Add rotation restrictions (optional)
    controls.minPolarAngle = Math.PI / 4    // Restrict vertical rotation (up)
    controls.maxPolarAngle = Math.PI / 1.5  // Restrict vertical rotation (down)
    
    // Disable pan
    controls.enablePan = false
    
    controlsRef.current = controls

    // Add lights
    const pointLight = new THREE.PointLight(0xffffff, 1, 100)
    pointLight.position.set(5, 5, 5)
    scene.add(pointLight)

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7) // Increased ambient light
    scene.add(ambientLight)

    // Load GLB model
    const loader = new GLTFLoader()
    loader.load(
      '/models/graduation_hat.glb', // Replace with your model path
      (gltf) => {
        if (modelRef.current) {
          scene.remove(modelRef.current)
        }
        modelRef.current = gltf.scene
        scene.add(gltf.scene)

        // Center and scale the model
        const box = new THREE.Box3().setFromObject(gltf.scene)
        const center = box.getCenter(new THREE.Vector3())
        const size = box.getSize(new THREE.Vector3())
        
        const maxDim = Math.max(size.x, size.y, size.z)
        const scale = 4 / maxDim // Increased scale factor (adjust as needed)
        gltf.scene.scale.setScalar(scale)
        
        gltf.scene.position.sub(center.multiplyScalar(scale))
        camera.position.z = 5 // Adjusted camera distance
      },
      (progress) => {
        console.log('Loading progress:', (progress.loaded / progress.total) * 100, '%')
      },
      (error) => {
        console.error('Error loading model:', error)
      }
    )

    // Animation
    const animate = () => {
      requestAnimationFrame(animate)
      if (controlsRef.current) {
        controlsRef.current.update() // Update controls in animation loop
      }
      renderer.render(scene, camera)
    }

    // Handle resize
    const handleResize = () => {
      if (!mountRef.current) return
      const width = mountRef.current.clientWidth
      const height = mountRef.current.clientHeight
      renderer.setSize(width, height)
      camera.aspect = width / height
      camera.updateProjectionMatrix()
    }

    window.addEventListener('resize', handleResize)
    handleResize()
    animate()

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize)
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement)
      }
      if (modelRef.current) {
        scene.remove(modelRef.current)
        modelRef.current = null
      }
      if (controlsRef.current) {
        controlsRef.current.dispose()
      }
      pointLight.dispose()
      ambientLight.dispose()
    }
  }, [])

  return (
    <div 
      ref={mountRef} 
      className="w-full h-[400px] bg-transparent"
      style={{ 
        position: 'relative',
        zIndex: 10 
      }}
    />
  )
}