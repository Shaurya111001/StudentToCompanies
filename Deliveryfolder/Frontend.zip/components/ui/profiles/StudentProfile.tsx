'use client'
import { useState, useEffect, useRef } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import axios from 'axios'
import { 
  FaSignOutAlt, FaEdit, FaGraduationCap, 
  FaFileAlt, FaBriefcase, FaUpload, 
  FaCode, FaTools, FaUserGraduate, FaSearch 
} from 'react-icons/fa'
import { motion, AnimatePresence } from 'framer-motion'
import toast from 'react-hot-toast'
// import GradientBackground from '../backgrounds/GradientBackground'

interface ExtractedSkill {
  id: number;
  skill_name: string;
}

interface User {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
}

interface StudentData {
  id: number;
  user: User;
  university: string;
  department: string;
  course: string;
  cv_file?: string;
  cv?: string;
  extracted_skills: ExtractedSkill[];
  experiences: Experience[];
}

interface Experience {
  id: number
  title: string
  company: string
  start_date: string
  end_date?: string
  description: string
  is_current: boolean
}

export default function StudentProfile() {
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [studentData, setStudentData] = useState<StudentData | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [updatedStudent, setUpdatedStudent] = useState<StudentData | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)

  useEffect(() => {
    const fetchStudentData = async () => {
      const token = localStorage.getItem('accessToken')
      const userId = localStorage.getItem('user_id')

      try {
        const response = await axios.get(`http://localhost:8000/api/students/${userId}/`)
        setStudentData(response.data)
        setUpdatedStudent(response.data)
        console.log(response.data)
      } catch (error) {
        console.error('Failed to fetch student data:', error)
        toast.error('Failed to load profile data')
      }
    }
    fetchStudentData()
  }, [])

  const handleLogout = () => {
    localStorage.removeItem('accessToken')
    localStorage.removeItem('refreshToken')
    localStorage.removeItem('user_id')
    localStorage.removeItem('user_type')
    router.push('/login')
  }

  const handleUpdate = async () => {
    const token = localStorage.getItem('accessToken')
    const userId = localStorage.getItem('user_id')
    
    try {
      // Only send the fields we want to update
      const updateData = {
        user: {
          first_name: updatedStudent?.user?.first_name,
          last_name: updatedStudent?.user?.last_name
        },
        university: updatedStudent?.university,
        department: updatedStudent?.department,
        course: updatedStudent?.course
      }
      
      console.log('Updating profile with data:', updateData)
      
      const response = await axios.put(
        `http://localhost:8000/api/students/${userId}/`,
        updateData,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      )
      console.log('Update response:', response.data)
      setStudentData(response.data)
      setIsModalOpen(false)
      toast.success('Profile updated successfully!')
    } catch (error: any) {
      console.error('Update error:', error)
      console.error('Error response:', error.response?.data)
      toast.error(error.response?.data?.error || 'Failed to update profile')
    }
  }

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setSelectedFile(file)
      handleCVUpload(file)
    }
  }

  const handleCVUpload = async (file: File) => {
    const token = localStorage.getItem('accessToken')
    const userId = localStorage.getItem('user_id')
    
    if (!file || !token || !userId) return

    const formData = new FormData()
    formData.append('cv_file', file)

    setIsUploading(true)
    try {
      console.log('Uploading CV for user:', userId)
      const response = await axios.patch(
        `http://localhost:8000/api/students/${userId}/`,
        formData,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'multipart/form-data'
          }
        }
      )
      console.log('Upload response:', response.data)
      setStudentData(response.data)
      toast.success('CV uploaded successfully!')
    } catch (error: any) {
      console.error('CV upload error:', error)
      console.error('Error response:', error.response?.data)
      toast.error(error.response?.data?.error || 'Failed to upload CV')
    } finally {
      setIsUploading(false)
    }
  }

  if (!studentData) return (
    <div className="min-h-screen flex items-center justify-center">
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360]
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "linear"
        }}
        className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full"
      />
    </div>
  )

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen"
    >
      {/* <GradientBackground /> */}
      
      {/* Header with Logout */}
      <motion.div 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="bg-white/80 backdrop-blur-sm shadow-lg sticky top-0 z-50"
      >
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <motion.h1 
            whileHover={{ scale: 1.05 }}
            className="text-xl font-semibold text-gray-800"
          >
            Student Dashboard
          </motion.h1>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleLogout}
            className="flex items-center px-4 py-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors duration-200"
          >
            <FaSignOutAlt className="mr-2" />
            Logout
          </motion.button>
        </div>
      </motion.div>

      <div className="max-w-6xl mx-auto p-8">
        {/* Header with Explore Button */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Student Profile</h1>
            <p className="mt-2 text-gray-600">Manage your profile and applications</p>
          </div>
          <button
            onClick={() => router.push('/student/explorejob')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            <FaSearch className="w-5 h-5" />
            Explore Internships
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Main Profile Section */}
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="md:col-span-2 space-y-6"
          >
            {/* Basic Info Card */}
            <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-8">
              <div className="space-y-6">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">
                    {studentData.user.first_name} {studentData.user.last_name}
                  </h2>
                  <p className="text-gray-600">{studentData.user.email}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-2 flex items-center">
                      <FaGraduationCap className="mr-2" />
                      University
                    </h3>
                    <p className="text-gray-600">{studentData.university}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-2 flex items-center">
                      <FaUserGraduate className="mr-2" />
                      Department
                    </h3>
                    <p className="text-gray-600">{studentData.department || 'Not specified'}</p>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-2 flex items-center">
                    <FaCode className="mr-2" />
                    Course
                  </h3>
                  <p className="text-gray-600">{studentData.course || 'Not specified'}</p>
                </div>

                <motion.div 
                  className="flex flex-wrap gap-4"
                  variants={{
                    hidden: { opacity: 0 },
                    show: {
                      opacity: 1,
                      transition: {
                        staggerChildren: 0.1
                      }
                    }
                  }}
                  initial="hidden"
                  animate="show"
                >
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setIsModalOpen(true)}
                    className="flex items-center px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 shadow-sm hover:shadow-lg"
                  >
                    <FaEdit className="mr-2" />
                    Update Profile
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => router.push('/student/joblist')}
                    className="flex items-center px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all duration-200 shadow-sm hover:shadow-lg"
                  >
                    <FaBriefcase className="mr-2" />
                    My Applications
                  </motion.button>
                </motion.div>
              </div>
            </div>

            {/* Experience Section */}
            {studentData.experiences && studentData.experiences.length > 0 && (
              <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-8">
                <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                  <FaBriefcase className="mr-2" />
                  Experience
                </h3>
                <div className="space-y-6">
                  {studentData.experiences.map((exp) => (
                    <div key={exp.id} className="border-l-2 border-blue-500 pl-4">
                      <h4 className="text-lg font-semibold text-gray-800">{exp.title}</h4>
                      <p className="text-gray-600">{exp.company}</p>
                      <p className="text-sm text-gray-500">
                        {new Date(exp.start_date).toLocaleDateString()} - 
                        {exp.is_current ? ' Present' : exp.end_date ? ` ${new Date(exp.end_date).toLocaleDateString()}` : ''}
                      </p>
                      <p className="text-gray-600 mt-2">{exp.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>

          {/* Sidebar */}
          <motion.div 
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="space-y-6"
          >
            {/* CV Section */}
            <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <FaFileAlt className="mr-2" />
                CV Document
              </h3>
              
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelect}
                accept=".pdf"
                className="hidden"
              />
              
              <div className="space-y-4">
                {studentData.cv_file ? (
                  <>
                    <a 
                      href={studentData.cv_file}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:text-blue-600 flex items-center"
                    >
                      <FaFileAlt className="mr-2" />
                      View Current CV
                    </a>
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full flex items-center justify-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                      disabled={isUploading}
                    >
                      {isUploading ? (
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      ) : (
                        <FaUpload className="mr-2" />
                      )}
                      Update CV
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full flex items-center justify-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                    disabled={isUploading}
                  >
                    {isUploading ? (
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    ) : (
                      <FaUpload className="mr-2" />
                    )}
                    Upload CV
                  </button>
                )}
              </div>
            </div>

            {/* Skills Section */}
            {studentData.extracted_skills && studentData.extracted_skills.length > 0 && (
              <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                  <FaTools className="mr-2" />
                  Skills
                </h3>
                <div className="flex flex-wrap gap-2">
                  {studentData.extracted_skills.map((skill) => (
                    <span
                      key={skill.id}
                      className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                    >
                      {skill.skill_name}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>

      {/* Update Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-xl shadow-xl w-full max-w-md"
            >
              <div className="px-6 py-4 border-b border-gray-100">
                <h2 className="text-xl font-semibold text-gray-800">Update Profile</h2>
              </div>
              <div className="p-6 space-y-4">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                    <input
                      type="text"
                      value={updatedStudent?.user?.first_name || ''}
                      onChange={(e) => setUpdatedStudent({
                        ...updatedStudent!,
                        user: {
                          ...updatedStudent!.user,
                          first_name: e.target.value
                        }
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                    <input
                      type="text"
                      value={updatedStudent?.user?.last_name || ''}
                      onChange={(e) => setUpdatedStudent({
                        ...updatedStudent!,
                        user: {
                          ...updatedStudent!.user,
                          last_name: e.target.value
                        }
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">University</label>
                    <input
                      type="text"
                      value={updatedStudent?.university || ''}
                      onChange={(e) => setUpdatedStudent({
                        ...updatedStudent!,
                        university: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                    <input
                      type="text"
                      value={updatedStudent?.department || ''}
                      onChange={(e) => setUpdatedStudent({
                        ...updatedStudent!,
                        department: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Course</label>
                    <input
                      type="text"
                      value={updatedStudent?.course || ''}
                      onChange={(e) => setUpdatedStudent({
                        ...updatedStudent!,
                        course: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>
              <div className="px-6 py-4 bg-gray-50 rounded-b-xl flex justify-end gap-3">
                <button 
                  onClick={() => setIsModalOpen(false)} 
                  className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleUpdate} 
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}