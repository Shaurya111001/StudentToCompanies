'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import axios from 'axios'
import { FaSignOutAlt, FaEdit, FaBriefcase, FaPlus } from 'react-icons/fa'
import { motion, AnimatePresence } from 'framer-motion'
import gsap from 'gsap'
import toast from 'react-hot-toast'


interface CompanyData {
  id: number
  company_name: string
  description: string
  logo: string
}

export default function CompanyProfile() {
  const router = useRouter()
  const [companyData, setCompanyData] = useState<CompanyData | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [updatedCompany, setUpdatedCompany] = useState<CompanyData | null>(null)

  useEffect(() => {
    const fetchCompanyData = async () => {
      const token = localStorage.getItem('accessToken')
      const _user = localStorage.getItem("user_id")

      try {
        const response = await axios.get(`http://localhost:8000/api/companies/${_user}/`)
        setCompanyData(response.data)
        setUpdatedCompany(response.data)
      } catch (error) {
        console.error('Failed to fetch company data:', error)
      }
    }
    fetchCompanyData()
  }, [])

  const handleLogout = () => {
    localStorage.removeItem('accessToken')
    localStorage.removeItem('refreshToken')
    localStorage.removeItem('user_id')
    localStorage.removeItem('user_type')
    router.push('/login')
  }

  const handleUpdate = async () => {
    const token = localStorage.getItem('accessToken')
    const _user = localStorage.getItem("user_id")
    try {
      await axios.put(`http://localhost:8000/api/companies/${_user}/`, updatedCompany, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      setCompanyData(updatedCompany)
      setIsModalOpen(false)
      toast.success('Profile updated successfully!', {
        style: {
          background: '#4CAF50',
          color: '#fff'
        }
      })
    } catch (error) {
      console.error('Update error:', error)
      toast.error('Failed to update profile', {
        style: {
          background: '#EF4444',
          color: '#fff'
        }
      })
    }
  }

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100
      }
    }
  }

  if (!companyData) return (
    <div className="min-h-screen flex items-center justify-center">
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360]
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "linear"
        }}
        className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full"
      />
    </div>
  )

  return (
    <motion.div 
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className="min-h-screen"
    >
      {/* Header with Logout */}
      <motion.div 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="bg-white/80 backdrop-blur-sm shadow-lg sticky top-0 z-50"
      >
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <motion.h1 
            whileHover={{ scale: 1.05 }}
            className="text-xl font-semibold text-gray-800"
          >
            Company Dashboard
          </motion.h1>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleLogout}
            className="flex items-center px-4 py-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors duration-200"
          >
            <FaSignOutAlt className="mr-2" />
            Logout
          </motion.button>
        </div>
      </motion.div>

      <div className="max-w-6xl mx-auto p-8">
        <motion.div 
          variants={itemVariants}
          className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300"
        >
          <div className="flex flex-col md:flex-row gap-12">
            <motion.div 
              variants={itemVariants}
              className="md:w-1/3"
            >
              <motion.div 
                whileHover={{ scale: 1.05 }}
                className="relative aspect-square w-full bg-white rounded-xl shadow-sm overflow-hidden"
              >
                <Image
                  src={companyData.logo || '/default-company-logo.png'}
                  alt={`${companyData.company_name} logo`}
                  fill
                  className="object-contain rounded-lg p-4"
                />
              </motion.div>
            </motion.div>

            <motion.div 
              variants={itemVariants}
              className="md:w-2/3 space-y-6"
            >
              <motion.div layout>
                <motion.h1 
                  variants={itemVariants}
                  className="text-3xl font-bold text-gray-900 mb-4"
                >
                  {companyData.company_name}
                </motion.h1>
                <motion.p 
                  variants={itemVariants}
                  className="text-gray-600 leading-relaxed"
                >
                  {companyData.description}
                </motion.p>
              </motion.div>

              <motion.div 
                variants={itemVariants}
                className="flex flex-col sm:flex-row gap-4 pt-6"
              >
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setIsModalOpen(true)}
                  className="flex items-center justify-center px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 shadow-sm hover:shadow-lg"
                >
                  <FaEdit className="mr-2" />
                  Update Profile
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => router.push('/company/showjob')}
                  className="flex items-center justify-center px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all duration-200 shadow-sm hover:shadow-lg"
                >
                  <FaBriefcase className="mr-2" />
                  Show Created Jobs
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => router.push('/company/createjob')}
                  className="flex items-center justify-center px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all duration-200 shadow-sm hover:shadow-lg"
                >
                  <FaPlus className="mr-2" />
                  Create New Job
                </motion.button>
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-xl shadow-xl w-full max-w-md"
            >
              <div className="px-6 py-4 border-b border-gray-100">
                <h2 className="text-xl font-semibold text-gray-800">Update Profile</h2>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
                  <input
                    type="text"
                    value={updatedCompany?.company_name || ''}
                    onChange={(e) => setUpdatedCompany({ ...updatedCompany!, company_name: e.target.value })}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="Company Name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea
                    value={updatedCompany?.description || ''}
                    onChange={(e) => setUpdatedCompany({ ...updatedCompany!, description: e.target.value })}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all min-h-[100px]"
                    placeholder="Company Description"
                  />
                </div>
              </div>
              <div className="px-6 py-4 bg-gray-50 rounded-b-xl flex justify-end gap-3">
                <button 
                  onClick={() => setIsModalOpen(false)} 
                  className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleUpdate} 
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}
