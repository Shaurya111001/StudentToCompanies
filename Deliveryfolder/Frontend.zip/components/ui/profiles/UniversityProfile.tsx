'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import axios from 'axios'
import { 
  FaSignOutAlt, FaEdit, FaUniversity, 
  FaBook, FaGraduationCap, FaPlus, FaUsers, FaComments 
} from 'react-icons/fa'
import { motion, AnimatePresence } from 'framer-motion'
import toast from 'react-hot-toast'
// import GradientBackground from '../backgrounds/GradientBackground'

interface User {
  id: number
  email: string
  first_name: string
  last_name: string
}

interface Subject {
  id: number
  name: string
  code: string
  description: string
  credits: number
  is_mandatory: boolean
  semester: number
}

interface Course {
  id: number
  name: string
  code: string
  description: string
  duration: string
  credits: number
  subjects: Subject[]
}

interface Department {
  id: number
  name: string
  description: string
  head_of_department: string
  courses: Course[]
}

interface UniversityData {
  id: number
  user: User
  university_code: string
  description: string
  location: string
  website: string
  departments: Department[]
}

export default function UniversityProfile() {
  const router = useRouter()
  const [universityData, setUniversityData] = useState<UniversityData | null>(null)
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false)
  const [isDepartmentModalOpen, setIsDepartmentModalOpen] = useState(false)
  const [isCourseModalOpen, setIsCourseModalOpen] = useState(false)
  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false)
  const [selectedDepartment, setSelectedDepartment] = useState<Department | null>(null)
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null)
  const [updatedUniversity, setUpdatedUniversity] = useState<UniversityData | null>(null)
  const [newDepartment, setNewDepartment] = useState({
    name: '',
    description: '',
    head_of_department: ''
  })
  const [newCourse, setNewCourse] = useState({
    name: '',
    code: '',
    description: '',
    duration: '',
    credits: 0
  })
  const [newSubject, setNewSubject] = useState({
    name: '',
    code: '',
    description: '',
    credits: 0,
    is_mandatory: true,
    semester: 1
  })

  useEffect(() => {
    const fetchUniversityData = async () => {
      const token = localStorage.getItem('accessToken')
      const userId = localStorage.getItem('user_id')

      try {
        const response = await axios.get(`http://localhost:8000/api/universities/${userId}/`)
        setUniversityData(response.data)
        setUpdatedUniversity(response.data)
      } catch (error) {
        console.error('Failed to fetch university data:', error)
        toast.error('Failed to load profile data')
      }
    }
    fetchUniversityData()
  }, [])

  const handleLogout = () => {
    localStorage.removeItem('accessToken')
    localStorage.removeItem('refreshToken')
    localStorage.removeItem('user_id')
    localStorage.removeItem('user_type')
    router.push('/login')
  }

  const handleProfileUpdate = async () => {
    const token = localStorage.getItem('accessToken')
    const userId = localStorage.getItem('user_id')
    try {
      const updateData = {
        user: {
          first_name: updatedUniversity?.user?.first_name,
          last_name: updatedUniversity?.user?.last_name
        },
        university_code: updatedUniversity?.university_code,
        description: updatedUniversity?.description,
        location: updatedUniversity?.location,
        website: updatedUniversity?.website
      }

      const response = await axios.put(
        `http://localhost:8000/api/universities/${userId}/`,
        updateData,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      )
      setUniversityData(response.data)
      setIsProfileModalOpen(false)
      toast.success('Profile updated successfully!')
    } catch (error: any) {
      console.error('Update error:', error)
      toast.error(error.response?.data?.error || 'Failed to update profile')
    }
  }

  const handleAddDepartment = async () => {
    const token = localStorage.getItem('accessToken')
    const userId = localStorage.getItem('user_id')
    try {
      const response = await axios.post(
        `http://localhost:8000/api/universities/${userId}/`,
        { department: newDepartment },
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      )
      setUniversityData({
        ...universityData!,
        departments: [...universityData!.departments, response.data]
      })
      setIsDepartmentModalOpen(false)
      toast.success('Department added successfully!')
    } catch (error: any) {
      console.error('Add department error:', error)
      toast.error(error.response?.data?.error || 'Failed to add department')
    }
  }

  const handleAddCourse = async () => {
    if (!selectedDepartment) return

    const token = localStorage.getItem('accessToken')
    try {
      const response = await axios.post(
        `http://localhost:8000/api/departments/${selectedDepartment.id}/`,
        newCourse,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      )
      
      // Update the local state with the new course
      const updatedDepartments = universityData!.departments.map(dept => {
        if (dept.id === selectedDepartment.id) {
          return {
            ...dept,
            courses: [...dept.courses, response.data]
          }
        }
        return dept
      })
      
      setUniversityData({
        ...universityData!,
        departments: updatedDepartments
      })
      setIsCourseModalOpen(false)
      toast.success('Course added successfully!')
    } catch (error: any) {
      console.error('Add course error:', error)
      toast.error(error.response?.data?.error || 'Failed to add course')
    }
  }

  const handleAddSubject = async () => {
    if (!selectedCourse) return;

    const token = localStorage.getItem('accessToken');
    try {
      const response = await axios.post(
        `http://localhost:8000/api/courses/${selectedCourse.id}/`,
        newSubject,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      // Update the local state with the new subject
      const updatedDepartments = universityData!.departments.map(dept => ({
        ...dept,
        courses: dept.courses.map(course => {
          if (course.id === selectedCourse.id) {
            return {
              ...course,
              subjects: [...course.subjects, response.data]
            };
          }
          return course;
        })
      }));
      
      setUniversityData({
        ...universityData!,
        departments: updatedDepartments
      });
      setIsSubjectModalOpen(false);
      toast.success('Subject added successfully!');
    } catch (error: any) {
      console.error('Add subject error:', error);
      toast.error(error.response?.data?.error || 'Failed to add subject');
    }
  };

  if (!universityData) return (
    <div className="min-h-screen flex items-center justify-center">
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360]
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "linear"
        }}
        className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full"
      />
    </div>
  )

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen"
    >
      {/* <GradientBackground /> */}
      
      {/* Header */}
      <motion.div 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="bg-white/80 backdrop-blur-sm shadow-lg sticky top-0 z-50"
      >
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-semibold text-gray-800">University Dashboard</h1>
          <button
            onClick={handleLogout}
            className="flex items-center px-4 py-2 text-red-600 hover:text-red-700"
          >
            <FaSignOutAlt className="mr-2" />
            Logout
          </button>
        </div>
      </motion.div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto p-8">
        {/* Header with View Students and Feedback Buttons */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">University Profile</h1>
            <p className="mt-2 text-gray-600">Manage your university information and departments</p>
          </div>
          <div className="flex gap-4">
            <button
              onClick={() => router.push('/university/students')}
              className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              <FaUsers className="w-5 h-5" />
              View Students
            </button>
            <button
              onClick={() => router.push('/university/feedback')}
              className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
            >
              <FaComments className="w-5 h-5" />
              View Feedback
            </button>
          </div>
        </div>

        {/* Profile Section */}
        <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-8 mb-8">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                {universityData.user.first_name} {universityData.user.last_name}
              </h2>
              <p className="text-gray-600">{universityData.user.email}</p>
              <p className="text-gray-600">Code: {universityData.university_code}</p>
              <p className="text-gray-600">Location: {universityData.location}</p>
              {universityData.website && (
                <a 
                  href={universityData.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-500 hover:text-blue-600"
                >
                  Website
                </a>
              )}
            </div>
            <button
              onClick={() => setIsProfileModalOpen(true)}
              className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
            >
              <FaEdit className="mr-2" />
              Edit Profile
            </button>
          </div>
          <p className="text-gray-700">{universityData.description}</p>
        </div>

        {/* Departments Section */}
        <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-8">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-2xl font-semibold text-gray-800">Departments</h3>
            <button
              onClick={() => setIsDepartmentModalOpen(true)}
              className="flex items-center px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600"
            >
              <FaPlus className="mr-2" />
              Add Department
            </button>
          </div>
          
          <div className="space-y-6">
            {universityData.departments.map((department) => (
              <div key={department.id} className="border-l-4 border-blue-500 pl-4">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="text-xl font-semibold text-gray-800">{department.name}</h4>
                    <p className="text-gray-600">Head: {department.head_of_department}</p>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedDepartment(department)
                      setIsCourseModalOpen(true)
                    }}
                    className="flex items-center px-3 py-1 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200"
                  >
                    <FaPlus className="mr-2" />
                    Add Course
                  </button>
                </div>
                
                {department.courses.length > 0 && (
                  <div className="ml-4 space-y-4">
                    {department.courses.map((course) => (
                      <div key={course.id} className="bg-white/80 backdrop-blur-sm rounded-lg p-4 shadow">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h5 className="text-lg font-semibold">{course.name}</h5>
                            <p className="text-sm text-gray-600">Code: {course.code}</p>
                          </div>
                          <button
                            onClick={() => {
                              setSelectedCourse(course);
                              setIsSubjectModalOpen(true);
                            }}
                            className="text-blue-500 hover:text-blue-600"
                          >
                            <FaPlus className="w-5 h-5" />
                          </button>
                        </div>
                        <p className="text-sm text-gray-700 mb-2">{course.description}</p>
                        <div className="text-sm text-gray-600">
                          <p>Duration: {course.duration}</p>
                          <p>Credits: {course.credits}</p>
                        </div>
                        {/* Display Subjects */}
                        {course.subjects && course.subjects.length > 0 && (
                          <div className="mt-4">
                            <h6 className="font-medium mb-2">Subjects:</h6>
                            <div className="space-y-2">
                              {course.subjects.map((subject) => (
                                <div key={subject.id} className="bg-gray-50 p-2 rounded">
                                  <div className="flex justify-between">
                                    <span className="font-medium">{subject.name}</span>
                                    <span className="text-sm text-gray-600">Code: {subject.code}</span>
                                  </div>
                                  <p className="text-sm text-gray-700">{subject.description}</p>
                                  <div className="text-sm text-gray-600 mt-1">
                                    <span>Credits: {subject.credits}</span>
                                    <span className="mx-2">•</span>
                                    <span>Semester: {subject.semester}</span>
                                    <span className="mx-2">•</span>
                                    <span>{subject.is_mandatory ? 'Mandatory' : 'Elective'}</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Profile Update Modal */}
      <AnimatePresence>
        {isProfileModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-white rounded-xl shadow-xl w-full max-w-md"
            >
              <div className="p-6">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">Update Profile</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      First Name
                    </label>
                    <input
                      type="text"
                      value={updatedUniversity?.user?.first_name || ''}
                      onChange={(e) => setUpdatedUniversity({
                        ...updatedUniversity!,
                        user: {
                          ...updatedUniversity!.user,
                          first_name: e.target.value
                        }
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Last Name
                    </label>
                    <input
                      type="text"
                      value={updatedUniversity?.user?.last_name || ''}
                      onChange={(e) => setUpdatedUniversity({
                        ...updatedUniversity!,
                        user: {
                          ...updatedUniversity!.user,
                          last_name: e.target.value
                        }
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      University Code
                    </label>
                    <input
                      type="text"
                      value={updatedUniversity?.university_code || ''}
                      onChange={(e) => setUpdatedUniversity({
                        ...updatedUniversity!,
                        university_code: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Location
                    </label>
                    <input
                      type="text"
                      value={updatedUniversity?.location || ''}
                      onChange={(e) => setUpdatedUniversity({
                        ...updatedUniversity!,
                        location: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Website
                    </label>
                    <input
                      type="url"
                      value={updatedUniversity?.website || ''}
                      onChange={(e) => setUpdatedUniversity({
                        ...updatedUniversity!,
                        website: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Description
                    </label>
                    <textarea
                      value={updatedUniversity?.description || ''}
                      onChange={(e) => setUpdatedUniversity({
                        ...updatedUniversity!,
                        description: e.target.value
                      })}
                      rows={4}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                </div>
              </div>
              <div className="p-4 bg-gray-50 rounded-b-xl flex justify-end gap-3">
                <button
                  onClick={() => setIsProfileModalOpen(false)}
                  className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={handleProfileUpdate}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                >
                  Save Changes
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Department Modal */}
      <AnimatePresence>
        {isDepartmentModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-white rounded-xl shadow-xl w-full max-w-md"
            >
              <div className="p-6">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">Add Department</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Department Name
                    </label>
                    <input
                      type="text"
                      value={newDepartment.name}
                      onChange={(e) => setNewDepartment({
                        ...newDepartment,
                        name: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Head of Department
                    </label>
                    <input
                      type="text"
                      value={newDepartment.head_of_department}
                      onChange={(e) => setNewDepartment({
                        ...newDepartment,
                        head_of_department: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Description
                    </label>
                    <textarea
                      value={newDepartment.description}
                      onChange={(e) => setNewDepartment({
                        ...newDepartment,
                        description: e.target.value
                      })}
                      rows={4}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                </div>
              </div>
              <div className="p-4 bg-gray-50 rounded-b-xl flex justify-end gap-3">
                <button
                  onClick={() => setIsDepartmentModalOpen(false)}
                  className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddDepartment}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                >
                  Add Department
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Course Modal */}
      <AnimatePresence>
        {isCourseModalOpen && selectedDepartment && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-white rounded-xl shadow-xl w-full max-w-md"
            >
              <div className="p-6">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  Add Course to {selectedDepartment.name}
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Course Name
                    </label>
                    <input
                      type="text"
                      value={newCourse.name}
                      onChange={(e) => setNewCourse({
                        ...newCourse,
                        name: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Course Code
                    </label>
                    <input
                      type="text"
                      value={newCourse.code}
                      onChange={(e) => setNewCourse({
                        ...newCourse,
                        code: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Duration
                    </label>
                    <input
                      type="text"
                      value={newCourse.duration}
                      onChange={(e) => setNewCourse({
                        ...newCourse,
                        duration: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                      placeholder="e.g., 4 years"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Credits
                    </label>
                    <input
                      type="number"
                      value={newCourse.credits}
                      onChange={(e) => setNewCourse({
                        ...newCourse,
                        credits: parseInt(e.target.value)
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Description
                    </label>
                    <textarea
                      value={newCourse.description}
                      onChange={(e) => setNewCourse({
                        ...newCourse,
                        description: e.target.value
                      })}
                      rows={4}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                </div>
              </div>
              <div className="p-4 bg-gray-50 rounded-b-xl flex justify-end gap-3">
                <button
                  onClick={() => {
                    setIsCourseModalOpen(false)
                    setSelectedDepartment(null)
                  }}
                  className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddCourse}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                >
                  Add Course
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Subject Modal */}
      <AnimatePresence>
        {isSubjectModalOpen && selectedCourse && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-white rounded-xl shadow-xl w-full max-w-md"
            >
              <div className="p-6">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  Add Subject to {selectedCourse.name}
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Subject Name
                    </label>
                    <input
                      type="text"
                      value={newSubject.name}
                      onChange={(e) => setNewSubject({
                        ...newSubject,
                        name: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Subject Code
                    </label>
                    <input
                      type="text"
                      value={newSubject.code}
                      onChange={(e) => setNewSubject({
                        ...newSubject,
                        code: e.target.value
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Credits
                    </label>
                    <input
                      type="number"
                      value={newSubject.credits}
                      onChange={(e) => setNewSubject({
                        ...newSubject,
                        credits: parseInt(e.target.value)
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Semester
                    </label>
                    <input
                      type="number"
                      value={newSubject.semester}
                      onChange={(e) => setNewSubject({
                        ...newSubject,
                        semester: parseInt(e.target.value)
                      })}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={newSubject.is_mandatory}
                        onChange={(e) => setNewSubject({
                          ...newSubject,
                          is_mandatory: e.target.checked
                        })}
                        className="rounded border-gray-300"
                      />
                      <span className="text-sm font-medium text-gray-700">
                        Is Mandatory
                      </span>
                    </label>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Description
                    </label>
                    <textarea
                      value={newSubject.description}
                      onChange={(e) => setNewSubject({
                        ...newSubject,
                        description: e.target.value
                      })}
                      rows={4}
                      className="w-full p-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                </div>
              </div>
              <div className="p-4 bg-gray-50 rounded-b-xl flex justify-end gap-3">
                <button
                  onClick={() => {
                    setIsSubjectModalOpen(false);
                    setSelectedCourse(null);
                  }}
                  className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddSubject}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                >
                  Add Subject
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}