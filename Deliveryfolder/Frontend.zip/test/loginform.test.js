import { expect } from 'chai';

describe('LoginForm', () => {
  it('should pass a basic test', () => {
    expect(true).to.equal(true);
  });
}); 