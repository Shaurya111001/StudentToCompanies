import { expect } from 'chai';
import { render, fireEvent } from '@testing-library/react';
import LoginForm from '../components/ui/LoginForm.tsx';

describe('LoginForm Component', function() {
  it('should render LoginForm without crashing', function() {
    const { getByText } = render(<LoginForm />);
    expect(getByText('Sign In')).to.exist;
  });

  it('should display error message on failed login', async function() {
    const { getByText, getByPlaceholderText } = render(<LoginForm />);
    fireEvent.change(getByPlaceholderText('Email Address'), { target: { value: 'wrong@example.com' } });
    fireEvent.change(getByPlaceholderText('Password'), { target: { value: 'wrongpassword' } });
    fireEvent.click(getByText('Sign In'));

    // Simulate error response
    await new Promise((r) => setTimeout(r, 1000)); // Wait for async actions
    expect(getByText('Login failed. Please try again.')).to.exist;
  });
});