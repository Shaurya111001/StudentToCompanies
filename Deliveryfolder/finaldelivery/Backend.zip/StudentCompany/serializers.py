from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import Student, Company, Internship, Application, University, Feedback, Complaint, Interview, Skill, Experience, ExtractedSkill, Subject, Course, Department
# from .user_serializers import UserSerializer

User = get_user_model()

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['email', 'first_name', 'last_name', 'password', 'is_active', 'user_type']
        extra_kwargs = {
            'password': {'write_only': True}  # Ensure password is write-only
        }

    def create(self, validated_data):
        user = User(
            email=validated_data['email'],
            first_name=validated_data['first_name'],
            # last_name=validated_data['last_name'],
            user_type=validated_data['user_type']
        )
        user.set_password(validated_data['password'])  # Hash the password
        user.save()
        return user

class SkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = Skill
        fields = ['id', 'name', 'category']

class ExperienceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Experience
        fields = ['id', 'title', 'company', 'start_date', 'end_date', 'description', 'is_current']

class ExtractedSkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExtractedSkill
        fields = ['id', 'skill_name']

class StudentSerializer(serializers.ModelSerializer):
    user = UserSerializer()  # Nested serializer for user details
    skills = SkillSerializer(many=True, read_only=True)
    experiences = ExperienceSerializer(many=True, read_only=True)
    extracted_skills = ExtractedSkillSerializer(many=True, read_only=True)

    class Meta:
        model = Student
        fields = [
            'id', 'user', 'university', 'department', 'course',
            'cv', 'cv_file', 'profile', 'skills',
            'experiences', 'extracted_skills', 'last_cv_update'
        ]
        read_only_fields = ['cv', 'extracted_skills', 'last_cv_update']

    def create(self, validated_data):
        user_data = validated_data.pop('user')
        user = UserSerializer.create(UserSerializer(), validated_data=user_data)
        student = Student.objects.create(user=user, **validated_data)
        return student

    def update(self, instance, validated_data):
        # Handle nested user data update
        if 'user' in validated_data:
            user_data = validated_data.pop('user')
            user = instance.user
            
            # Update user fields
            for attr, value in user_data.items():
                setattr(user, attr, value)
            user.save()

        # Update student fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        
        return instance

class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['id', 'user', 'company_name', 'logo', 'description']  # Include any other fields you need

class InternshipSerializer(serializers.ModelSerializer):
    company = CompanySerializer(read_only=True)  # For reading company data
    company_id = serializers.PrimaryKeyRelatedField(
        queryset=Company.objects.all(),
        write_only=True,
        source='company'
    )

    class Meta:
        model = Internship
        fields = ['id', 'title', 'description', 'skills_required', 'is_paid', 
                 'start_date', 'end_date', 'company', 'company_id']

    def create(self, validated_data):
        # Create the internship with the provided company
        return Internship.objects.create(**validated_data)

class InterviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Interview
        fields = ['id', 'date_time', 'location', 'interview_type', 'notes', 'status']

class ApplicationSerializer(serializers.ModelSerializer):
    student = serializers.PrimaryKeyRelatedField(queryset=Student.objects.all())
    internship = InternshipSerializer()  # Use the nested InternshipSerializer
    interviews = InterviewSerializer(many=True, read_only=True)  # Include interviews

    class Meta:
        model = Application
        fields = ['id', 'student', 'internship', 'date_applied', 'description', 'status', 'interviews']
        read_only_fields = ['date_applied', 'status']  # Status will be 'applied' by default

    def create(self, validated_data):
        user_id = validated_data.pop('student')
        try:
            student = Student.objects.get(user_id=user_id)
            validated_data['status'] = 'applied'
            validated_data['student'] = student
            return super().create(validated_data)
        except Student.DoesNotExist:
            raise serializers.ValidationError("Student not found for this user")

class SubjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subject
        fields = ['id', 'name', 'code', 'description', 'credits', 'is_mandatory', 'semester']

class CourseSerializer(serializers.ModelSerializer):
    subjects = SubjectSerializer(many=True, read_only=True)
    
    class Meta:
        model = Course
        fields = ['id', 'name', 'code', 'description', 'duration', 'credits', 'subjects']

class DepartmentSerializer(serializers.ModelSerializer):
    courses = CourseSerializer(many=True, read_only=True)
    
    class Meta:
        model = Department
        fields = ['id', 'name', 'description', 'head_of_department', 'courses']

class UniversitySerializer(serializers.ModelSerializer):
    user = UserSerializer()
    departments = DepartmentSerializer(many=True, read_only=True)

    class Meta:
        model = University
        fields = ['id', 'user', 'university_code', 'description', 'location', 'website', 'departments']
        read_only_fields = ['id']

    def create(self, validated_data):
        return University.objects.create(**validated_data)

    def update(self, instance, validated_data):
        # Handle nested user data update
        if 'user' in validated_data:
            user_data = validated_data.pop('user')
            user = instance.user
            for attr, value in user_data.items():
                setattr(user, attr, value)
            user.save()

        # Update university fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        
        return instance

class FeedbackSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)  # Nested serializer for reading
    user_id = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.all(), 
        source='user',
        write_only=True
    )  # F

    class Meta:
        model = Feedback
        fields = ['id', 'user','user_id', 'message', 'rating', 'date_submitted']
        read_only_fields = ['date_submitted']
    def create(self, validated_data):
        return super().create(validated_data)

class ComplaintSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(queryset=User.objects.all(), required=True)

    class Meta:
        model = Feedback
        fields = ['id', 'user', 'message', 'rating', 'date_submitted']  # Exclude user field

    def create(self, validated_data):
        # The user is set in the view, so we don't need to handle it here
        return super().create(validated_data)



