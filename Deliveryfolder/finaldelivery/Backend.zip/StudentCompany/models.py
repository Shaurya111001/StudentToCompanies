from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from django.core.validators import MinValueValidator, MaxValueValidator
from django.contrib.auth import get_user_model
from .utils.PDFProcessor import PDFProcessor

class UserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError(_("The Email field must be set"))
        email = self.normalize_email(email)
        extra_fields.setdefault('is_active', True)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user
    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault("is_active", True)

        if not extra_fields.get('is_staff'):
            raise ValueError(_("Superuser must have is_staff=True."))
        if not extra_fields.get('is_superuser'):
            raise ValueError(_("Superuser must have is_superuser=True."))

        return self.create_user(email, password, **extra_fields)
    


class User(AbstractBaseUser, PermissionsMixin):
    first_name = models.CharField(max_length=25)
    last_name = models.CharField(max_length=25, blank=True, null=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=255)
    country_code = models.CharField(max_length=5, blank=True, null=True)
    phone_number = models.CharField(max_length=25, blank=True, null=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)

    USER_TYPE_CHOICES = [
    ('student', 'Student'),
    ('company', 'Company'),
    ('university', 'University'),
    ]
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES)
    
    objects = UserManager()
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["first_name", "last_name","password", "user_type"]
    

    def __str__(self):
        return self.email



class Skill(models.Model):
    name = models.CharField(max_length=100)
    category = models.CharField(max_length=100)  # e.g., "Technical", "Soft Skills", "Languages"
    
    def __str__(self):
        return self.name

class Experience(models.Model):
    title = models.CharField(max_length=200)
    company = models.CharField(max_length=200)
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    description = models.TextField()
    is_current = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.title} at {self.company}"

class ExtractedSkill(models.Model):
    student = models.ForeignKey('Student', on_delete=models.CASCADE, related_name='extracted_skills')
    skill_name = models.CharField(max_length=100)
    
    def __str__(self):
        return self.skill_name

class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='student_profile')
    profile = models.ImageField(upload_to='student_profile/', null=True, blank=True)
    university = models.CharField(max_length=100)
    department = models.CharField(max_length=100, null=True, blank=True)
    course = models.CharField(max_length=200, null=True, blank=True)
    cv = models.TextField(blank=True)  # Stores the extracted text from CV
    cv_file = models.FileField(upload_to='student_cvs/', null=True, blank=True)
    skills = models.ManyToManyField(Skill, related_name='students', blank=True)
    experiences = models.ManyToManyField(Experience, related_name='students', blank=True)
    last_cv_update = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.email}'s Profile"

    def update_cv_and_extract_data(self):
        """Update CV text and extract skills when CV file is updated"""
        if self.cv_file:
            # Extract text from CV using the file object directly
            from .utils.PDFProcessor import PDFProcessor
            
            # Save the file first to ensure it's on disk
            self.save()
            
            # Use the absolute path of the saved file
            file_path = self.cv_file.path
            print(f"Processing CV file at: {file_path}")
            
            try:
                extracted_text = PDFProcessor.extract_text(file_path)
                # print(extracted_text)
                self.cv = extracted_text
                self.save()
                print("CV text extracted successfully")
            except Exception as e:
                print(f"Error extracting CV text: {str(e)}")
                raise


class Company(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='company_profile')
    company_name = models.CharField(max_length=100)
    logo = models.ImageField(upload_to='company_logo/', null=True, blank=True)
    description = models.TextField()


class Internship(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='internships')
    title = models.CharField(max_length=100)
    description = models.TextField()
    skills_required = models.TextField()
    is_paid = models.BooleanField(default=False)
    start_date = models.DateField()
    end_date = models.DateField()


class Application(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='applications')
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, related_name='applications')
    date_applied = models.DateTimeField(auto_now_add=True)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=50, choices=[
        ('applied', 'Applied'),
        ('under_review', 'Under Review'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected')
    ], default='applied')


class Feedback(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='feedbacks')
    message = models.TextField()
    rating = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        help_text="Rating from 1 to 5",
        default=3
    )
    date_submitted = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback from {self.user.email} on {self.date_submitted.date()}"

    class Meta:
        ordering = ['-date_submitted']


class Complaint(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='complaints')
    message = models.TextField()
    status = models.CharField(max_length=50, choices=[
        ('submitted', 'Submitted'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved')
    ], default='submitted')
    date_submitted = models.DateTimeField(auto_now_add=True)
    resolution_notes = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Complaint from {self.user.email} - {self.status}"

    class Meta:
        ordering = ['-date_submitted']


class Interview(models.Model):
    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name='interviews')
    date_time = models.DateTimeField()
    location = models.CharField(max_length=255)  # Can be physical address or virtual meeting link
    interview_type = models.CharField(
        max_length=20,
        choices=[
            ('online', 'Online'),
            ('in_person', 'In Person'),
        ],
        default='online'
    )
    notes = models.TextField(blank=True, null=True)  # Additional notes or instructions
    status = models.CharField(
        max_length=20,
        choices=[
            ('scheduled', 'Scheduled'),
            ('completed', 'Completed'),
            ('cancelled', 'Cancelled'),
            ('rescheduled', 'Rescheduled'),
        ],
        default='scheduled'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Interview for {self.application.student.user.email} - {self.application.internship.title}"

    class Meta:
        ordering = ['-date_time']


class University(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='university_profile')
    university_code = models.CharField(max_length=10)
    description = models.TextField(blank=True, null=True)
    location = models.CharField(max_length=255)
    website = models.URLField(max_length=200, blank=True, null=True)

    def __str__(self):
        return self.user.email

    class Meta:
        verbose_name_plural = "Universities"


class Department(models.Model):
    university = models.ForeignKey(University, on_delete=models.CASCADE, related_name='departments')
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    head_of_department = models.CharField(max_length=100, blank=True, null=True)
    
    def __str__(self):
        return f"{self.name} - {self.university.user.email}"

class Course(models.Model):
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='courses')
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20)
    description = models.TextField(blank=True, null=True)
    duration = models.CharField(max_length=50, help_text="e.g., '4 years', '2 semesters'")
    credits = models.IntegerField(help_text="Total credits for the course")
    
    def __str__(self):
        return f"{self.code} - {self.name}"

class Subject(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='subjects')
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20)
    description = models.TextField(blank=True, null=True)
    credits = models.IntegerField()
    is_mandatory = models.BooleanField(default=True)
    semester = models.IntegerField(help_text="Semester number when this subject is taught")
    
    def __str__(self):
        return f"{self.code} - {self.name}"




