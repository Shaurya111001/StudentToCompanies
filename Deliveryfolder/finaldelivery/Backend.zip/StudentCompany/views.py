from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .utils.Recommendation import Recommendation
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import get_user_model
from .serializers import UserSerializer, CompanySerializer
from rest_framework_simplejwt.exceptions import TokenError, InvalidToken
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.viewsets import ModelViewSet
from .models import Student, Internship, Company, ExtractedSkill, Skill, Experience
from .serializers import StudentSerializer, InternshipSerializer
from .models import User
from .serializers import ApplicationSerializer
from .models import Application
from .models import Interview
from .serializers import InterviewSerializer
from .models import University
from .serializers import UniversitySerializer
from .models import Feedback
from .serializers import FeedbackSerializer
from .models import Complaint
from .serializers import ComplaintSerializer
from .models import Department
from .serializers import DepartmentSerializer
from .models import Course
from .serializers import CourseSerializer
from .models import Subject
from .serializers import SubjectSerializer
from rest_framework import generics
import json
from rest_framework.authentication import TokenAuthentication
from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone
import re


def get_tokens_for_user(user):

    refresh = RefreshToken.for_user(user)
    return {

    'refresh': str(refresh),
    'access': str(refresh.access_token),

}





class RegisterView(APIView):
    permission_classes = [AllowAny] 
    def post(self, request):
        user_data_dict = request.data.get('user', {})
        serializer = UserSerializer(data=user_data_dict)
        
        if serializer.is_valid():
            user = serializer.save()
            out = {}
            tokens = get_tokens_for_user(user)
            
            if user_data_dict["user_type"] == "university":
                universitydata = {
                    "university_code": request.data.get("university_code", ""),
                    "description": request.data.get("description", ""),
                    "location": request.data.get("location", ""),
                    "website": request.data.get("website", ""),
                    "user": user.id
                }
                print(universitydata)  # Debug print to see the data being sent to serializer
                serializer = UniversitySerializer(data=universitydata)
                if serializer.is_valid():
                    serializer.save()
                    out["user_id"] = user.id
                    out["user_type"] = user.user_type
                    out["tokens"] = tokens
                    return Response(out, status=status.HTTP_201_CREATED)
                print(serializer.errors)  # Debug print to see validation errors
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
            elif user_data_dict["user_type"] == "student":
                studentdata = {
                    "university": user_data_dict["university"], 
                    "cv_file": request.data.get("cv_file"), 
                    "user": user.id  # Changed: Pass user.id instead of user object
                }
                serializer = StudentSerializer(data=studentdata)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
            elif user_data_dict["user_type"] == "company":
                companydata = {
                    "company_name": user_data_dict.get("company_name", ""),  # Changed: Use get() with default
                    "description": user_data_dict.get("description", ""),
                    "user": user.id  # Changed: Pass user.id instead of user object
                }
                serializer = CompanySerializer(data=companydata)
                if serializer.is_valid():
                    serializer.save()
                    out["user_id"] = user.id
                    out["user_type"] = user.user_type
                    out["tokens"] = tokens
                    return Response(out, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            out["user_id"] = user.id
            out["type"] = user.user_type
            out["tokens"] = tokens
            return Response(out, status=status.HTTP_201_CREATED)
        
        print(serializer.errors)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    permission_classes = [AllowAny] 
    def post(self, request):
        username = request.data.get('email')
        password = request.data.get('password')
        out = {}
        try:
            user = get_user_model().objects.get(email=username)
            if not(user.check_password(password)):
                tokens = get_tokens_for_user(user)
                out["user_id"] = user.id
                out["type"] = user.user_type
                out["tokens"] = tokens
                return Response(out, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "Invalid credentials"}, status=status.HTTP_400_BAD_REQUEST)
        except get_user_model().DoesNotExist:
            return Response({"detail": "User not found"}, status=status.HTTP_400_BAD_REQUEST)
        

        



class LogoutView(APIView):
    def post(self, request):
        # Retrieve the refresh token from cookies
        refresh_token = request.COOKIES.get('refresh_token')

        if not refresh_token:
            return Response({"error": "Refresh token is missing."}, status=status.HTTP_400_BAD_REQUEST)
        

        try:
            # Create a RefreshToken instance from the refresh token string
            print(refresh_token)
            token = RefreshToken(refresh_token)

            # Blacklist the refresh token to invalidate it
            token.blacklist()

            # Successfully logged out
            return Response({"message": "Successfully logged out."}, status=status.HTTP_200_OK)

        except (TokenError, InvalidToken) as e:
            # If the token is invalid or expired, return an error response
            return Response({"error": "Invalid or expired refresh token."}, status=status.HTTP_400_BAD_REQUEST)



class StudentView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request, pk=None):
        if pk:
            try:
                student = Student.objects.get(user_id=pk)
                serializer = StudentSerializer(student)
                return Response(serializer.data)
            except Student.DoesNotExist:
                return Response(
                    {"error": "Student not found"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
        
        students = Student.objects.all()
        serializer = StudentSerializer(students, many=True)
        return Response(serializer.data)

    def post(self, request):
        if request.user.user_type != 'student':
            return Response(
                {"error": "Only students can create student profiles"},
                status=status.HTTP_403_FORBIDDEN
            )
        email = request.data.get('user', {}).get('email', None)

        if not email:
            return Response(
                {"error": "Email is required"},
                status=status.HTTP_400_BAD_REQUEST
            )
        print(request.data)
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response(
                {"error": "User with this email does not exist"},
                status=status.HTTP_404_NOT_FOUND
            )

        # Now you can create the student profile
        request.data['user'] = user.id  # Set the user ID in the request data

        serializer = StudentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        print(serializer.errors)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            student = Student.objects.get(user_id=pk)
            
            # Check if the user is updating their own profile
            # if request.user != student.user:
            #     return Response(
            #         {"error": "You can only update your own profile"},
            #         status=status.HTTP_403_FORBIDDEN
            #     )
            serializer = StudentSerializer(student, data=request.data, partial=True)
            if serializer.is_valid():
                print(request.data)
                serializer.save()
                return Response(serializer.data)
            print(serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Student.DoesNotExist:
            return Response(
                {"error": "Student not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
    def patch(self, request, pk):
        try:
            student = Student.objects.get(user_id=pk)
            
            # Check if this is a CV update
            if 'cv_file' in request.FILES:
                print("Processing CV update")
                student.cv_file = request.FILES['cv_file']
                student.update_cv_and_extract_data()
                print("CV data extracted")
                
                # Clear old extracted skills
                ExtractedSkill.objects.filter(student=student).delete()
                print("Old skills cleared")
                
                # Extract and save new skills
                extracted_skills = self.extract_skills_from_cv(student.cv)
                if extracted_skills:  # Check if skills were extracted
                    print("New skills extracted:", extracted_skills)
                    for skill in extracted_skills:
                        ExtractedSkill.objects.create(
                            student=student,
                            skill_name=skill
                        )
                    print("New skills saved")
                else:
                    print("No skills were extracted from the CV")
            
            # Handle other field updates
            serializer = StudentSerializer(student, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except Student.DoesNotExist:
            return Response(
                {"error": "Student not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            print(f"Error in patch: {str(e)}")
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def delete(self, request, pk):
        try:
            student = Student.objects.get(user_id=pk)
            
            # Check if the user is deleting their own profile
            if request.user != student.user:
                return Response(
                    {"error": "You can only delete your own profile"},
                    status=status.HTTP_403_FORBIDDEN
                )

            student.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Student.DoesNotExist:
            return Response(
                {"error": "Student not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

    def extract_skills_from_cv(self, cv_text):
        """Extract skills from CV text using basic pattern matching."""
        if not cv_text:
            return []  # Return empty list instead of None
            
        # Common technical skills patterns
        tech_skills_pattern = r'\b(Python|Java|JavaScript|React|Node\.js|SQL|HTML|CSS|Git|Docker|AWS|Azure|MongoDB|PostgreSQL|MySQL|TypeScript|Angular|Vue\.js|PHP|C\+\+|Ruby|Swift|Kotlin|Go|Rust|R|MATLAB|TensorFlow|PyTorch|Pandas|NumPy|Linux|Unix|Windows|MacOS)\b'
        
        # Common soft skills patterns
        soft_skills_pattern = r'\b(Leadership|Communication|Teamwork|Problem[- ]Solving|Project Management|Time Management|Analytical|Critical Thinking|Collaboration|Adaptability|Organization|Creativity|Innovation|Strategic Thinking|Decision Making)\b'
        
        try:
            # Find all matches
            tech_skills = set(re.findall(tech_skills_pattern, cv_text, re.IGNORECASE))
            soft_skills = set(re.findall(soft_skills_pattern, cv_text, re.IGNORECASE))
            
            # Combine all skills
            all_skills = list(tech_skills.union(soft_skills))
            
            return all_skills
        except Exception as e:
            print(f"Error extracting skills: {str(e)}")
            return []  # Return empty list on error

class CompanyView(APIView):
    permission_classes = [AllowAny] 

    def get(self, request, pk=None):
        if pk:
            try:
                company = Company.objects.get(user_id=pk)
                serializer = CompanySerializer(company)
                return Response(serializer.data)
            except Company.DoesNotExist:
                return Response(
                    {"error": "Company not found"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
        
        companies = Company.objects.all()
        serializer = CompanySerializer(companies, many=True)
        return Response(serializer.data)

    def post(self, request):
        if request.user.user_type != 'company':
            return Response(
                {"error": "Only company users can create company profiles"},
                status=status.HTTP_403_FORBIDDEN
            )

        serializer = CompanySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            company = Company.objects.get(user_id=pk)
            
            # Check if the user is updating their own profile
            if request.user != company.user:
                return Response(
                    {"error": "You can only update your own company profile"},
                    status=status.HTTP_403_FORBIDDEN
                )

            serializer = CompanySerializer(company, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Company.DoesNotExist:
            return Response(
                {"error": "Company not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

    def delete(self, request, pk):
        try:
            company = Company.objects.get(pk=pk)
            
            # Check if the user is deleting their own profile
            if request.user != company.user:
                return Response(
                    {"error": "You can only delete your own company profile"},
                    status=status.HTTP_403_FORBIDDEN
                )

            company.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Company.DoesNotExist:
            return Response(
                {"error": "Company not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

class RecommendationView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request):
        try:
            user_id = request.query_params.get('user_id')
            if not user_id:
                return Response({"error": "User ID is required"}, status=status.HTTP_400_BAD_REQUEST)

            # Get student profile
            student = Student.objects.select_related('user').get(user_id=user_id)

            # Get student's CV
            student_cv = student.cv if student.cv else ""

            # Format academic info as a single text string for the recommendation engine
            academic_text = f"{student.university or ''} {student.department or ''} {student.course or ''}"
            academic_text += " " + " ".join(student.skills.values_list('name', flat=True)) if student.skills.exists() else ""

            # Get all internships
            internships = Internship.objects.select_related('company').all()
            internships_data = []

            for internship in internships:
                internship_dict = {
                    'id': internship.id,
                    'title': internship.title,
                    'description': internship.description,
                    'skills_required': internship.skills_required,
                    'is_paid': internship.is_paid,
                    'start_date': internship.start_date,
                    'end_date': internship.end_date,
                    'company_id': internship.company.id if internship.company else None
                }
                internships_data.append(internship_dict)

            # Get recommendations
            recommended_ids = Recommendation.get_recommendations(
                internships=internships_data,
                student_cv=f"{student_cv} {academic_text}",  # Combine CV with academic info
                student_academic_info=None  # We've already combined it with the CV
            )

            # Filter and return recommended internships
            recommended_internships = [
                internship for internship in internships_data
                if internship['id'] in recommended_ids
            ]

            return Response({
                'recommendations': recommended_internships
            })

        except Student.DoesNotExist:
            return Response(
                {"error": "Student not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            print(f"Error in RecommendationView: {str(e)}")
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

#2

class InternshipView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request, pk=None):  # Changed from internship_id to pk to match URL pattern
        try:
            # If pk is provided, get specific internship
            if pk is not None:
                internship = Internship.objects.get(id=pk)
                serializer = InternshipSerializer(internship)
                return Response(serializer.data, status=status.HTTP_200_OK)
            
            # Otherwise, handle list view
            user_id = request.query_params.get('user_id')
            
            if user_id:
                company = Company.objects.get(user_id=user_id)
                internships = Internship.objects.filter(company=company)
                if not internships.exists():
                    return Response(
                        {"message": "No internships found for this company"}, 
                        status=status.HTTP_404_NOT_FOUND
                    )
            else:
                internships = Internship.objects.all()

            serializer = InternshipSerializer(internships, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Internship.DoesNotExist:
            return Response(
                {"error": "Internship not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Company.DoesNotExist:
            return Response(
                {"error": "Company not found for this user"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response({
                "error": "An error occurred while fetching internships",
                "details": str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def post(self, request, *args, **kwargs):
        try:
            # Check if user is from a company
            if request.user.user_type != 'company':
                return Response(
                    {"error": "Only company users can create internships"}, 
                    status=status.HTTP_403_FORBIDDEN
                )

            # Transform the incoming data
            data = request.data.copy()
            company_id = data.pop('company')  # Extract the company ID
            user = User.objects.get(id=company_id)
            company = Company.objects.get(user=user)
            
            # Set company_id instead of company data
            data['company_id'] = company.id

            serializer = InternshipSerializer(data=data)
            if serializer.is_valid():
                serializer.save()
                return Response({
                    "message": "Internship created successfully!",
                    "data": serializer.data
                }, status=status.HTTP_201_CREATED)
            
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except User.DoesNotExist:
            return Response({"error": "User not found."}, status=status.HTTP_404_NOT_FOUND)
        except Company.DoesNotExist:
            return Response({"error": "Company not found."}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({
                "error": "An unexpected error occurred",
                "details": str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
class ApplicationView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request, internship_id=None):
        try:
            user_id = request.query_params.get('user_id')
            
            if not user_id:
                return Response({"error": "User ID is required"}, status=status.HTTP_400_BAD_REQUEST)

            user = User.objects.get(id=user_id)

            # Handle different user types
            if user.user_type == 'company':
                company = Company.objects.get(user=user)
                # Filter applications by internship_id if provided
                if internship_id:
                    applications = Application.objects.filter(
                        internship_id=internship_id,
                        internship__company=company
                    )
                else:
                    applications = Application.objects.filter(
                        internship__company=company
                    )
            elif user.user_type == 'student':
                student = Student.objects.get(user=user)
                # Get all applications for this student
                applications = Application.objects.filter(student=student)
            else:
                return Response(
                    {"error": "Invalid user type"},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Use select_related and prefetch_related for both cases
            applications = applications.select_related(
                'student',
                'student__user',
                'internship',
                'internship__company'
            ).prefetch_related('interviews')

            print(f"Found {applications.count()} applications")  # Debug print
            serializer = ApplicationSerializer(applications, many=True)
            return Response(serializer.data)

        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)
        except (Company.DoesNotExist, Student.DoesNotExist):
            return Response({"error": "Profile not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            print(f"Error in ApplicationView GET: {str(e)}")  # Debug print
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def post(self, request):
        try:
            # Get user_id from request data
            user_id = request.data.get('student')
            if not user_id:
                return Response({"error": "User ID is required"}, status=status.HTTP_400_BAD_REQUEST)
            
            try:
                user = User.objects.get(id=user_id)
                if user.user_type != 'student':
                    return Response(
                        {"error": "Only students can apply for internships"},
                        status=status.HTTP_403_FORBIDDEN
                    )
                
                student = Student.objects.get(user=user)

            except User.DoesNotExist:
                return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)
            except Student.DoesNotExist:
                return Response({"error": "Student profile not found"}, status=status.HTTP_404_NOT_FOUND)

            serializer = ApplicationSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(
                    serializer.data,
                    status=status.HTTP_201_CREATED
                )
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        except Exception as e:
            print(f"Error in ApplicationView POST: {str(e)}")  # Debug print
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def patch(self, request, application_id):
        try:
            application = Application.objects.get(id=application_id)
            # Check user permissions and update logic
            # ...

            serializer = ApplicationSerializer(application, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except Application.DoesNotExist:
            return Response({"error": "Application not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            print(f"Error in ApplicationView PATCH: {str(e)}")  # Debug print
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        



    
class InterviewView(APIView):
    permission_classes = [AllowAny] 

    def get(self, request, application_id=None):
        try:
            if application_id:
                # Get interviews for specific application
                application = Application.objects.get(id=application_id)
                
                # Check permissions
                if request.user.user_type == 'company':
                    if request.user.company_profile != application.internship.company:
                        return Response(
                            {"error": "You can only view interviews for your own internships"},
                            status=status.HTTP_403_FORBIDDEN
                        )
                elif request.user.user_type == 'student':
                    if request.user.student_profile != application.student:
                        return Response(
                            {"error": "You can only view your own interviews"},
                            status=status.HTTP_403_FORBIDDEN
                        )
                
                interviews = Interview.objects.filter(application=application)
            else:
                # Get all interviews based on user type
                if request.user.user_type == 'company':
                    interviews = Interview.objects.filter(
                        application__internship__company=request.user.company_profile
                    )
                elif request.user.user_type == 'student':
                    interviews = Interview.objects.filter(
                        application__student=request.user.student_profile
                    )
                else:
                    return Response(
                        {"error": "Invalid user type"},
                        status=status.HTTP_403_FORBIDDEN
                    )

            serializer = InterviewSerializer(interviews, many=True)
            return Response(serializer.data)

        except Application.DoesNotExist:
            return Response(
                {"error": "Application not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def post(self, request):
        try:
            # Get user_id from query params
            user_id = request.query_params.get('user_id')
            if not user_id:
                return Response({"error": "User ID is required"}, status=status.HTTP_400_BAD_REQUEST)

            user = User.objects.get(id=user_id)
            if user.user_type != 'company':
                return Response(
                    {"error": "Only companies can schedule interviews"},
                    status=status.HTTP_403_FORBIDDEN
                )

            # Get the application ID from the request data
            application_id = request.data.get('application')
            if not application_id:
                return Response({"error": "Application ID is required"}, status=status.HTTP_400_BAD_REQUEST)

            # Verify the application exists
            application = Application.objects.get(id=application_id)
            if application.internship.company != user.company_profile:
                return Response(
                    {"error": "You can only schedule interviews for your own internships"},
                    status=status.HTTP_403_FORBIDDEN
                )

            # Create the interview
            serializer = InterviewSerializer(data=request.data)
            if serializer.is_valid():
                interview = serializer.save()
                
                # Update application status
                application.status = 'under_review'
                application.save()

                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)
        except Application.DoesNotExist:
            return Response({"error": "Application not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            print(f"Error in InterviewView POST: {str(e)}")  # Debug print
            return Response(
                {"error": "An unexpected error occurred", "details": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def patch(self, request, interview_id):
        try:
            interview = Interview.objects.get(id=interview_id)
            
            # Only companies can update interview details
            if request.user.user_type == 'company':
                if request.user.company_profile != interview.application.internship.company:
                    return Response(
                        {"error": "You can only update your own interviews"},
                        status=status.HTTP_403_FORBIDDEN
                    )
            else:
                return Response(
                    {"error": "Only companies can update interview details"},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            serializer = InterviewSerializer(
                interview,
                data=request.data,
                partial=True
            )
            
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        except Interview.DoesNotExist:
            return Response(
                {"error": "Interview not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        



    
class UniversityView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request, pk=None):
        if pk:
            try:
                university = University.objects.get(user_id=pk)
                serializer = UniversitySerializer(university)
                return Response(serializer.data)
            except University.DoesNotExist:
                return Response(
                    {"error": "University not found"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
        universities = University.objects.all()
        serializer = UniversitySerializer(universities, many=True)
        return Response(serializer.data)

    def put(self, request, pk):
        try:
            university = University.objects.get(user_id=pk)
            serializer = UniversitySerializer(university, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except University.DoesNotExist:
            return Response(
                {"error": "University not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

    def post(self, request, pk=None):
        # Handle department creation
        if pk and 'department' in request.data:
            try:
                university = University.objects.get(user_id=pk)
                print("Found university:", university)
                
                # Create department data with university
                department_data = {
                    'university': university,  # Pass the university object directly
                    'name': request.data['department']['name'],
                    'description': request.data['department']['description'],
                    'head_of_department': request.data['department']['head_of_department']
                }
                
                # Create department directly
                department = Department.objects.create(**department_data)
                print("Created department:", department)
                
                # Serialize for response
                serializer = DepartmentSerializer(department)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
                
            except University.DoesNotExist:
                return Response(
                    {"error": "University not found"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            except Exception as e:
                print("Error creating department:", str(e))
                return Response(
                    {"error": str(e)}, 
                    status=status.HTTP_400_BAD_REQUEST
                )

class DepartmentView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []
    def get(self, request, pk):
        try:
            department = Department.objects.get(id=pk)
            serializer = DepartmentSerializer(department)
            return Response(serializer.data)
        except Department.DoesNotExist:
            return Response(
                {"error": "Department not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

    def post(self, request, pk):
        # Handle course creation
        try:
            department = Department.objects.get(id=pk)
            print("Found department:", department)
            
            # Create course data with department
            course_data = {
                'department': department,  # Pass the department object directly
                'name': request.data['name'],
                'code': request.data['code'],
                'description': request.data['description'],
                'duration': request.data['duration'],
                'credits': request.data['credits']
            }
            
            # Create course directly
            course = Course.objects.create(**course_data)
            print("Created course:", course)
            
            # Serialize for response
            serializer = CourseSerializer(course)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
            
        except Department.DoesNotExist:
            return Response(
                {"error": "Department not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            print("Error creating course:", str(e))
            return Response(
                {"error": str(e)}, 
                status=status.HTTP_400_BAD_REQUEST
            )

class CourseView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []
    def get(self, request, pk):
        try:
            course = Course.objects.get(id=pk)
            serializer = CourseSerializer(course)
            return Response(serializer.data)
        except Course.DoesNotExist:
            return Response(
                {"error": "Course not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

    def post(self, request, pk):
        # Handle subject creation
        try:
            course = Course.objects.get(id=pk)
            print("Found course:", course)
            
            # Create subject data with course
            subject_data = {
                'course': course,  # Pass the course object directly
                'name': request.data['name'],
                'code': request.data['code'],
                'description': request.data['description'],
                'credits': request.data['credits'],
                'is_mandatory': request.data['is_mandatory'],
                'semester': request.data['semester']
            }
            
            # Create subject directly
            subject = Subject.objects.create(**subject_data)
            print("Created subject:", subject)
            
            # Serialize for response
            serializer = SubjectSerializer(subject)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
            
        except Course.DoesNotExist:
            return Response(
                {"error": "Course not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            print("Error creating subject:", str(e))
            return Response(
                {"error": str(e)}, 
                status=status.HTTP_400_BAD_REQUEST
            )

class FeedbackView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []
    def get(self, request):
        try:
            # Get feedback only from users who are students
            feedbacks = Feedback.objects.filter(
                user__user_type='student'  # Filter by user_type field
            ).select_related('user')  # Optimize query by including user data

            serializer = FeedbackSerializer(feedbacks, many=True)
            return Response(serializer.data)
        except Exception as e:
            return Response(
                {"error": str(e)}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def post(self, request):
        try:
            user_id = request.data.get('user')  # Get user_id from request data
            if not user_id:
                return Response({"error": "User ID is required."}, status=status.HTTP_400_BAD_REQUEST)

            # Fetch the user based on user_id
            # try:
            #     user = User.objects.get(id=user_id)
            #     # print(user.id)
            # except User.DoesNotExist:
            #     return Response({"error": "User not found."}, status=status.HTTP_404_NOT_FOUND)

            # Prepare the feedback data
            feedback_data = request.data.copy()  # Create a copy of the request data
            feedback_data['user'] = user_id  # Assign the user object
            # print(feedback_data)

            # Validate and save the feedback
            serializer = FeedbackSerializer(data=feedback_data)
            
            if serializer.is_valid():
                serializer.save()  # Save the feedback with the associated user
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            print(serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def delete(self, request, feedback_id):
        try:
            feedback = Feedback.objects.get(id=feedback_id)
            
            # Only allow users to delete their own feedback or staff members
            if feedback.user != request.user and not request.user.is_staff:
                return Response(
                    {"error": "You can only delete your own feedback"},
                    status=status.HTTP_403_FORBIDDEN
                )

            feedback.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)

        except Feedback.DoesNotExist:
            return Response(
                {"error": "Feedback not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def put(self, request, feedback_id):
        try:
            feedback = Feedback.objects.get(id=feedback_id)
            
            # Only allow users to update their own feedback
            if feedback.user != request.user:
                return Response(
                    {"error": "You can only update your own feedback"},
                    status=status.HTTP_403_FORBIDDEN
                )

            serializer = FeedbackSerializer(
                feedback,
                data=request.data,
                partial=True
            )
            
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        except Feedback.DoesNotExist:
            return Response(
                {"error": "Feedback not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        



    
class ComplaintView(APIView):
    permission_classes = [AllowAny] 

    def get(self, request):
        try:
            # Staff can see all complaints
            if request.user.is_staff:
                complaints = Complaint.objects.all()
            else:
                # Regular users can only see their own complaints
                complaints = Complaint.objects.filter(user=request.user)

            # Optional status filter
            status = request.query_params.get('status', None)
            if status:
                complaints = complaints.filter(status=status)

            serializer = ComplaintSerializer(
                complaints, 
                many=True,
                context={'request': request}
            )
            return Response(serializer.data)

        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def post(self, request):
        try:
            serializer = ComplaintSerializer(
                data=request.data,
                context={'request': request}
            )
            if serializer.is_valid():
                # Associate the complaint with the current user
                serializer.save(user=request.user)
                return Response(
                    serializer.data,
                    status=status.HTTP_201_CREATED
                )
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def patch(self, request, complaint_id):
        try:
            complaint = Complaint.objects.get(id=complaint_id)
            
            # Check permissions
            if not request.user.is_staff and complaint.user != request.user:
                return Response(
                    {"error": "You don't have permission to modify this complaint"},
                    status=status.HTTP_403_FORBIDDEN
                )

            # Regular users can only update the message
            if not request.user.is_staff:
                allowed_fields = {'message'}
                received_fields = set(request.data.keys())
                if not received_fields.issubset(allowed_fields):
                    return Response(
                        {"error": "You can only update the message content"},
                        status=status.HTTP_403_FORBIDDEN
                    )

            serializer = ComplaintSerializer(
                complaint,
                data=request.data,
                partial=True,
                context={'request': request}
            )
            
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        except Complaint.DoesNotExist:
            return Response(
                {"error": "Complaint not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def delete(self, request, complaint_id):
        try:
            complaint = Complaint.objects.get(id=complaint_id)
            
            # Only staff or the complaint owner can delete
            if not request.user.is_staff and complaint.user != request.user:
                return Response(
                    {"error": "You don't have permission to delete this complaint"},
                    status=status.HTTP_403_FORBIDDEN
                )

            complaint.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)

        except Complaint.DoesNotExist:
            return Response(
                {"error": "Complaint not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        



    
class UniversitySearchView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request):
        query = request.query_params.get('query', '')
        if query:
            # Search for universities where first_name contains the query (case-insensitive)
            universities = University.objects.filter(
                user__first_name__icontains=query
            ).values('user__first_name')[:5]  # Limit to 5 results
            
            # Format the response
            results = [
                {'name': uni['user__first_name']} 
                for uni in universities
            ]
            return Response(results)
        return Response([])

class UniversityStudentsView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request):
        try:
            # Get user_id from query params
            user_id = request.query_params.get('user_id')
            if not user_id:
                return Response(
                    {"error": "user_id is required"}, 
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Get current university using user_id
            university = University.objects.get(user_id=user_id)
            page_size = int(request.query_params.get('page_size', 10))
            page_number = int(request.query_params.get('page', 1))
            
            # Get all students from this university
            students = Student.objects.filter(
                university=university.user.first_name
            ).select_related('user')
            
            # Get applications for each student
            student_data = []
            for student in students:
                # Get recent and active applications
                thirty_days_ago = timezone.now() - timezone.timedelta(days=30)
                ninety_days_ago = timezone.now() - timezone.timedelta(days=90)
                
                applications = Application.objects.filter(
                    student=student
                ).filter(
                    Q(status='under_review') |
                    Q(status='applied', date_applied__gte=thirty_days_ago) |
                    Q(status='accepted', date_applied__gte=ninety_days_ago)
                ).select_related(
                    'internship',
                    'internship__company'
                ).order_by('-date_applied')
                
                application_data = []
                for app in applications:
                    application_data.append({
                        'id': app.id,
                        'company_name': app.internship.company.company_name,
                        'position': app.internship.title,
                        'status': app.status,
                        'date_applied': app.date_applied,
                        'is_paid': app.internship.is_paid,
                        'description': app.description
                    })
                
                student_data.append({
                    'id': student.id,
                    'name': f"{student.user.first_name} {student.user.last_name}",
                    'email': student.user.email,
                    'profile_image': request.build_absolute_uri(student.profile.url) if student.profile else None,
                    'cv_file': request.build_absolute_uri(student.cv_file.url) if student.cv_file else None,
                    'cv_text': student.cv,
                    'applications': application_data
                })
            
            # Implement pagination
            paginator = Paginator(student_data, page_size)
            page_obj = paginator.get_page(page_number)
            
            return Response({
                'results': page_obj.object_list,
                'total_pages': paginator.num_pages,
                'current_page': page_number,
                'total_count': paginator.count
            })
            
        except University.DoesNotExist:
            return Response(
                {"error": "University not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
class ApplicationStatusView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request, application_id):
        try:
            user_id = request.query_params.get('user_id')
            
            if not user_id:
                return Response({"error": "User ID is required"}, status=status.HTTP_400_BAD_REQUEST)

            user = User.objects.get(id=user_id)

            application = Application.objects.select_related(
                'student',
                'student__user',
                'internship',
                'internship__company'
            ).prefetch_related('interviews').get(id=application_id)
            
            # Check if user has permission to view this application
            if user.user_type == 'student' and str(application.student.user.id) != user_id:
                return Response(
                    {"error": "You don't have permission to view this application"},
                    status=status.HTTP_403_FORBIDDEN
                )
            elif user.user_type == 'company' and application.internship.company.user.id != user.id:
                return Response(
                    {"error": "You don't have permission to view this application"},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            serializer = ApplicationSerializer(application)
            return Response(serializer.data)

        except Application.DoesNotExist:
            return Response({"error": "Application not found"}, status=status.HTTP_404_NOT_FOUND)
        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            print(f"Error in ApplicationStatusView GET: {str(e)}")
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class ApplicationDetailView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []
    def get(self, request, application_id):
        try:
            # Get the application with related student and user
            application = Application.objects.select_related(
                'student', 
                'student__user'
            ).get(id=application_id)

            # Format response exactly as SelectStud.tsx expects
            response_data = {
                'id': application.id,
                'student': application.student.id,
                'student_details': {
                    'user': {
                        'id': application.student.user.id,
                        'first_name': application.student.user.first_name,
                        'last_name': application.student.user.last_name,
                        'email': application.student.user.email,
                    },
                    'university': application.student.university,
                    'profile_url': application.student.profile.url if application.student.profile else None
                },
                'internship': application.internship.id,
                'date_applied': application.date_applied,
                'description': application.description,
                'status': application.status
            }

            return Response(response_data)

        except Application.DoesNotExist:
            return Response({'error': 'Application not found'}, status=404)