import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer

class Recommendation:
    """AI-powered internship recommendation system"""

    # Load embedding model (Fast & Free)
    model = SentenceTransformer('all-MiniLM-L6-v2')

    @staticmethod
    def get_recommendations(internships, student_cv, student_academic_info=None, top_n=5):
        """
        Generate internship recommendations using CV and academic background.
        
        Args:
        - internships: List of internship dictionaries with 'id', 'description', 'skills_required'
        - student_cv: Student's resume text
        - student_academic_info: String containing university, department, course, and skills
        - top_n: Number of recommendations to return
        """
        if not internships or not student_cv:
            return []

        internships_list = list(internships)
        
        # Combine CV and academic info for processing
        student_profile = student_cv
        if student_academic_info:
            student_profile = f"{student_cv} {student_academic_info}"

        # Prepare internship texts
        internship_texts = [f"{i['description']} {i['skills_required']}" for i in internships_list]
        
        # Generate embeddings
        documents = [student_profile] + internship_texts
        embeddings = Recommendation.model.encode(documents)
        embedding_similarities = cosine_similarity([embeddings[0]], embeddings[1:])[0]

        # TF-IDF Similarity
        tfidf_vectorizer = TfidfVectorizer(stop_words='english')
        tfidf_matrix = tfidf_vectorizer.fit_transform(documents)
        tfidf_similarities = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:])[0]

        # Combine both similarity scores (weighted sum)
        final_scores = 0.7 * embedding_similarities + 0.3 * tfidf_similarities

        # Get top N recommendations
        top_indices = np.argsort(final_scores)[::-1]
        recommended_ids = [
            internships_list[idx]['id']
            for idx in top_indices[:top_n] if final_scores[idx] > 0
        ]

        return recommended_ids

# Example Usage
if __name__ == "__main__":
    test_internships = [
        {'id': 1, 'description': 'Python developer with ML experience', 'skills_required': 'Python, TensorFlow, ML'},
        {'id': 2, 'description': 'Web development role', 'skills_required': 'JavaScript, React, Node.js'},
        {'id': 3, 'description': 'Data Scientist position', 'skills_required': 'Python, Pandas, Machine Learning'}
    ]

    test_cv = """
    Experienced programmer with Python skills.
    Worked on several machine learning projects using TensorFlow.
    """

    recommendations = Recommendation.get_recommendations(test_internships, test_cv)
    print("Recommended Internship IDs:", recommendations)
