import pdfplumber
import fitz  # PyMuPDF
import pytesseract
from PIL import Image
import os

class PDFProcessor:
    @staticmethod
    def extract_text(file_path):
        """Extract text from a PDF file using pdfplumber or OCR if needed."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"CV file not found at: {file_path}")

        text = ""

        # Try extracting selectable text first
        try:
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    text += page.extract_text() or ""
            if text.strip():  # If text was found, return it
                return text
        except Exception as e:
            print(f"Error using pdfplumber: {e}")

        # If no text found, use PyMuPDF (Fallback)
        try:
            doc = fitz.open(file_path)
            for page in doc:
                text += page.get_text("text") or ""
            doc.close()
            if text.strip():
                return text
        except Exception as e:
            print(f"Error using PyMuPDF: {e}")
            doc.close() if 'doc' in locals() else None

        # If no text found, use OCR
        print("No selectable text found, using OCR...")
        text = PDFProcessor.extract_text_ocr(file_path)
        return text

    @staticmethod
    def extract_text_ocr(file_path):
        """Extract text using OCR (Tesseract) from scanned PDFs."""
        text = ""
        try:
            doc = fitz.open(file_path)
            for page in doc:
                image = page.get_pixmap()
                img = Image.frombytes("RGB", [image.width, image.height], image.samples)
                text += pytesseract.image_to_string(img) + "\n"
            doc.close()
        except Exception as e:
            print(f"Error in OCR: {e}")
            doc.close() if 'doc' in locals() else None
        return text

def main():
    """Main function for testing the PDFProcessor."""
    file_path = "calendar.pdf"  # Change this to test other PDFs
    extracted_text = PDFProcessor.extract_text(file_path)
    
    print("Extracted Text from PDF:")
    print(extracted_text)

if __name__ == "__main__":
    main()
