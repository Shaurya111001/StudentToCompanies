import pytest
from rest_framework.exceptions import ValidationError
from ..models import User, Student, Company, University, Feedback, Complaint, Application, Internship, Interview
from ..serializers import (
    UserSerializer,
    StudentSerializer,
    CompanySerializer,
    UniversitySerializer,
    FeedbackSerializer,
    ComplaintSerializer,
    ApplicationSerializer,
    InternshipSerializer,
    InterviewSerializer
)

@pytest.mark.django_db
class TestSerializers:
    def test_user_serializer_valid(self):
        data = {
            "email": "testuser@example.com",
            "password": "password123",
            "first_name": "Test",
            "last_name": "User",
            "user_type": "student"
        }
        serializer = UserSerializer(data=data)
        assert serializer.is_valid()
        assert serializer.validated_data['email'] == data['email']

    def test_user_serializer_invalid(self):
        data = {
            "email": "invalidemail",
            "password": "short",
            "first_name": "Gani12",
            "user_type": "student"
        }
        serializer = UserSerializer(data=data)
        assert not serializer.is_valid()
        assert 'email' in serializer.errors
        assert 'first_name' not in serializer.errors
        assert 'password' in serializer.errors

    def test_student_serializer(self):
        user = User.objects.create_user(
            email='student@example.com',
            password='password123',
            first_name='Student',
            last_name='User',
            user_type='student'
        )
        data = {
            "user": {
                "email": user.email,
                "password": "password123",
                "first_name": "Student",
                "last_name": "User",
                "user_type": "student"
            },
            "university": "Test University",
            "cv_file": None
        }
        serializer = StudentSerializer(data=data)
        assert serializer.is_valid()
        student = serializer.save()
        assert student.user.email == user.email

    def test_company_serializer(self):
        user = User.objects.create_user(
            email='company@example.com',
            password='password123',
            first_name='Company',
            last_name='User',
            user_type='company'
        )
        data = {
            "user": {
                "email": user.email,
                "password": "password123",
                "first_name": "Company",
                "last_name": "User",
                "user_type": "company"
            },
            "company_name": "Test Company",
            "description": "A test company."
        }
        serializer = CompanySerializer(data=data)
        assert serializer.is_valid()
        company = serializer.save()
        assert company.user.email == user.email
        assert company.company_name == "Test Company"

    def test_university_serializer(self):
        user = User.objects.create_user(
            email='university@example.com',
            password='password123',
            first_name='University',
            last_name='User',
            user_type='university'
        )
        data = {
            "user": {
                "email": user.email,
                "password": "password123",
                "first_name": "University",
                "last_name": "User",
                "user_type": "university"
            },
            "university_code": "Test University",
            "description": "A test university.",
            "location": "Test Location",
            "website": "http://testuniversity.com"
        }
        serializer = UniversitySerializer(data=data)
        assert serializer.is_valid()
        university = serializer.save()
        assert university.user.email == user.email
        assert university.university_code == "Test University"

    def test_feedback_serializer_valid(self):
        user = User.objects.create_user(
            email='student@example.com',
            password='password123',
            first_name='Student',
            last_name='User',
            user_type='student'
        )
        data = {
            "user": {
                "email": user.email,
                "password": "password123",
                "first_name": "Student",
                "last_name": "User",
                "user_type": "student"
            },
            "message": "Great experience!",
            "rating": 5
        }
        serializer = FeedbackSerializer(data=data)
        assert serializer.is_valid()
        feedback = serializer.save()
        assert feedback.message == data['message']
        assert feedback.rating == data['rating']

    def test_feedback_serializer_invalid(self):
        data = {
            "message": "Bad",
            "rating": 6  # Invalid rating
        }
        serializer = FeedbackSerializer(data=data)
        assert not serializer.is_valid()
        assert 'rating' in serializer.errors

    def test_complaint_serializer(self):
        user = User.objects.create_user(
            email='student@example.com',
            password='password123',
            first_name='Student',
            last_name='User',
            user_type='student'
        )
        data = {
            "user": user.id,
            "message": "I have a complaint."
        }
        serializer = ComplaintSerializer(data=data)
        assert serializer.is_valid()
        complaint = serializer.save()
        assert complaint.message == data['message']

    def test_application_serializer(self):
        user = User.objects.create_user(
            email='student@example.com',
            password='password123',
            first_name='Student',
            last_name='User',
            user_type='student'
        )
        student = Student.objects.create(user=user)
        internship = Internship.objects.create(
            title='Software Internship',
            description='An internship for software development.',
            company='Test Company',
            start_date='2023-12-01',
            end_date='2024-01-01'
        )
        data = {
            "student": student.id,
            "internship": internship.id,
            "status": "applied"
        }
        serializer = ApplicationSerializer(data=data)
        assert serializer.is_valid()
        application = serializer.save()
        assert application.student == student
        assert application.internship == internship
        assert application.status == data['status']

    def test_internship_serializer(self):
        company = Company.objects.create(
            user=User.objects.create_user(
                email='company@example.com',
                password='password123',
                first_name='Company',
                last_name='User',
                user_type='company'
            ),
            company_name='Test Company',
            description='A test company.'
        )
        data = {
            "title": "Software Internship",
            "description": "An internship for software development.",
            "company": company.id,
            "start_date": "2023-12-01",
            "end_date": "2024-01-01",
            "skills_required": "Python, Django",
            "is_paid": True
        }
        serializer = InternshipSerializer(data=data)
        assert serializer.is_valid()
        internship = serializer.save()
        assert internship.title == data['title']
        assert internship.company == company

    def test_interview_serializer(self):
        user = User.objects.create_user(
            email='student@example.com',
            password='password123',
            first_name='Student',
            last_name='User',
            user_type='student'
        )
        student = Student.objects.create(user=user)
        company = Company.objects.create(
            user=User.objects.create_user(
                email='company@example.com',
                password='password123',
                first_name='Company',
                last_name='User',
                user_type='company'
            ),
            company_name='Test Company',
            description='A test company.'
        )
        internship = Internship.objects.create(
            title='Software Internship',
            description='An internship for software development.',
            company=company,
            start_date='2023-12-01',
            end_date='2024-01-01'
        )
        application = Application.objects.create(
            student=student,
            internship=internship,
            status='applied'
        )
        data = {
            "application": application.id,
            "date_time": "2023-12-01T10:00:00Z",
            "location": "Online",
            "interview_type": "online"
        }
        serializer = InterviewSerializer(data=data)
        assert serializer.is_valid()
        interview = serializer.save()
        assert interview.application == application
        assert interview.date_time == data['date_time']
        assert interview.location == data['location']
        assert interview.interview_type == data['interview_type']
