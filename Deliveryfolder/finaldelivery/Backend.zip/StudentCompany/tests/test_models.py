import pytest
from ..models import User, Student, Company, University, Feedback, Complaint, Application, Internship

@pytest.mark.django_db
class TestModels:
    def test_user_creation(self):
        user = User.objects.create_user(
            email='testuser@example.com',
            password='password123',
            user_type='student'
        )
        assert user.email == 'testuser@example.com'
        assert user.check_password('password123') is True

    def test_student_creation(self):
        user = User.objects.create_user(
            email='student@example.com',
            password='password123',
            user_type='student'
        )
        student = Student.objects.create(user=user)
        assert student.user == user

    def test_company_creation(self):
        user = User.objects.create_user(
            email='company@example.com',
            password='password123',
            user_type='company'
        )
        company = Company.objects.create(user=user, company_name='Test Company')
        assert company.user == user
        assert company.company_name == 'Test Company'

    def test_university_creation(self):
        user = User.objects.create_user(
            email='university@example.com',
            password='password123',
            user_type='university'
        )
        university = University.objects.create(user=user, university_code='Test University')
        assert university.user == user
        assert university.university_code == 'Test University'

    def test_feedback_creation(self):
        user = User.objects.create_user(
            email='student@example.com',
            password='password123',
            user_type='student'
        )
        feedback = Feedback.objects.create(user=user, message='Great experience!', rating=5)
        assert feedback.user == user
        assert feedback.message == 'Great experience!'
        assert feedback.rating == 5

    def test_complaint_creation(self):
        user = User.objects.create_user(
            email='student@example.com',
            password='password123',
            user_type='student'
        )
        complaint = Complaint.objects.create(user=user, message='I have a complaint.')
        assert complaint.user == user
        assert complaint.message == 'I have a complaint.'

    def test_application_creation(self):
        user = User.objects.create_user(
            email='student@example.com',
            password='password123',
            user_type='student'
        )
        user2 = User.objects.create_user(
            email='company@example.com',
            password='password123',
            user_type='company'
        )
        company = Company.objects.create(user=user2)
        internship = Internship.objects.create(
            title='Software Internship',
            description='An internship for software development.',
            company=company,
            skills_required = "python",
            start_date='2023-12-01',  # Provide a valid start date
            end_date='2024-01-01' 
        )
        student = Student.objects.create(user=user)
        application = Application.objects.create(student=student, status='applied', internship=internship)
        assert application.student == student
        assert application.internship == internship
        assert application.status == 'applied'
